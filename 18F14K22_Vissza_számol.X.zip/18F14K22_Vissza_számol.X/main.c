#include "main.h"
#include "oled_i2c.h"

/*
 * PIC18F14K22 countdown timer
 *
 * Buttons are assumed to connect the input pin to GND when pressed.
 * RB5 and RB7 use the PIC's internal pull-ups; RA2 and RC0 need the
 * corresponding external pull-up resistors on the board.
 */

/* Configuration for the external 8 MHz crystal. */
#pragma config FOSC = HS, PLLEN = OFF, PCLKEN = ON, FCMEN = OFF, IESO = OFF
#pragma config PWRTEN = ON, BOREN = OFF, BORV = 19
#pragma config WDTEN = OFF
#pragma config MCLRE = ON, STVREN = ON, LVP = OFF, XINST = OFF

#define TIMER0_RELOAD_HIGH      0xFFu
#define TIMER0_RELOAD_LOW       0x06u  /* 1 ms: 8 MHz / 4 / 8 = 250 kHz */

#define BUTTON_UP               0x01u
#define BUTTON_DOWN             0x02u
#define BUTTON_NEXT             0x04u
#define BUTTON_START            0x08u
#define BUTTON_MASK             (BUTTON_UP | BUTTON_DOWN | BUTTON_NEXT | BUTTON_START)

#define BUTTON_DEBOUNCE_COUNT   3u     /* 3 x 10 ms */
#define BUTTON_POLL_MS          10UL
#define START_LONG_PRESS_MS     2000UL
#define UP_DOWN_REPEAT_START_MS 2000UL
#define UP_DOWN_REPEAT_MS       100UL
#define ALARM_TOGGLE_MS         250UL
#define COLON_BLINK_MS          500UL

#define TIME_DISPLAY_COLUMN     16u
#define TIME_DISPLAY_PAGE       4u
#define TIME_DISPLAY_WIDTH      96u

#define EEPROM_MAGIC            0xA5u
#define EEPROM_MAGIC_ADDRESS    0x00u
#define EEPROM_HOUR_ADDRESS     0x01u
#define EEPROM_MINUTE_ADDRESS   0x02u
#define EEPROM_SECOND_ADDRESS   0x03u
#define EEPROM_CHECK_ADDRESS    0x04u

#define LED1                    LATCbits.LATC1
#define LED2                    LATCbits.LATC2
#define BUZZER                  LATCbits.LATC3
#define RELAY                   LATCbits.LATC5

typedef enum {
    STATE_SPLASH,
    STATE_SETUP,
    STATE_RUNNING,
    STATE_PAUSED,
    STATE_EXPIRED
} AppState;

typedef enum {
    FIELD_HOUR,
    FIELD_MINUTE,
    FIELD_SECOND
} EditField;

typedef struct {
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
} TimeValue;

typedef struct {
    uint8_t pressed;
    uint8_t repeated;
    bool startPressed;
    bool startShort;
    bool startLong;
    bool anyPressed;
} ButtonEvents;

static volatile uint32_t milliseconds = 0UL;

static AppState appState = STATE_SPLASH;
static EditField editField = FIELD_HOUR;
static TimeValue setTime = {0u, 0u, 0u};
static TimeValue remainingTime = {0u, 0u, 0u};

static uint32_t splashStartedAt = 0UL;
static uint32_t lastSecondAt = 0UL;
static uint32_t lastAlarmToggleAt = 0UL;
static uint32_t lastColonBlinkAt = 0UL;
static bool alarmOn = false;
static bool colonVisible = true;

static uint8_t buttonStable = 0u;
static uint8_t buttonLastRaw = 0u;
static uint8_t buttonDebounce[4] = {0u, 0u, 0u, 0u};
static uint32_t lastButtonPollAt = 0UL;
static uint32_t startPressedAt = 0UL;
static uint32_t upPressedAt = 0UL;
static uint32_t downPressedAt = 0UL;
static uint32_t lastUpRepeatAt = 0UL;
static uint32_t lastDownRepeatAt = 0UL;
static bool startLongReported = false;
static bool consumeStartRelease = false;

static const uint8_t buttonMasks[4] = {
    BUTTON_UP, BUTTON_DOWN, BUTTON_NEXT, BUTTON_START
};

static void Hardware_Init(void);
static void Timer0_Init(void);
static void Outputs_Off(void);
static void Outputs_CountdownOn(void);
static uint32_t Millis(void);
static uint8_t ReadButtonsRaw(void);
static void Buttons_Init(uint32_t now);
static ButtonEvents Buttons_Update(uint32_t now);
static void Buttons_ConsumeStartRelease(void);
static bool Time_IsZero(const TimeValue *time);
static bool Time_Decrement(TimeValue *time);
static void Time_Adjust(EditField field, bool increment);
static void Time_ToText(const TimeValue *time, char text[9]);
static void EEPROM_Write(uint8_t address, uint8_t value);
static uint8_t EEPROM_Read(uint8_t address);
static uint8_t EEPROM_Check(const TimeValue *time);
static void EEPROM_SaveTime(const TimeValue *time);
static bool EEPROM_LoadTime(TimeValue *time);
static void Show_Splash(void);
static void Show_Setup(void);
static void Show_SetupValues(void);
static void Show_Countdown(const char *title);
static void Show_CountdownTime(void);
static void Show_Expired(void);
static void Start_Countdown(uint32_t now);
static void Pause_Countdown(void);
static void Resume_Countdown(uint32_t now);
static void Finish_Countdown(uint32_t now);
static void Update_Countdown(uint32_t now);
static void Update_Alarm(uint32_t now);
static void Handle_Events(const ButtonEvents *events, uint32_t now);

void __interrupt() InterruptServiceRoutine(void)
{
    if (INTCONbits.TMR0IF != 0u) {
        TMR0H = TIMER0_RELOAD_HIGH;
        TMR0L = TIMER0_RELOAD_LOW;
        INTCONbits.TMR0IF = 0;
        milliseconds++;
    }
}

void main(void)
{
    uint32_t now;
    ButtonEvents events;

    Hardware_Init();
    OLED_Init();

    now = Millis();
    Buttons_Init(now);
    Outputs_Off();
    Show_Splash();
    splashStartedAt = now;

    for (;;) {
        now = Millis();
        events = Buttons_Update(now);

        if (appState == STATE_SPLASH) {
            if ((uint32_t)(now - splashStartedAt) >= 3000UL) {
                appState = STATE_SETUP;
                editField = FIELD_HOUR;
                Outputs_Off();
                Show_Setup();
            }
        } else {
            Handle_Events(&events, now);
        }

        if (appState == STATE_RUNNING) {
            Update_Countdown(now);
        } else if (appState == STATE_EXPIRED) {
            Update_Alarm(now);
        }
    }
}

static void Hardware_Init(void)
{
    ANSEL = 0x00;
    ANSELH = 0x00;
    CM1CON0 = 0x00;
    CM2CON0 = 0x00;

    LATA = 0x00;
    LATB = 0x00;
    LATC = 0x00;

    TRISA = 0xFF;
    TRISB = 0xFF;
    TRISC = 0xFF;

    TRISAbits.TRISA2 = 1;   /* START / MENU */
    TRISBbits.TRISB5 = 1;   /* DOWN */
    TRISBbits.TRISB7 = 1;   /* NEXT */
    TRISCbits.TRISC0 = 1;   /* UP */

    TRISCbits.TRISC1 = 0;   /* LED1 */
    TRISCbits.TRISC2 = 0;   /* LED2 */
    TRISCbits.TRISC3 = 0;   /* buzzer */
    TRISCbits.TRISC5 = 0;   /* relay */

    /* Internal pull-ups are available on PORTB inputs only. */
    INTCON2bits.nRBPU = 0;
    WPUBbits.WPUB5 = 1;
    WPUBbits.WPUB7 = 1;

    Timer0_Init();
}

static void Timer0_Init(void)
{
    RCONbits.IPEN = 0;

    T0CON = 0x02;           /* 16 bit, Fosc/4, 1:8 prescaler, timer off */
    TMR0H = TIMER0_RELOAD_HIGH;
    TMR0L = TIMER0_RELOAD_LOW;
    INTCONbits.TMR0IF = 0;
    INTCONbits.TMR0IE = 1;
    INTCONbits.GIE = 1;
    T0CONbits.TMR0ON = 1;
}

static void Outputs_Off(void)
{
    LED1 = 0;
    LED2 = 0;
    BUZZER = 0;
    RELAY = 0;
    alarmOn = false;
}

static void Outputs_CountdownOn(void)
{
    LED1 = 1;
    LED2 = 0;
    BUZZER = 0;
    RELAY = 1;
}

static uint32_t Millis(void)
{
    uint8_t interruptsEnabled;
    uint32_t result;

    interruptsEnabled = INTCONbits.GIE;
    INTCONbits.GIE = 0;
    result = milliseconds;
    INTCONbits.GIE = interruptsEnabled;

    return result;
}

static uint8_t ReadButtonsRaw(void)
{
    uint8_t value = 0u;

    if (PORTCbits.RC0 == 0u) {
        value |= BUTTON_UP;
    }
    if (PORTBbits.RB5 == 0u) {
        value |= BUTTON_DOWN;
    }
    if (PORTBbits.RB7 == 0u) {
        value |= BUTTON_NEXT;
    }
    if (PORTAbits.RA2 == 0u) {
        value |= BUTTON_START;
    }

    return value;
}

static void Buttons_Init(uint32_t now)
{
    buttonStable = ReadButtonsRaw();
    buttonLastRaw = buttonStable;
    buttonDebounce[0] = 0u;
    buttonDebounce[1] = 0u;
    buttonDebounce[2] = 0u;
    buttonDebounce[3] = 0u;
    lastButtonPollAt = now;
    startLongReported = false;
    consumeStartRelease = false;
    upPressedAt = now;
    downPressedAt = now;
    lastUpRepeatAt = now;
    lastDownRepeatAt = now;
}

static ButtonEvents Buttons_Update(uint32_t now)
{
    ButtonEvents events = {0u, 0u, false, false, false, false};
    uint8_t raw;
    uint8_t index;

    if ((uint32_t)(now - lastButtonPollAt) < BUTTON_POLL_MS) {
        return events;
    }
    lastButtonPollAt = now;
    raw = ReadButtonsRaw();

    for (index = 0u; index < 4u; index++) {
        uint8_t mask = buttonMasks[index];
        bool rawPressed = ((raw & mask) != 0u);
        bool lastPressed = ((buttonLastRaw & mask) != 0u);
        bool stablePressed = ((buttonStable & mask) != 0u);

        if (rawPressed != lastPressed) {
            if (rawPressed) {
                buttonLastRaw |= mask;
            } else {
                buttonLastRaw &= (uint8_t)~mask;
            }
            buttonDebounce[index] = 0u;
        } else if (buttonDebounce[index] < BUTTON_DEBOUNCE_COUNT) {
            buttonDebounce[index]++;

            if ((buttonDebounce[index] >= BUTTON_DEBOUNCE_COUNT) &&
                (rawPressed != stablePressed)) {
                if (rawPressed) {
                    buttonStable |= mask;
                    if (mask == BUTTON_START) {
                        events.startPressed = true;
                        startPressedAt = now;
                        startLongReported = false;
                    } else {
                        events.pressed |= mask;
                        if (mask == BUTTON_UP) {
                            upPressedAt = now;
                            lastUpRepeatAt = now;
                        } else if (mask == BUTTON_DOWN) {
                            downPressedAt = now;
                            lastDownRepeatAt = now;
                        }
                    }
                } else {
                    buttonStable &= (uint8_t)~mask;
                    if (mask == BUTTON_START) {
                        if ((!startLongReported) && (!consumeStartRelease)) {
                            events.startShort = true;
                        }
                        consumeStartRelease = false;
                    }
                }
            }
        }
    }

    if (((buttonStable & BUTTON_START) != 0u) && (!startLongReported) &&
        ((uint32_t)(now - startPressedAt) >= START_LONG_PRESS_MS)) {
        startLongReported = true;
        events.startLong = true;
    }

    if (((buttonStable & BUTTON_UP) != 0u) &&
        ((uint32_t)(now - upPressedAt) >= UP_DOWN_REPEAT_START_MS) &&
        ((uint32_t)(now - lastUpRepeatAt) >= UP_DOWN_REPEAT_MS)) {
        lastUpRepeatAt = now;
        events.repeated |= BUTTON_UP;
    }
    if (((buttonStable & BUTTON_DOWN) != 0u) &&
        ((uint32_t)(now - downPressedAt) >= UP_DOWN_REPEAT_START_MS) &&
        ((uint32_t)(now - lastDownRepeatAt) >= UP_DOWN_REPEAT_MS)) {
        lastDownRepeatAt = now;
        events.repeated |= BUTTON_DOWN;
    }

    events.anyPressed = ((events.pressed != 0u) || events.startPressed);
    return events;
}

static void Buttons_ConsumeStartRelease(void)
{
    consumeStartRelease = true;
}

static bool Time_IsZero(const TimeValue *time)
{
    return (time->hour == 0u) && (time->minute == 0u) && (time->second == 0u);
}

static bool Time_Decrement(TimeValue *time)
{
    if (time->second != 0u) {
        time->second--;
    } else {
        time->second = 59u;
        if (time->minute != 0u) {
            time->minute--;
        } else {
            time->minute = 59u;
            if (time->hour != 0u) {
                time->hour--;
            }
        }
    }

    return !Time_IsZero(time);
}

static void Time_Adjust(EditField field, bool increment)
{
    uint8_t *value;
    uint8_t maximum;

    if (field == FIELD_HOUR) {
        value = &setTime.hour;
        maximum = 99u;
    } else if (field == FIELD_MINUTE) {
        value = &setTime.minute;
        maximum = 59u;
    } else {
        value = &setTime.second;
        maximum = 59u;
    }

    if (increment) {
        if (*value >= maximum) {
            *value = 0u;
        } else {
            (*value)++;
        }
    } else if (*value == 0u) {
        *value = maximum;
    } else {
        (*value)--;
    }
}

static void Time_ToText(const TimeValue *time, char text[9])
{
    text[0] = (char)('0' + (time->hour / 10u));
    text[1] = (char)('0' + (time->hour % 10u));
    text[2] = ':';
    text[3] = (char)('0' + (time->minute / 10u));
    text[4] = (char)('0' + (time->minute % 10u));
    text[5] = ':';
    text[6] = (char)('0' + (time->second / 10u));
    text[7] = (char)('0' + (time->second % 10u));
    text[8] = '\0';
}

static void EEPROM_Write(uint8_t address, uint8_t value)
{
    uint8_t interruptsEnabled;

    EEADR = address;
    EEDATA = value;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.WREN = 1;

    interruptsEnabled = INTCONbits.GIE;
    INTCONbits.GIE = 0;
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;
    INTCONbits.GIE = interruptsEnabled;

    while (EECON1bits.WR != 0u) {
    }
    EECON1bits.WREN = 0;
}

static uint8_t EEPROM_Read(uint8_t address)
{
    EEADR = address;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.RD = 1;
    return EEDATA;
}

static uint8_t EEPROM_Check(const TimeValue *time)
{
    return (uint8_t)(EEPROM_MAGIC ^ time->hour ^ time->minute ^ time->second ^ 0x5Au);
}

static void EEPROM_SaveTime(const TimeValue *time)
{
    EEPROM_Write(EEPROM_MAGIC_ADDRESS, EEPROM_MAGIC);
    EEPROM_Write(EEPROM_HOUR_ADDRESS, time->hour);
    EEPROM_Write(EEPROM_MINUTE_ADDRESS, time->minute);
    EEPROM_Write(EEPROM_SECOND_ADDRESS, time->second);
    EEPROM_Write(EEPROM_CHECK_ADDRESS, EEPROM_Check(time));
}

static bool EEPROM_LoadTime(TimeValue *time)
{
    uint8_t magic = EEPROM_Read(EEPROM_MAGIC_ADDRESS);

    time->hour = EEPROM_Read(EEPROM_HOUR_ADDRESS);
    time->minute = EEPROM_Read(EEPROM_MINUTE_ADDRESS);
    time->second = EEPROM_Read(EEPROM_SECOND_ADDRESS);

    if ((magic != EEPROM_MAGIC) || (time->hour > 99u) ||
        (time->minute > 59u) || (time->second > 59u)) {
        return false;
    }

    return (EEPROM_Read(EEPROM_CHECK_ADDRESS) == EEPROM_Check(time));
}

static void Show_Splash(void)
{
    OLED_Clear();
    OLED_WriteTextCenteredAtY(21u, "PIC18F14K22");
    OLED_WriteTextCenteredAtY(34u, "VISSZA SZAMLALO");
}

static void Show_Setup(void)
{
    OLED_Clear();
    OLED_WriteTextCenteredAtY(13u, "ADD MEG AZ ID\xC5\x90T");
    Show_SetupValues();
}

static void Show_SetupValues(void)
{
    char text[9];
    const char *fieldName;

    Time_ToText(&setTime, text);
    if (editField == FIELD_HOUR) {
        fieldName = "ORA ";
    } else if (editField == FIELD_MINUTE) {
        fieldName = "PERC";
    } else {
        fieldName = "MP  ";
    }

    /* All time strings are eight characters wide, so they overwrite the
       previous value in place without clearing the screen. */
    OLED_WriteTextDoubleCentered(4u, text);
    OLED_WriteTextCentered(7u, fieldName);
}

static void Show_Countdown(const char *title)
{
    OLED_Clear();
    OLED_WriteTextCenteredAtY(13u, title);
    Show_CountdownTime();
}

static void Show_CountdownTime(void)
{
    char text[9];

    Time_ToText(&remainingTime, text);
    if (!colonVisible) {
        text[2] = ' ';
        text[5] = ' ';
    }

    /* Eight double-width characters fill this complete 96 x 16 pixel field,
       so the new image overwrites the old one without a visible clear step. */
    OLED_WriteTextDoubleCentered(TIME_DISPLAY_PAGE, text);
}

static void Show_Expired(void)
{
    OLED_Clear();
    OLED_WriteTextCenteredAtY(20u, "LEJ\xC3\x81RT AZ ID\xC5\x90");
    OLED_WriteTextCenteredAtY(36u, "NYOMJ MEG GOMBOT");
}

static void Start_Countdown(uint32_t now)
{
    if (Time_IsZero(&setTime)) {
        return;
    }

    EEPROM_SaveTime(&setTime);
    remainingTime = setTime;
    appState = STATE_RUNNING;
    lastSecondAt = now;
    lastColonBlinkAt = now;
    colonVisible = true;
    Outputs_CountdownOn();
    Show_Countdown("VISSZASZAMLALAS");
}

static void Pause_Countdown(void)
{
    appState = STATE_PAUSED;
    Show_Countdown("SZUNET");
}

static void Resume_Countdown(uint32_t now)
{
    appState = STATE_RUNNING;
    lastSecondAt = now;
    lastColonBlinkAt = now;
    colonVisible = true;
    Outputs_CountdownOn();
    Show_Countdown("VISSZASZAMLALAS");
}

static void Finish_Countdown(uint32_t now)
{
    appState = STATE_EXPIRED;
    LED1 = 0;
    RELAY = 0;
    LED2 = 0;
    BUZZER = 0;
    alarmOn = false;
    lastAlarmToggleAt = now;
    Show_Expired();
}

static void Update_Countdown(uint32_t now)
{
    bool displayNeedsUpdate = false;

    while ((uint32_t)(now - lastSecondAt) >= 1000UL) {
        lastSecondAt += 1000UL;
        displayNeedsUpdate = true;
        if (!Time_Decrement(&remainingTime)) {
            Finish_Countdown(now);
            return;
        }
    }

    while ((uint32_t)(now - lastColonBlinkAt) >= COLON_BLINK_MS) {
        lastColonBlinkAt += COLON_BLINK_MS;
        colonVisible = !colonVisible;
        displayNeedsUpdate = true;
    }

    if (displayNeedsUpdate) {
        Show_CountdownTime();
    }
}

static void Update_Alarm(uint32_t now)
{
    while ((uint32_t)(now - lastAlarmToggleAt) >= ALARM_TOGGLE_MS) {
        lastAlarmToggleAt += ALARM_TOGGLE_MS;
        alarmOn = !alarmOn;
        LED2 = alarmOn ? 1 : 0;
        BUZZER = alarmOn ? 1 : 0;
    }
}

static void Handle_Events(const ButtonEvents *events, uint32_t now)
{
    TimeValue storedTime;

    if (appState == STATE_EXPIRED) {
        if (events->anyPressed) {
            if (events->startPressed) {
                Buttons_ConsumeStartRelease();
            }
            appState = STATE_SETUP;
            editField = FIELD_HOUR;
            Outputs_Off();
            Show_Setup();
        }
        return;
    }

    if (appState == STATE_SETUP) {
        if (((events->pressed | events->repeated) & BUTTON_UP) != 0u) {
            Time_Adjust(editField, true);
            Show_SetupValues();
        }
        if (((events->pressed | events->repeated) & BUTTON_DOWN) != 0u) {
            Time_Adjust(editField, false);
            Show_SetupValues();
        }
        if ((events->pressed & BUTTON_NEXT) != 0u) {
            if (editField == FIELD_SECOND) {
                editField = FIELD_HOUR;
            } else {
                editField = (EditField)(editField + 1);
            }
            Show_SetupValues();
        }
        if (events->startLong) {
            /* A long START clears an entered value. From an already empty
               field it retains the original convenience function: load the
               last value saved in EEPROM. */
            if (!Time_IsZero(&setTime)) {
                setTime.hour = 0u;
                setTime.minute = 0u;
                setTime.second = 0u;
                editField = FIELD_HOUR;
                Show_SetupValues();
            } else if (EEPROM_LoadTime(&storedTime)) {
                setTime = storedTime;
                editField = FIELD_HOUR;
                Show_SetupValues();
            }
        }
        if (events->startShort) {
            Start_Countdown(now);
        }
    } else if (appState == STATE_RUNNING) {
        if (events->startShort) {
            Pause_Countdown();
        }
    } else if (appState == STATE_PAUSED) {
        if (events->startShort) {
            Resume_Countdown(now);
        }
    }
}
