subtitle "Microchip MPLAB XC8 C Compiler v3.10 (Free license) build 20250813170317 Og1 "

pagewidth 120

	opt flic

	processor	18F14K22
include "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc\18f14k22.cgen.inc"
getbyte	macro	val,pos
	(((val) >> (8 * pos)) and 0xff)
endm
byte0	macro	val
	(getbyte(val,0))
endm
byte1	macro	val
	(getbyte(val,1))
endm
byte2	macro	val
	(getbyte(val,2))
endm
byte3	macro	val
	(getbyte(val,3))
endm
byte4	macro	val
	(getbyte(val,4))
endm
byte5	macro	val
	(getbyte(val,5))
endm
byte6	macro	val
	(getbyte(val,6))
endm
byte7	macro	val
	(getbyte(val,7))
endm
getword	macro	val,pos
	(((val) >> (8 * pos)) and 0xffff)
endm
word0	macro	val
	(getword(val,0))
endm
word1	macro	val
	(getword(val,2))
endm
word2	macro	val
	(getword(val,4))
endm
word3	macro	val
	(getword(val,6))
endm
gettword	macro	val,pos
	(((val) >> (8 * pos)) and 0xffffff)
endm
tword0	macro	val
	(gettword(val,0))
endm
tword1	macro	val
	(gettword(val,3))
endm
tword2	macro	val
	(gettword(val,6))
endm
getdword	macro	val,pos
	(((val) >> (8 * pos)) and 0xffffffff)
endm
dword0	macro	val
	(getdword(val,0))
endm
dword1	macro	val
	(getdword(val,4))
endm
clrc   macro
	bcf	status,0
endm
setc   macro
	bsf	status,0
endm
clrz   macro
	bcf	status,2
endm
setz   macro
	bsf	status,2
endm
skipnz macro
	btfsc	status,2
endm
skipz  macro
	btfss	status,2
endm
skipnc macro
	btfsc	status,0
endm
skipc  macro
	btfss	status,0
endm
pushw macro
	movwf postinc1
endm
pushf macro arg1
	movff arg1, postinc1
endm
popw macro
	movf postdec1,f
	movf indf1,w
endm
popf macro arg1
	movf postdec1,f
	movff indf1,arg1
endm
popfc macro arg1
	movff plusw1,arg1
	decfsz fsr1,f
endm
skiprom24 macro arg1
	btfsc arg1,7
endm
	global	__ramtop
	global	__accesstop
# 54 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SRCON0 equ 0F68h ;# 
# 125 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SRCON1 equ 0F69h ;# 
# 187 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CM2CON0 equ 0F6Bh ;# 
# 257 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CM2CON1 equ 0F6Ch ;# 
# 319 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CM1CON0 equ 0F6Dh ;# 
# 389 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPMSK equ 0F6Fh ;# 
# 394 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPMASK equ 0F6Fh ;# 
# 527 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SLRCON equ 0F76h ;# 
# 559 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
WPUA equ 0F77h ;# 
# 617 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
WPUB equ 0F78h ;# 
# 665 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
IOCA equ 0F79h ;# 
# 723 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
IOCB equ 0F7Ah ;# 
# 771 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ANSEL equ 0F7Eh ;# 
# 891 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ANSELH equ 0F7Fh ;# 
# 963 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PORTA equ 0F80h ;# 
# 1197 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PORTB equ 0F81h ;# 
# 1305 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PORTC equ 0F82h ;# 
# 1544 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
LATA equ 0F89h ;# 
# 1622 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
LATB equ 0F8Ah ;# 
# 1688 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
LATC equ 0F8Bh ;# 
# 1800 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TRISA equ 0F92h ;# 
# 1805 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
DDRA equ 0F92h ;# 
# 1954 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TRISB equ 0F93h ;# 
# 1959 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
DDRB equ 0F93h ;# 
# 2084 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TRISC equ 0F94h ;# 
# 2089 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
DDRC equ 0F94h ;# 
# 2306 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
OSCTUNE equ 0F9Bh ;# 
# 2376 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PIE1 equ 0F9Dh ;# 
# 2447 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PIR1 equ 0F9Eh ;# 
# 2518 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
IPR1 equ 0F9Fh ;# 
# 2589 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PIE2 equ 0FA0h ;# 
# 2650 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PIR2 equ 0FA1h ;# 
# 2711 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
IPR2 equ 0FA2h ;# 
# 2772 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
EECON1 equ 0FA6h ;# 
# 2838 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
EECON2 equ 0FA7h ;# 
# 2845 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
EEDATA equ 0FA8h ;# 
# 2852 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
EEADR equ 0FA9h ;# 
# 2914 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCSTA equ 0FABh ;# 
# 2919 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCSTA1 equ 0FABh ;# 
# 3124 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TXSTA equ 0FACh ;# 
# 3129 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TXSTA1 equ 0FACh ;# 
# 3380 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TXREG equ 0FADh ;# 
# 3385 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TXREG1 equ 0FADh ;# 
# 3392 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCREG equ 0FAEh ;# 
# 3397 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCREG1 equ 0FAEh ;# 
# 3404 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SPBRG equ 0FAFh ;# 
# 3409 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SPBRG1 equ 0FAFh ;# 
# 3416 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SPBRGH equ 0FB0h ;# 
# 3423 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
T3CON equ 0FB1h ;# 
# 3530 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR3 equ 0FB2h ;# 
# 3537 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR3L equ 0FB2h ;# 
# 3544 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR3H equ 0FB3h ;# 
# 3551 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ECCP1AS equ 0FB6h ;# 
# 3633 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PWM1CON equ 0FB7h ;# 
# 3703 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
BAUDCON equ 0FB8h ;# 
# 3708 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
BAUDCTL equ 0FB8h ;# 
# 3869 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PSTRCON equ 0FB9h ;# 
# 3913 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
VREFCON0 equ 0FBAh ;# 
# 3918 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
REFCON0 equ 0FBAh ;# 
# 3991 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
VREFCON1 equ 0FBBh ;# 
# 3996 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
REFCON1 equ 0FBBh ;# 
# 4123 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
VREFCON2 equ 0FBCh ;# 
# 4128 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
REFCON2 equ 0FBCh ;# 
# 4225 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CCP1CON equ 0FBDh ;# 
# 4307 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CCPR1 equ 0FBEh ;# 
# 4314 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CCPR1L equ 0FBEh ;# 
# 4321 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CCPR1H equ 0FBFh ;# 
# 4328 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADCON2 equ 0FC0h ;# 
# 4399 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADCON1 equ 0FC1h ;# 
# 4460 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADCON0 equ 0FC2h ;# 
# 4579 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADRES equ 0FC3h ;# 
# 4586 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADRESL equ 0FC3h ;# 
# 4593 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADRESH equ 0FC4h ;# 
# 4600 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPCON2 equ 0FC5h ;# 
# 4662 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPCON1 equ 0FC6h ;# 
# 4732 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPSTAT equ 0FC7h ;# 
# 4953 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPADD equ 0FC8h ;# 
# 4960 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPBUF equ 0FC9h ;# 
# 4967 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
T2CON equ 0FCAh ;# 
# 5038 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PR2 equ 0FCBh ;# 
# 5043 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
MEMCON equ 0FCBh ;# 
# 5148 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR2 equ 0FCCh ;# 
# 5155 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
T1CON equ 0FCDh ;# 
# 5258 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR1 equ 0FCEh ;# 
# 5265 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR1L equ 0FCEh ;# 
# 5272 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR1H equ 0FCFh ;# 
# 5279 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCON equ 0FD0h ;# 
# 5412 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
WDTCON equ 0FD1h ;# 
# 5440 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
OSCCON2 equ 0FD2h ;# 
# 5472 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
OSCCON equ 0FD3h ;# 
# 5555 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
T0CON equ 0FD5h ;# 
# 5625 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR0 equ 0FD6h ;# 
# 5632 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR0L equ 0FD6h ;# 
# 5639 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR0H equ 0FD7h ;# 
# 5646 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
STATUS equ 0FD8h ;# 
# 5717 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR2 equ 0FD9h ;# 
# 5724 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR2L equ 0FD9h ;# 
# 5731 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR2H equ 0FDAh ;# 
# 5738 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PLUSW2 equ 0FDBh ;# 
# 5745 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PREINC2 equ 0FDCh ;# 
# 5752 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTDEC2 equ 0FDDh ;# 
# 5759 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTINC2 equ 0FDEh ;# 
# 5766 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INDF2 equ 0FDFh ;# 
# 5773 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
BSR equ 0FE0h ;# 
# 5780 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR1 equ 0FE1h ;# 
# 5787 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR1L equ 0FE1h ;# 
# 5794 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR1H equ 0FE2h ;# 
# 5801 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PLUSW1 equ 0FE3h ;# 
# 5808 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PREINC1 equ 0FE4h ;# 
# 5815 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTDEC1 equ 0FE5h ;# 
# 5822 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTINC1 equ 0FE6h ;# 
# 5829 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INDF1 equ 0FE7h ;# 
# 5836 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
WREG equ 0FE8h ;# 
# 5848 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR0 equ 0FE9h ;# 
# 5855 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR0L equ 0FE9h ;# 
# 5862 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR0H equ 0FEAh ;# 
# 5869 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PLUSW0 equ 0FEBh ;# 
# 5876 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PREINC0 equ 0FECh ;# 
# 5883 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTDEC0 equ 0FEDh ;# 
# 5890 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTINC0 equ 0FEEh ;# 
# 5897 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INDF0 equ 0FEFh ;# 
# 5904 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INTCON3 equ 0FF0h ;# 
# 5996 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INTCON2 equ 0FF1h ;# 
# 6090 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INTCON equ 0FF2h ;# 
# 6226 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PROD equ 0FF3h ;# 
# 6233 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PRODL equ 0FF3h ;# 
# 6240 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PRODH equ 0FF4h ;# 
# 6247 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TABLAT equ 0FF5h ;# 
# 6256 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TBLPTR equ 0FF6h ;# 
# 6263 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TBLPTRL equ 0FF6h ;# 
# 6270 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TBLPTRH equ 0FF7h ;# 
# 6277 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TBLPTRU equ 0FF8h ;# 
# 6286 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PCLAT equ 0FF9h ;# 
# 6293 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PC equ 0FF9h ;# 
# 6300 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PCL equ 0FF9h ;# 
# 6307 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PCLATH equ 0FFAh ;# 
# 6314 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PCLATU equ 0FFBh ;# 
# 6321 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
STKPTR equ 0FFCh ;# 
# 6395 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TOS equ 0FFDh ;# 
# 6402 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TOSL equ 0FFDh ;# 
# 6409 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TOSH equ 0FFEh ;# 
# 6416 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TOSU equ 0FFFh ;# 
# 54 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SRCON0 equ 0F68h ;# 
# 125 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SRCON1 equ 0F69h ;# 
# 187 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CM2CON0 equ 0F6Bh ;# 
# 257 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CM2CON1 equ 0F6Ch ;# 
# 319 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CM1CON0 equ 0F6Dh ;# 
# 389 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPMSK equ 0F6Fh ;# 
# 394 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPMASK equ 0F6Fh ;# 
# 527 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SLRCON equ 0F76h ;# 
# 559 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
WPUA equ 0F77h ;# 
# 617 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
WPUB equ 0F78h ;# 
# 665 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
IOCA equ 0F79h ;# 
# 723 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
IOCB equ 0F7Ah ;# 
# 771 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ANSEL equ 0F7Eh ;# 
# 891 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ANSELH equ 0F7Fh ;# 
# 963 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PORTA equ 0F80h ;# 
# 1197 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PORTB equ 0F81h ;# 
# 1305 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PORTC equ 0F82h ;# 
# 1544 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
LATA equ 0F89h ;# 
# 1622 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
LATB equ 0F8Ah ;# 
# 1688 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
LATC equ 0F8Bh ;# 
# 1800 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TRISA equ 0F92h ;# 
# 1805 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
DDRA equ 0F92h ;# 
# 1954 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TRISB equ 0F93h ;# 
# 1959 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
DDRB equ 0F93h ;# 
# 2084 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TRISC equ 0F94h ;# 
# 2089 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
DDRC equ 0F94h ;# 
# 2306 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
OSCTUNE equ 0F9Bh ;# 
# 2376 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PIE1 equ 0F9Dh ;# 
# 2447 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PIR1 equ 0F9Eh ;# 
# 2518 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
IPR1 equ 0F9Fh ;# 
# 2589 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PIE2 equ 0FA0h ;# 
# 2650 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PIR2 equ 0FA1h ;# 
# 2711 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
IPR2 equ 0FA2h ;# 
# 2772 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
EECON1 equ 0FA6h ;# 
# 2838 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
EECON2 equ 0FA7h ;# 
# 2845 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
EEDATA equ 0FA8h ;# 
# 2852 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
EEADR equ 0FA9h ;# 
# 2914 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCSTA equ 0FABh ;# 
# 2919 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCSTA1 equ 0FABh ;# 
# 3124 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TXSTA equ 0FACh ;# 
# 3129 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TXSTA1 equ 0FACh ;# 
# 3380 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TXREG equ 0FADh ;# 
# 3385 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TXREG1 equ 0FADh ;# 
# 3392 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCREG equ 0FAEh ;# 
# 3397 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCREG1 equ 0FAEh ;# 
# 3404 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SPBRG equ 0FAFh ;# 
# 3409 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SPBRG1 equ 0FAFh ;# 
# 3416 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SPBRGH equ 0FB0h ;# 
# 3423 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
T3CON equ 0FB1h ;# 
# 3530 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR3 equ 0FB2h ;# 
# 3537 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR3L equ 0FB2h ;# 
# 3544 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR3H equ 0FB3h ;# 
# 3551 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ECCP1AS equ 0FB6h ;# 
# 3633 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PWM1CON equ 0FB7h ;# 
# 3703 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
BAUDCON equ 0FB8h ;# 
# 3708 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
BAUDCTL equ 0FB8h ;# 
# 3869 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PSTRCON equ 0FB9h ;# 
# 3913 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
VREFCON0 equ 0FBAh ;# 
# 3918 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
REFCON0 equ 0FBAh ;# 
# 3991 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
VREFCON1 equ 0FBBh ;# 
# 3996 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
REFCON1 equ 0FBBh ;# 
# 4123 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
VREFCON2 equ 0FBCh ;# 
# 4128 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
REFCON2 equ 0FBCh ;# 
# 4225 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CCP1CON equ 0FBDh ;# 
# 4307 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CCPR1 equ 0FBEh ;# 
# 4314 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CCPR1L equ 0FBEh ;# 
# 4321 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
CCPR1H equ 0FBFh ;# 
# 4328 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADCON2 equ 0FC0h ;# 
# 4399 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADCON1 equ 0FC1h ;# 
# 4460 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADCON0 equ 0FC2h ;# 
# 4579 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADRES equ 0FC3h ;# 
# 4586 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADRESL equ 0FC3h ;# 
# 4593 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
ADRESH equ 0FC4h ;# 
# 4600 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPCON2 equ 0FC5h ;# 
# 4662 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPCON1 equ 0FC6h ;# 
# 4732 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPSTAT equ 0FC7h ;# 
# 4953 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPADD equ 0FC8h ;# 
# 4960 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
SSPBUF equ 0FC9h ;# 
# 4967 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
T2CON equ 0FCAh ;# 
# 5038 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PR2 equ 0FCBh ;# 
# 5043 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
MEMCON equ 0FCBh ;# 
# 5148 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR2 equ 0FCCh ;# 
# 5155 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
T1CON equ 0FCDh ;# 
# 5258 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR1 equ 0FCEh ;# 
# 5265 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR1L equ 0FCEh ;# 
# 5272 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR1H equ 0FCFh ;# 
# 5279 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
RCON equ 0FD0h ;# 
# 5412 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
WDTCON equ 0FD1h ;# 
# 5440 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
OSCCON2 equ 0FD2h ;# 
# 5472 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
OSCCON equ 0FD3h ;# 
# 5555 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
T0CON equ 0FD5h ;# 
# 5625 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR0 equ 0FD6h ;# 
# 5632 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR0L equ 0FD6h ;# 
# 5639 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TMR0H equ 0FD7h ;# 
# 5646 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
STATUS equ 0FD8h ;# 
# 5717 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR2 equ 0FD9h ;# 
# 5724 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR2L equ 0FD9h ;# 
# 5731 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR2H equ 0FDAh ;# 
# 5738 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PLUSW2 equ 0FDBh ;# 
# 5745 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PREINC2 equ 0FDCh ;# 
# 5752 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTDEC2 equ 0FDDh ;# 
# 5759 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTINC2 equ 0FDEh ;# 
# 5766 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INDF2 equ 0FDFh ;# 
# 5773 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
BSR equ 0FE0h ;# 
# 5780 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR1 equ 0FE1h ;# 
# 5787 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR1L equ 0FE1h ;# 
# 5794 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR1H equ 0FE2h ;# 
# 5801 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PLUSW1 equ 0FE3h ;# 
# 5808 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PREINC1 equ 0FE4h ;# 
# 5815 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTDEC1 equ 0FE5h ;# 
# 5822 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTINC1 equ 0FE6h ;# 
# 5829 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INDF1 equ 0FE7h ;# 
# 5836 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
WREG equ 0FE8h ;# 
# 5848 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR0 equ 0FE9h ;# 
# 5855 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR0L equ 0FE9h ;# 
# 5862 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
FSR0H equ 0FEAh ;# 
# 5869 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PLUSW0 equ 0FEBh ;# 
# 5876 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PREINC0 equ 0FECh ;# 
# 5883 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTDEC0 equ 0FEDh ;# 
# 5890 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
POSTINC0 equ 0FEEh ;# 
# 5897 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INDF0 equ 0FEFh ;# 
# 5904 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INTCON3 equ 0FF0h ;# 
# 5996 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INTCON2 equ 0FF1h ;# 
# 6090 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
INTCON equ 0FF2h ;# 
# 6226 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PROD equ 0FF3h ;# 
# 6233 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PRODL equ 0FF3h ;# 
# 6240 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PRODH equ 0FF4h ;# 
# 6247 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TABLAT equ 0FF5h ;# 
# 6256 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TBLPTR equ 0FF6h ;# 
# 6263 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TBLPTRL equ 0FF6h ;# 
# 6270 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TBLPTRH equ 0FF7h ;# 
# 6277 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TBLPTRU equ 0FF8h ;# 
# 6286 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PCLAT equ 0FF9h ;# 
# 6293 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PC equ 0FF9h ;# 
# 6300 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PCL equ 0FF9h ;# 
# 6307 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PCLATH equ 0FFAh ;# 
# 6314 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
PCLATU equ 0FFBh ;# 
# 6321 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
STKPTR equ 0FFCh ;# 
# 6395 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TOS equ 0FFDh ;# 
# 6402 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TOSL equ 0FFDh ;# 
# 6409 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TOSH equ 0FFEh ;# 
# 6416 "C:\Program Files\Microchip\MPLABX\v6.20\packs\Microchip\PIC18F-K_DFP\1.13.292\xc8\pic\include\proc/pic18f14k22.h"
TOSU equ 0FFFh ;# 
	debug_source C
	FNCALL	_main,_Buttons_Init
	FNCALL	_main,_Buttons_Update
	FNCALL	_main,_Handle_Events
	FNCALL	_main,_Hardware_Init
	FNCALL	_main,_Millis
	FNCALL	_main,_OLED_Init
	FNCALL	_main,_Outputs_Off
	FNCALL	_main,_Show_Setup
	FNCALL	_main,_Show_Splash
	FNCALL	_main,_Update_Alarm
	FNCALL	_main,_Update_Countdown
	FNCALL	_Update_Countdown,_Finish_Countdown
	FNCALL	_Update_Countdown,_Show_Countdown
	FNCALL	_Update_Countdown,_Time_Decrement
	FNCALL	_Time_Decrement,_Time_IsZero
	FNCALL	_Finish_Countdown,_Show_Expired
	FNCALL	_Show_Expired,_OLED_Clear
	FNCALL	_Show_Expired,_OLED_WriteTextCenteredAtY
	FNCALL	_Show_Splash,_OLED_Clear
	FNCALL	_Show_Splash,_OLED_WriteTextCenteredAtY
	FNCALL	_OLED_Init,_I2C_Init
	FNCALL	_OLED_Init,_OLED_Clear
	FNCALL	_OLED_Init,_OLED_Command
	FNCALL	_OLED_Init,_OLED_DisplayOn
	FNCALL	_OLED_Init,_OLED_FindAddress
	FNCALL	_OLED_FindAddress,_I2C_AddressResponds
	FNCALL	_I2C_AddressResponds,_I2C_Start
	FNCALL	_I2C_AddressResponds,_I2C_Stop
	FNCALL	_I2C_AddressResponds,_I2C_Write
	FNCALL	_OLED_DisplayOn,_OLED_Command
	FNCALL	_Hardware_Init,_Timer0_Init
	FNCALL	_Handle_Events,_Buttons_ConsumeStartRelease
	FNCALL	_Handle_Events,_EEPROM_LoadTime
	FNCALL	_Handle_Events,_Outputs_Off
	FNCALL	_Handle_Events,_Pause_Countdown
	FNCALL	_Handle_Events,_Resume_Countdown
	FNCALL	_Handle_Events,_Show_Setup
	FNCALL	_Handle_Events,_Start_Countdown
	FNCALL	_Handle_Events,_Time_Adjust
	FNCALL	_Start_Countdown,_EEPROM_SaveTime
	FNCALL	_Start_Countdown,_Outputs_CountdownOn
	FNCALL	_Start_Countdown,_Show_Countdown
	FNCALL	_Start_Countdown,_Time_IsZero
	FNCALL	_EEPROM_SaveTime,_EEPROM_Check
	FNCALL	_EEPROM_SaveTime,_EEPROM_Write
	FNCALL	_Show_Setup,_OLED_Clear
	FNCALL	_Show_Setup,_OLED_WriteTextCenteredAtY
	FNCALL	_Show_Setup,_OLED_WriteTextDoubleCentered
	FNCALL	_Show_Setup,_Time_ToText
	FNCALL	_Resume_Countdown,_Outputs_CountdownOn
	FNCALL	_Resume_Countdown,_Show_Countdown
	FNCALL	_Pause_Countdown,_Show_Countdown
	FNCALL	_Show_Countdown,_OLED_Clear
	FNCALL	_Show_Countdown,_OLED_WriteTextCenteredAtY
	FNCALL	_Show_Countdown,_OLED_WriteTextDoubleCentered
	FNCALL	_Show_Countdown,_Time_ToText
	FNCALL	_Time_ToText,___lwdiv
	FNCALL	_Time_ToText,___lwmod
	FNCALL	_OLED_WriteTextDoubleCentered,_OLED_TextWidth
	FNCALL	_OLED_WriteTextDoubleCentered,_OLED_WriteTextDoublePage
	FNCALL	_OLED_WriteTextDoublePage,_OLED_Data
	FNCALL	_OLED_WriteTextDoublePage,_OLED_GetGlyph
	FNCALL	_OLED_WriteTextDoublePage,_OLED_ScaleGlyph
	FNCALL	_OLED_WriteTextDoublePage,_OLED_SetCursor
	FNCALL	_OLED_WriteTextCenteredAtY,_OLED_TextWidth
	FNCALL	_OLED_WriteTextCenteredAtY,_OLED_WriteTextAtY
	FNCALL	_OLED_WriteTextAtY,_OLED_Data
	FNCALL	_OLED_WriteTextAtY,_OLED_GetGlyph
	FNCALL	_OLED_WriteTextAtY,_OLED_SetCursor
	FNCALL	_OLED_Clear,_OLED_Fill
	FNCALL	_OLED_Fill,_OLED_Data
	FNCALL	_OLED_Fill,_OLED_SetCursor
	FNCALL	_OLED_SetCursor,_OLED_Command
	FNCALL	_OLED_Command,_I2C_Start
	FNCALL	_OLED_Command,_I2C_Stop
	FNCALL	_OLED_Command,_I2C_Write
	FNCALL	_OLED_Data,_I2C_Start
	FNCALL	_OLED_Data,_I2C_Stop
	FNCALL	_OLED_Data,_I2C_Write
	FNCALL	_I2C_Write,_I2C_WaitIdle
	FNCALL	_I2C_Stop,_I2C_WaitIdle
	FNCALL	_I2C_Start,_I2C_WaitIdle
	FNCALL	_EEPROM_LoadTime,_EEPROM_Check
	FNCALL	_EEPROM_LoadTime,_EEPROM_Read
	FNCALL	_Buttons_Update,_ReadButtonsRaw
	FNCALL	_Buttons_Init,_ReadButtonsRaw
	FNROOT	_main
	FNCALL	intlevel2,_InterruptServiceRoutine
	global	intlevel2
	FNROOT	intlevel2
	global	_oledAddress
psect	idataCOMRAM,class=CODE,space=0,delta=1,noexec
global __pidataCOMRAM
__pidataCOMRAM:
	file	"oled_i2c.c"
	line	24

;initializer for _oledAddress
	db	low(03Ch)
	global	_buttonMasks
psect	mediumconst,class=MEDIUMCONST,space=0,reloc=2,noexec
global __pmediumconst
__pmediumconst:
	db	0
	file	"main.c"
	line	92
_buttonMasks:
	db	low(01h)
	db	low(02h)
	db	low(04h)
	db	low(08h)
	global __end_of_buttonMasks
__end_of_buttonMasks:
	global	_font5x7
psect	mediumconst
	file	"oled_i2c.c"
	line	26
_font5x7:
	db	low(0)
	db	low(0)
	db	low(0)
	db	low(0)
	db	low(0)
	db	low(0)
	db	low(0)
	db	low(05Fh)
	db	low(0)
	db	low(0)
	db	low(0)
	db	low(07h)
	db	low(0)
	db	low(07h)
	db	low(0)
	db	low(014h)
	db	low(07Fh)
	db	low(014h)
	db	low(07Fh)
	db	low(014h)
	db	low(024h)
	db	low(02Ah)
	db	low(07Fh)
	db	low(02Ah)
	db	low(012h)
	db	low(023h)
	db	low(013h)
	db	low(08h)
	db	low(064h)
	db	low(062h)
	db	low(036h)
	db	low(049h)
	db	low(055h)
	db	low(022h)
	db	low(050h)
	db	low(0)
	db	low(05h)
	db	low(03h)
	db	low(0)
	db	low(0)
	db	low(0)
	db	low(01Ch)
	db	low(022h)
	db	low(041h)
	db	low(0)
	db	low(0)
	db	low(041h)
	db	low(022h)
	db	low(01Ch)
	db	low(0)
	db	low(014h)
	db	low(08h)
	db	low(03Eh)
	db	low(08h)
	db	low(014h)
	db	low(08h)
	db	low(08h)
	db	low(03Eh)
	db	low(08h)
	db	low(08h)
	db	low(0)
	db	low(050h)
	db	low(030h)
	db	low(0)
	db	low(0)
	db	low(08h)
	db	low(08h)
	db	low(08h)
	db	low(08h)
	db	low(08h)
	db	low(0)
	db	low(060h)
	db	low(060h)
	db	low(0)
	db	low(0)
	db	low(020h)
	db	low(010h)
	db	low(08h)
	db	low(04h)
	db	low(02h)
	db	low(03Eh)
	db	low(051h)
	db	low(049h)
	db	low(045h)
	db	low(03Eh)
	db	low(0)
	db	low(042h)
	db	low(07Fh)
	db	low(040h)
	db	low(0)
	db	low(042h)
	db	low(061h)
	db	low(051h)
	db	low(049h)
	db	low(046h)
	db	low(021h)
	db	low(041h)
	db	low(045h)
	db	low(04Bh)
	db	low(031h)
	db	low(018h)
	db	low(014h)
	db	low(012h)
	db	low(07Fh)
	db	low(010h)
	db	low(027h)
	db	low(045h)
	db	low(045h)
	db	low(045h)
	db	low(039h)
	db	low(03Ch)
	db	low(04Ah)
	db	low(049h)
	db	low(049h)
	db	low(030h)
	db	low(01h)
	db	low(071h)
	db	low(09h)
	db	low(05h)
	db	low(03h)
	db	low(036h)
	db	low(049h)
	db	low(049h)
	db	low(049h)
	db	low(036h)
	db	low(06h)
	db	low(049h)
	db	low(049h)
	db	low(029h)
	db	low(01Eh)
	db	low(0)
	db	low(036h)
	db	low(036h)
	db	low(0)
	db	low(0)
	db	low(0)
	db	low(056h)
	db	low(036h)
	db	low(0)
	db	low(0)
	db	low(08h)
	db	low(014h)
	db	low(022h)
	db	low(041h)
	db	low(0)
	db	low(014h)
	db	low(014h)
	db	low(014h)
	db	low(014h)
	db	low(014h)
	db	low(0)
	db	low(041h)
	db	low(022h)
	db	low(014h)
	db	low(08h)
	db	low(02h)
	db	low(01h)
	db	low(051h)
	db	low(09h)
	db	low(06h)
	db	low(032h)
	db	low(049h)
	db	low(079h)
	db	low(041h)
	db	low(03Eh)
	db	low(07Eh)
	db	low(011h)
	db	low(011h)
	db	low(011h)
	db	low(07Eh)
	db	low(07Fh)
	db	low(049h)
	db	low(049h)
	db	low(049h)
	db	low(036h)
	db	low(03Eh)
	db	low(041h)
	db	low(041h)
	db	low(041h)
	db	low(022h)
	db	low(07Fh)
	db	low(041h)
	db	low(041h)
	db	low(022h)
	db	low(01Ch)
	db	low(07Fh)
	db	low(049h)
	db	low(049h)
	db	low(049h)
	db	low(041h)
	db	low(07Fh)
	db	low(09h)
	db	low(09h)
	db	low(09h)
	db	low(01h)
	db	low(03Eh)
	db	low(041h)
	db	low(049h)
	db	low(049h)
	db	low(07Ah)
	db	low(07Fh)
	db	low(08h)
	db	low(08h)
	db	low(08h)
	db	low(07Fh)
	db	low(0)
	db	low(041h)
	db	low(07Fh)
	db	low(041h)
	db	low(0)
	db	low(020h)
	db	low(040h)
	db	low(041h)
	db	low(03Fh)
	db	low(01h)
	db	low(07Fh)
	db	low(08h)
	db	low(014h)
	db	low(022h)
	db	low(041h)
	db	low(07Fh)
	db	low(040h)
	db	low(040h)
	db	low(040h)
	db	low(040h)
	db	low(07Fh)
	db	low(02h)
	db	low(0Ch)
	db	low(02h)
	db	low(07Fh)
	db	low(07Fh)
	db	low(04h)
	db	low(08h)
	db	low(010h)
	db	low(07Fh)
	db	low(03Eh)
	db	low(041h)
	db	low(041h)
	db	low(041h)
	db	low(03Eh)
	db	low(07Fh)
	db	low(09h)
	db	low(09h)
	db	low(09h)
	db	low(06h)
	db	low(03Eh)
	db	low(041h)
	db	low(051h)
	db	low(021h)
	db	low(05Eh)
	db	low(07Fh)
	db	low(09h)
	db	low(019h)
	db	low(029h)
	db	low(046h)
	db	low(046h)
	db	low(049h)
	db	low(049h)
	db	low(049h)
	db	low(031h)
	db	low(01h)
	db	low(01h)
	db	low(07Fh)
	db	low(01h)
	db	low(01h)
	db	low(03Fh)
	db	low(040h)
	db	low(040h)
	db	low(040h)
	db	low(03Fh)
	db	low(01Fh)
	db	low(020h)
	db	low(040h)
	db	low(020h)
	db	low(01Fh)
	db	low(03Fh)
	db	low(040h)
	db	low(038h)
	db	low(040h)
	db	low(03Fh)
	db	low(063h)
	db	low(014h)
	db	low(08h)
	db	low(014h)
	db	low(063h)
	db	low(07h)
	db	low(08h)
	db	low(070h)
	db	low(08h)
	db	low(07h)
	db	low(061h)
	db	low(051h)
	db	low(049h)
	db	low(045h)
	db	low(043h)
	db	low(0)
	db	low(07Fh)
	db	low(041h)
	db	low(041h)
	db	low(0)
	db	low(02h)
	db	low(04h)
	db	low(08h)
	db	low(010h)
	db	low(020h)
	db	low(0)
	db	low(041h)
	db	low(041h)
	db	low(07Fh)
	db	low(0)
	db	low(04h)
	db	low(02h)
	db	low(01h)
	db	low(02h)
	db	low(04h)
	db	low(040h)
	db	low(040h)
	db	low(040h)
	db	low(040h)
	db	low(040h)
	db	low(0)
	db	low(01h)
	db	low(02h)
	db	low(04h)
	db	low(0)
	db	low(020h)
	db	low(054h)
	db	low(054h)
	db	low(054h)
	db	low(078h)
	db	low(07Fh)
	db	low(048h)
	db	low(044h)
	db	low(044h)
	db	low(038h)
	db	low(038h)
	db	low(044h)
	db	low(044h)
	db	low(044h)
	db	low(020h)
	db	low(038h)
	db	low(044h)
	db	low(044h)
	db	low(048h)
	db	low(07Fh)
	db	low(038h)
	db	low(054h)
	db	low(054h)
	db	low(054h)
	db	low(018h)
	db	low(08h)
	db	low(07Eh)
	db	low(09h)
	db	low(01h)
	db	low(02h)
	db	low(0Ch)
	db	low(052h)
	db	low(052h)
	db	low(052h)
	db	low(03Eh)
	db	low(07Fh)
	db	low(08h)
	db	low(04h)
	db	low(04h)
	db	low(078h)
	db	low(0)
	db	low(044h)
	db	low(07Dh)
	db	low(040h)
	db	low(0)
	db	low(020h)
	db	low(040h)
	db	low(044h)
	db	low(03Dh)
	db	low(0)
	db	low(07Fh)
	db	low(010h)
	db	low(028h)
	db	low(044h)
	db	low(0)
	db	low(0)
	db	low(041h)
	db	low(07Fh)
	db	low(040h)
	db	low(0)
	db	low(07Ch)
	db	low(04h)
	db	low(018h)
	db	low(04h)
	db	low(078h)
	db	low(07Ch)
	db	low(08h)
	db	low(04h)
	db	low(04h)
	db	low(078h)
	db	low(038h)
	db	low(044h)
	db	low(044h)
	db	low(044h)
	db	low(038h)
	db	low(07Ch)
	db	low(014h)
	db	low(014h)
	db	low(014h)
	db	low(08h)
	db	low(08h)
	db	low(014h)
	db	low(014h)
	db	low(018h)
	db	low(07Ch)
	db	low(07Ch)
	db	low(08h)
	db	low(04h)
	db	low(04h)
	db	low(08h)
	db	low(048h)
	db	low(054h)
	db	low(054h)
	db	low(054h)
	db	low(020h)
	db	low(04h)
	db	low(03Fh)
	db	low(044h)
	db	low(040h)
	db	low(020h)
	db	low(03Ch)
	db	low(040h)
	db	low(040h)
	db	low(020h)
	db	low(07Ch)
	db	low(01Ch)
	db	low(020h)
	db	low(040h)
	db	low(020h)
	db	low(01Ch)
	db	low(03Ch)
	db	low(040h)
	db	low(030h)
	db	low(040h)
	db	low(03Ch)
	db	low(044h)
	db	low(028h)
	db	low(010h)
	db	low(028h)
	db	low(044h)
	db	low(0Ch)
	db	low(050h)
	db	low(050h)
	db	low(050h)
	db	low(03Ch)
	db	low(044h)
	db	low(064h)
	db	low(054h)
	db	low(04Ch)
	db	low(044h)
	global __end_of_font5x7
__end_of_font5x7:
	global	_glyph_unknown
psect	mediumconst
	file	"oled_i2c.c"
	line	124
_glyph_unknown:
	db	low(02h)
	db	low(01h)
	db	low(051h)
	db	low(09h)
	db	low(06h)
	global __end_of_glyph_unknown
__end_of_glyph_unknown:
	global	_glyph_a_acute_lower
psect	mediumconst
	file	"oled_i2c.c"
	line	123
_glyph_a_acute_lower:
	db	low(03Ch)
	db	low(04Ah)
	db	low(049h)
	db	low(049h)
	db	low(07Ch)
	global __end_of_glyph_a_acute_lower
__end_of_glyph_a_acute_lower:
	global	_glyph_a_acute_upper
psect	mediumconst
	file	"oled_i2c.c"
	line	122
_glyph_a_acute_upper:
	db	low(07Eh)
	db	low(011h)
	db	low(011h)
	db	low(011h)
	db	low(07Fh)
	global __end_of_glyph_a_acute_upper
__end_of_glyph_a_acute_upper:
	global	_glyph_o_double_acute_lower
psect	mediumconst
	file	"oled_i2c.c"
	line	121
_glyph_o_double_acute_lower:
	db	low(038h)
	db	low(046h)
	db	low(044h)
	db	low(046h)
	db	low(038h)
	global __end_of_glyph_o_double_acute_lower
__end_of_glyph_o_double_acute_lower:
	global	_glyph_o_double_acute_upper
psect	mediumconst
	file	"oled_i2c.c"
	line	120
_glyph_o_double_acute_upper:
	db	low(03Eh)
	db	low(043h)
	db	low(041h)
	db	low(043h)
	db	low(03Eh)
	global __end_of_glyph_o_double_acute_upper
__end_of_glyph_o_double_acute_upper:
	global	_buttonMasks
	global	_font5x7
	global	_glyph_unknown
	global	_glyph_a_acute_lower
	global	_glyph_a_acute_upper
	global	_glyph_o_double_acute_lower
	global	_glyph_o_double_acute_upper
	global	_buttonDebounce
	global	_splashStartedAt
	global	_milliseconds
	global	_consumeStartRelease
	global	_startLongReported
	global	_buttonLastRaw
	global	_buttonStable
	global	_alarmOn
	global	_editField
	global	_appState
	global	_remainingTime
	global	_setTime
	global	Buttons_Update@F2596
	global	_startPressedAt
	global	_lastButtonPollAt
	global	_lastAlarmToggleAt
	global	_lastSecondAt
	global	_SSPBUF
_SSPBUF	set	0xFC9
	global	_SSPCON2bits
_SSPCON2bits	set	0xFC5
	global	_PIR1bits
_PIR1bits	set	0xF9E
	global	_ANSELHbits
_ANSELHbits	set	0xF7F
	global	_SSPADD
_SSPADD	set	0xFC8
	global	_SSPCON2
_SSPCON2	set	0xFC5
	global	_SSPCON1bits
_SSPCON1bits	set	0xFC6
	global	_SSPSTATbits
_SSPSTATbits	set	0xFC7
	global	_EECON2
_EECON2	set	0xFA7
	global	_EECON1bits
_EECON1bits	set	0xFA6
	global	_EEDATA
_EEDATA	set	0xFA8
	global	_EEADR
_EEADR	set	0xFA9
	global	_PORTAbits
_PORTAbits	set	0xF80
	global	_PORTBbits
_PORTBbits	set	0xF81
	global	_PORTCbits
_PORTCbits	set	0xF82
	global	_LATCbits
_LATCbits	set	0xF8B
	global	_T0CONbits
_T0CONbits	set	0xFD5
	global	_T0CON
_T0CON	set	0xFD5
	global	_RCONbits
_RCONbits	set	0xFD0
	global	_WPUBbits
_WPUBbits	set	0xF78
	global	_INTCON2bits
_INTCON2bits	set	0xFF1
	global	_TRISCbits
_TRISCbits	set	0xF94
	global	_TRISBbits
_TRISBbits	set	0xF93
	global	_TRISAbits
_TRISAbits	set	0xF92
	global	_TRISC
_TRISC	set	0xF94
	global	_TRISB
_TRISB	set	0xF93
	global	_TRISA
_TRISA	set	0xF92
	global	_LATC
_LATC	set	0xF8B
	global	_LATB
_LATB	set	0xF8A
	global	_LATA
_LATA	set	0xF89
	global	_CM2CON0
_CM2CON0	set	0xF6B
	global	_CM1CON0
_CM1CON0	set	0xF6D
	global	_ANSELH
_ANSELH	set	0xF7F
	global	_ANSEL
_ANSEL	set	0xF7E
	global	_TMR0L
_TMR0L	set	0xFD6
	global	_TMR0H
_TMR0H	set	0xFD7
	global	_INTCONbits
_INTCONbits	set	0xFF2
	
STR_2:
	db	98	;'b'
	db	105	;'i'
	db	103	;'g'
	db	121	;'y'
	db	117	;'u'
	db	115	;'s'
	db	122	;'z'
	db	64	;'@'
	db	116	;'t'
	db	45
	db	111	;'o'
	db	110	;'n'
	db	108	;'l'
	db	105	;'i'
	db	110	;'n'
	db	101	;'e'
	db	46
	db	104	;'h'
	db	117	;'u'
	db	0
	
STR_6:
	db	65	;'A'
	db	68	;'D'
	db	68	;'D'
	db	32
	db	77	;'M'
	db	69	;'E'
	db	71	;'G'
	db	32
	db	65	;'A'
	db	90	;'Z'
	db	32
	db	73	;'I'
	db	68	;'D'
	db	-59
	db	-112
	db	84	;'T'
	db	0
	
STR_8:
	db	78	;'N'
	db	89	;'Y'
	db	79	;'O'
	db	77	;'M'
	db	74	;'J'
	db	32
	db	77	;'M'
	db	69	;'E'
	db	71	;'G'
	db	32
	db	71	;'G'
	db	79	;'O'
	db	77	;'M'
	db	66	;'B'
	db	79	;'O'
	db	84	;'T'
	db	0
	
STR_7:
	db	76	;'L'
	db	69	;'E'
	db	74	;'J'
	db	-61
	db	-127
	db	82	;'R'
	db	84	;'T'
	db	32
	db	65	;'A'
	db	90	;'Z'
	db	32
	db	73	;'I'
	db	68	;'D'
	db	-59
	db	-112
	db	0
	
STR_9:
	db	86	;'V'
	db	73	;'I'
	db	83	;'S'
	db	83	;'S'
	db	90	;'Z'
	db	65	;'A'
	db	83	;'S'
	db	90	;'Z'
	db	65	;'A'
	db	77	;'M'
	db	76	;'L'
	db	65	;'A'
	db	76	;'L'
	db	65	;'A'
	db	83	;'S'
	db	0
	
STR_1:
	db	83	;'S'
	db	90	;'Z'
	db	69	;'E'
	db	77	;'M'
	db	69	;'E'
	db	83	;'S'
	db	32
	db	65	;'A'
	db	84	;'T'
	db	84	;'T'
	db	73	;'I'
	db	76	;'L'
	db	65	;'A'
	db	0
	
STR_10:
	db	83	;'S'
	db	90	;'Z'
	db	85	;'U'
	db	78	;'N'
	db	69	;'E'
	db	84	;'T'
	db	0
	
STR_4:
	db	80	;'P'
	db	69	;'E'
	db	82	;'R'
	db	67	;'C'
	db	0
	
STR_3:
	db	79	;'O'
	db	82	;'R'
	db	65	;'A'
	db	0
	
STR_5:
	db	77	;'M'
	db	80	;'P'
	db	0
STR_11	equ	STR_9+0
STR_12	equ	STR_9+0
; #config settings
	config pad_punits      = on
	config apply_mask      = off
	config ignore_cmsgs    = off
	config default_configs = off
	config default_idlocs  = off
	config FOSC = "HS"
	config PLLEN = "OFF"
	config PCLKEN = "ON"
	config FCMEN = "OFF"
	config IESO = "OFF"
	config PWRTEN = "ON"
	config BOREN = "OFF"
	config BORV = "19"
	config WDTEN = "OFF"
	config MCLRE = "ON"
	config STVREN = "ON"
	config LVP = "OFF"
	config XINST = "OFF"
	file	"build_check.s"
	line	#
psect	cinit,class=CODE,delta=1,reloc=2
global __pcinit
__pcinit:
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bssCOMRAM,class=COMRAM,space=1,noexec,lowdata
global __pbssCOMRAM
__pbssCOMRAM:
_buttonDebounce:
       ds      4
_splashStartedAt:
       ds      4
_milliseconds:
       ds      4
_consumeStartRelease:
       ds      1
_startLongReported:
       ds      1
_buttonLastRaw:
       ds      1
_buttonStable:
       ds      1
_alarmOn:
       ds      1
_editField:
       ds      1
_appState:
       ds      1
_remainingTime:
       ds      3
_setTime:
       ds      3
psect	dataCOMRAM,class=COMRAM,space=1,noexec,lowdata
global __pdataCOMRAM
__pdataCOMRAM:
	file	"oled_i2c.c"
	line	24
_oledAddress:
       ds      1
psect	bssBANK0,class=BANK0,space=1,noexec,lowdata
global __pbssBANK0
__pbssBANK0:
Buttons_Update@F2596:
       ds      5
_startPressedAt:
       ds      4
_lastButtonPollAt:
       ds      4
_lastAlarmToggleAt:
       ds      4
_lastSecondAt:
       ds      4
	file	"build_check.s"
	line	#
psect	cinit
; Initialize objects allocated to COMRAM (1 bytes)
	global __pidataCOMRAM
	; load TBLPTR registers with __pidataCOMRAM
	movlw	low (__pidataCOMRAM)
	movwf	tblptrl
	movlw	high(__pidataCOMRAM)
	movwf	tblptrh
	movlw	low highword(__pidataCOMRAM)
	movwf	tblptru
	tblrd*+ ;fetch initializer
	movff	tablat, __pdataCOMRAM+0		
	line	#
; Clear objects allocated to BANK0 (21 bytes)
	global __pbssBANK0
lfsr	0,__pbssBANK0
movlw	21
clear_0:
clrf	postinc0,c
decf	wreg
bnz	clear_0
; Clear objects allocated to COMRAM (25 bytes)
	global __pbssCOMRAM
lfsr	0,__pbssCOMRAM
movlw	25
clear_1:
clrf	postinc0,c
decf	wreg
bnz	clear_1
psect cinit,class=CODE,delta=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
	bcf int$flags,0,c ;clear compiler interrupt flag (level 1)
	bcf int$flags,1,c ;clear compiler interrupt flag (level 2)
	GLOBAL	__Lmediumconst
	movlw	low highword(__Lmediumconst)
	movwf	tblptru
movlb 0
goto _main	;jump to C main() function
psect	cstackCOMRAM,class=COMRAM,space=1,noexec,lowdata
global __pcstackCOMRAM
__pcstackCOMRAM:
?_Hardware_Init:	; 1 bytes @ 0x0
?_OLED_Init:	; 1 bytes @ 0x0
?_Outputs_Off:	; 1 bytes @ 0x0
?_Show_Splash:	; 1 bytes @ 0x0
?_Show_Setup:	; 1 bytes @ 0x0
?_Update_Alarm:	; 1 bytes @ 0x0
?_Timer0_Init:	; 1 bytes @ 0x0
?_OLED_Clear:	; 1 bytes @ 0x0
?_I2C_Init:	; 1 bytes @ 0x0
?_OLED_FindAddress:	; 1 bytes @ 0x0
?_OLED_Command:	; 1 bytes @ 0x0
?_OLED_DisplayOn:	; 1 bytes @ 0x0
?_OLED_Fill:	; 1 bytes @ 0x0
?_OLED_Data:	; 1 bytes @ 0x0
?_OLED_TextWidth:	; 1 bytes @ 0x0
?_I2C_Start:	; 1 bytes @ 0x0
?_I2C_Write:	; 1 bytes @ 0x0
?_I2C_Stop:	; 1 bytes @ 0x0
?_I2C_WaitIdle:	; 1 bytes @ 0x0
?_InterruptServiceRoutine:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Outputs_CountdownOn:	; 1 bytes @ 0x0
?_ReadButtonsRaw:	; 1 bytes @ 0x0
?_Buttons_ConsumeStartRelease:	; 1 bytes @ 0x0
?_Time_IsZero:	; 1 bytes @ 0x0
?_Time_Adjust:	; 1 bytes @ 0x0
?_EEPROM_Read:	; 1 bytes @ 0x0
?_EEPROM_Check:	; 1 bytes @ 0x0
?_Show_Expired:	; 1 bytes @ 0x0
?_Pause_Countdown:	; 1 bytes @ 0x0
?_OLED_ScaleGlyph:	; 1 bytes @ 0x0
?_I2C_AddressResponds:	; 1 bytes @ 0x0
	global	?_OLED_GetGlyph
?_OLED_GetGlyph:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	?_Millis
?_Millis:	; 4 bytes @ 0x0
	global	ReadButtonsRaw@value
ReadButtonsRaw@value:	; 1 bytes @ 0x0
	global	Time_IsZero@time
Time_IsZero@time:	; 1 bytes @ 0x0
	global	Time_Adjust@increment
Time_Adjust@increment:	; 1 bytes @ 0x0
	global	EEPROM_Read@address
EEPROM_Read@address:	; 1 bytes @ 0x0
	global	EEPROM_Check@time
EEPROM_Check@time:	; 1 bytes @ 0x0
	global	OLED_ScaleGlyph@lowerPage
OLED_ScaleGlyph@lowerPage:	; 1 bytes @ 0x0
	global	OLED_GetGlyph@text
OLED_GetGlyph@text:	; 1 bytes @ 0x0
	global	OLED_TextWidth@text
OLED_TextWidth@text:	; 2 bytes @ 0x0
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x0
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x0
	global	Update_Alarm@now
Update_Alarm@now:	; 4 bytes @ 0x0
??_Hardware_Init:	; 1 bytes @ 0x0
??_Outputs_Off:	; 1 bytes @ 0x0
??_Timer0_Init:	; 1 bytes @ 0x0
??_I2C_Init:	; 1 bytes @ 0x0
??_I2C_WaitIdle:	; 1 bytes @ 0x0
??_InterruptServiceRoutine:	; 1 bytes @ 0x0
??_Outputs_CountdownOn:	; 1 bytes @ 0x0
??_ReadButtonsRaw:	; 1 bytes @ 0x0
??_Buttons_ConsumeStartRelease:	; 1 bytes @ 0x0
??_EEPROM_Read:	; 1 bytes @ 0x0
	ds   1
?_Buttons_Init:	; 1 bytes @ 0x1
	global	?_Buttons_Update
?_Buttons_Update:	; 5 bytes @ 0x1
	global	_Time_IsZero$947
_Time_IsZero$947:	; 1 bytes @ 0x1
	global	I2C_Write@data
I2C_Write@data:	; 1 bytes @ 0x1
	global	Buttons_Init@now
Buttons_Init@now:	; 4 bytes @ 0x1
	global	Buttons_Update@now
Buttons_Update@now:	; 4 bytes @ 0x1
??_I2C_Start:	; 1 bytes @ 0x1
??_I2C_Write:	; 1 bytes @ 0x1
??_I2C_Stop:	; 1 bytes @ 0x1
??_Time_IsZero:	; 1 bytes @ 0x1
??_Time_Adjust:	; 1 bytes @ 0x1
??_EEPROM_Check:	; 1 bytes @ 0x1
??_OLED_ScaleGlyph:	; 1 bytes @ 0x1
	ds   1
?_Time_Decrement:	; 1 bytes @ 0x2
	global	Time_Decrement@time
Time_Decrement@time:	; 1 bytes @ 0x2
	global	Time_Adjust@field
Time_Adjust@field:	; 1 bytes @ 0x2
	global	OLED_Command@command
OLED_Command@command:	; 1 bytes @ 0x2
	global	OLED_Data@data
OLED_Data@data:	; 1 bytes @ 0x2
	global	I2C_AddressResponds@address
I2C_AddressResponds@address:	; 1 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
??_OLED_Command:	; 1 bytes @ 0x2
??_OLED_Data:	; 1 bytes @ 0x2
??_OLED_GetGlyph:	; 1 bytes @ 0x2
??_OLED_TextWidth:	; 1 bytes @ 0x2
??_I2C_AddressResponds:	; 1 bytes @ 0x2
	ds   1
?_OLED_SetCursor:	; 1 bytes @ 0x3
?_EEPROM_Write:	; 1 bytes @ 0x3
?_EEPROM_LoadTime:	; 1 bytes @ 0x3
	global	Time_Adjust@maximum
Time_Adjust@maximum:	; 1 bytes @ 0x3
	global	EEPROM_Write@value
EEPROM_Write@value:	; 1 bytes @ 0x3
	global	EEPROM_LoadTime@time
EEPROM_LoadTime@time:	; 1 bytes @ 0x3
	global	OLED_SetCursor@page
OLED_SetCursor@page:	; 1 bytes @ 0x3
	global	OLED_ScaleGlyph@glyphColumn
OLED_ScaleGlyph@glyphColumn:	; 1 bytes @ 0x3
	global	I2C_AddressResponds@acknowledged
I2C_AddressResponds@acknowledged:	; 1 bytes @ 0x3
??_OLED_DisplayOn:	; 1 bytes @ 0x3
??_Time_Decrement:	; 1 bytes @ 0x3
	ds   1
	global	Time_Adjust@value
Time_Adjust@value:	; 1 bytes @ 0x4
	global	EEPROM_Write@address
EEPROM_Write@address:	; 1 bytes @ 0x4
	global	OLED_SetCursor@column
OLED_SetCursor@column:	; 1 bytes @ 0x4
	global	OLED_TextWidth@width
OLED_TextWidth@width:	; 1 bytes @ 0x4
	global	OLED_ScaleGlyph@result
OLED_ScaleGlyph@result:	; 1 bytes @ 0x4
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x4
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x4
	global	Millis@result
Millis@result:	; 4 bytes @ 0x4
??_Millis:	; 1 bytes @ 0x4
??_Update_Alarm:	; 1 bytes @ 0x4
??_OLED_FindAddress:	; 1 bytes @ 0x4
??_OLED_SetCursor:	; 1 bytes @ 0x4
??___lwdiv:	; 1 bytes @ 0x4
??___lwmod:	; 1 bytes @ 0x4
??_EEPROM_Write:	; 1 bytes @ 0x4
??_EEPROM_LoadTime:	; 1 bytes @ 0x4
	ds   1
	global	EEPROM_Write@interruptsEnabled
EEPROM_Write@interruptsEnabled:	; 1 bytes @ 0x5
	global	EEPROM_LoadTime@magic
EEPROM_LoadTime@magic:	; 1 bytes @ 0x5
	global	OLED_Fill@pattern
OLED_Fill@pattern:	; 1 bytes @ 0x5
	global	OLED_ScaleGlyph@targetBit
OLED_ScaleGlyph@targetBit:	; 1 bytes @ 0x5
??_Buttons_Init:	; 1 bytes @ 0x5
??_OLED_Fill:	; 1 bytes @ 0x5
	ds   1
?_EEPROM_SaveTime:	; 1 bytes @ 0x6
	global	EEPROM_SaveTime@time
EEPROM_SaveTime@time:	; 1 bytes @ 0x6
	global	OLED_Fill@column
OLED_Fill@column:	; 1 bytes @ 0x6
	global	OLED_ScaleGlyph@row
OLED_ScaleGlyph@row:	; 1 bytes @ 0x6
	global	OLED_GetGlyph@c
OLED_GetGlyph@c:	; 1 bytes @ 0x6
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x6
??_Buttons_Update:	; 1 bytes @ 0x6
	ds   1
?_OLED_WriteTextAtY:	; 1 bytes @ 0x7
?_OLED_WriteTextDoublePage:	; 1 bytes @ 0x7
?_Time_ToText:	; 1 bytes @ 0x7
	global	Time_ToText@time
Time_ToText@time:	; 1 bytes @ 0x7
	global	OLED_Fill@page
OLED_Fill@page:	; 1 bytes @ 0x7
	global	OLED_WriteTextAtY@y
OLED_WriteTextAtY@y:	; 1 bytes @ 0x7
	global	OLED_WriteTextDoublePage@page
OLED_WriteTextDoublePage@page:	; 1 bytes @ 0x7
??_EEPROM_SaveTime:	; 1 bytes @ 0x7
	ds   1
	global	Millis@interruptsEnabled
Millis@interruptsEnabled:	; 1 bytes @ 0x8
	global	Time_ToText@text
Time_ToText@text:	; 1 bytes @ 0x8
	global	OLED_WriteTextDoublePage@text
OLED_WriteTextDoublePage@text:	; 1 bytes @ 0x8
	global	OLED_WriteTextAtY@text
OLED_WriteTextAtY@text:	; 2 bytes @ 0x8
??_OLED_Init:	; 1 bytes @ 0x8
??_OLED_Clear:	; 1 bytes @ 0x8
	ds   1
	global	OLED_WriteTextDoublePage@lowerPage
OLED_WriteTextDoublePage@lowerPage:	; 1 bytes @ 0x9
??_Time_ToText:	; 1 bytes @ 0x9
	ds   1
	global	Buttons_Update@raw
Buttons_Update@raw:	; 1 bytes @ 0xA
??_OLED_WriteTextAtY:	; 1 bytes @ 0xA
??_OLED_WriteTextDoublePage:	; 1 bytes @ 0xA
	ds   1
	global	Buttons_Update@lastPressed
Buttons_Update@lastPressed:	; 1 bytes @ 0xB
	ds   1
	global	Buttons_Update@stablePressed
Buttons_Update@stablePressed:	; 1 bytes @ 0xC
	global	OLED_WriteTextDoublePage@glyph
OLED_WriteTextDoublePage@glyph:	; 2 bytes @ 0xC
	ds   1
	global	_Buttons_Update$940
_Buttons_Update$940:	; 1 bytes @ 0xD
	ds   1
	global	Buttons_Update@rawPressed
Buttons_Update@rawPressed:	; 1 bytes @ 0xE
	global	OLED_WriteTextAtY@column
OLED_WriteTextAtY@column:	; 1 bytes @ 0xE
	global	OLED_WriteTextDoublePage@column
OLED_WriteTextDoublePage@column:	; 1 bytes @ 0xE
	ds   1
	global	Buttons_Update@index
Buttons_Update@index:	; 1 bytes @ 0xF
	global	OLED_WriteTextDoublePage@scaledColumn
OLED_WriteTextDoublePage@scaledColumn:	; 1 bytes @ 0xF
	global	OLED_WriteTextAtY@glyph
OLED_WriteTextAtY@glyph:	; 2 bytes @ 0xF
	ds   1
	global	OLED_WriteTextDoublePage@index
OLED_WriteTextDoublePage@index:	; 1 bytes @ 0x10
	global	Buttons_Update@events
Buttons_Update@events:	; 5 bytes @ 0x10
	ds   1
	global	OLED_WriteTextAtY@shift
OLED_WriteTextAtY@shift:	; 1 bytes @ 0x11
	global	OLED_WriteTextDoublePage@pointer
OLED_WriteTextDoublePage@pointer:	; 2 bytes @ 0x11
	ds   1
	global	OLED_WriteTextAtY@page
OLED_WriteTextAtY@page:	; 1 bytes @ 0x12
	ds   1
?_OLED_WriteTextDoubleCentered:	; 1 bytes @ 0x13
	global	OLED_WriteTextDoubleCentered@text
OLED_WriteTextDoubleCentered@text:	; 1 bytes @ 0x13
	global	OLED_WriteTextAtY@index
OLED_WriteTextAtY@index:	; 1 bytes @ 0x13
	ds   1
	global	OLED_WriteTextAtY@pointer
OLED_WriteTextAtY@pointer:	; 2 bytes @ 0x14
??_OLED_WriteTextDoubleCentered:	; 1 bytes @ 0x14
	ds   1
	global	Buttons_Update@mask
Buttons_Update@mask:	; 1 bytes @ 0x15
	ds   1
?_OLED_WriteTextCenteredAtY:	; 1 bytes @ 0x16
	global	OLED_WriteTextCenteredAtY@text
OLED_WriteTextCenteredAtY@text:	; 2 bytes @ 0x16
	ds   2
	global	OLED_WriteTextDoubleCentered@width
OLED_WriteTextDoubleCentered@width:	; 1 bytes @ 0x18
??_OLED_WriteTextCenteredAtY:	; 1 bytes @ 0x18
	ds   1
	global	OLED_WriteTextDoubleCentered@column
OLED_WriteTextDoubleCentered@column:	; 1 bytes @ 0x19
	ds   1
	global	OLED_WriteTextDoubleCentered@page
OLED_WriteTextDoubleCentered@page:	; 1 bytes @ 0x1A
	ds   2
	global	OLED_WriteTextCenteredAtY@y
OLED_WriteTextCenteredAtY@y:	; 1 bytes @ 0x1C
	ds   1
	global	OLED_WriteTextCenteredAtY@column
OLED_WriteTextCenteredAtY@column:	; 1 bytes @ 0x1D
	ds   1
	global	OLED_WriteTextCenteredAtY@width
OLED_WriteTextCenteredAtY@width:	; 1 bytes @ 0x1E
	ds   1
?_Show_Countdown:	; 1 bytes @ 0x1F
?_Finish_Countdown:	; 1 bytes @ 0x1F
	global	Show_Countdown@title
Show_Countdown@title:	; 2 bytes @ 0x1F
	global	Finish_Countdown@now
Finish_Countdown@now:	; 4 bytes @ 0x1F
	global	Show_Setup@text
Show_Setup@text:	; 9 bytes @ 0x1F
??_Show_Splash:	; 1 bytes @ 0x1F
??_Show_Setup:	; 1 bytes @ 0x1F
??_Show_Expired:	; 1 bytes @ 0x1F
	ds   2
	global	Show_Countdown@text
Show_Countdown@text:	; 9 bytes @ 0x21
??_Show_Countdown:	; 1 bytes @ 0x21
	ds   2
??_Finish_Countdown:	; 1 bytes @ 0x23
	ds   5
	global	Show_Setup@fieldName
Show_Setup@fieldName:	; 2 bytes @ 0x28
	ds   2
?_Update_Countdown:	; 1 bytes @ 0x2A
?_Start_Countdown:	; 1 bytes @ 0x2A
?_Resume_Countdown:	; 1 bytes @ 0x2A
	global	Start_Countdown@now
Start_Countdown@now:	; 4 bytes @ 0x2A
	global	Resume_Countdown@now
Resume_Countdown@now:	; 4 bytes @ 0x2A
	global	Update_Countdown@now
Update_Countdown@now:	; 4 bytes @ 0x2A
??_Pause_Countdown:	; 1 bytes @ 0x2A
	ds   4
?_Handle_Events:	; 1 bytes @ 0x2E
	global	Handle_Events@events
Handle_Events@events:	; 1 bytes @ 0x2E
??_Update_Countdown:	; 1 bytes @ 0x2E
??_Start_Countdown:	; 1 bytes @ 0x2E
??_Resume_Countdown:	; 1 bytes @ 0x2E
	ds   1
	global	Handle_Events@now
Handle_Events@now:	; 4 bytes @ 0x2F
	ds   3
	global	Update_Countdown@displayNeedsUpdate
Update_Countdown@displayNeedsUpdate:	; 1 bytes @ 0x32
	ds   1
	global	Handle_Events@storedTime
Handle_Events@storedTime:	; 3 bytes @ 0x33
??_Handle_Events:	; 1 bytes @ 0x33
	ds   3
??_main:	; 1 bytes @ 0x36
	ds   4
	global	main@events
main@events:	; 5 bytes @ 0x3A
	ds   5
	global	main@now
main@now:	; 4 bytes @ 0x3F
	ds   4
;!
;!Data Sizes:
;!    Strings     119
;!    Constant    484
;!    Data        1
;!    BSS         46
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMRAM           94     67      93
;!    BANK0           160      0      21
;!    BANK1           256      0       0

;!
;!Pointer List with Targets:
;!
;!    EEPROM_Check@time	PTR const struct . size(1) Largest target is 3
;!		 -> Handle_Events@storedTime(COMRAM[3]), setTime(COMRAM[3]), 
;!
;!    EEPROM_LoadTime@time	PTR struct . size(1) Largest target is 3
;!		 -> Handle_Events@storedTime(COMRAM[3]), 
;!
;!    EEPROM_SaveTime@time	PTR const struct . size(1) Largest target is 3
;!		 -> setTime(COMRAM[3]), 
;!
;!    Handle_Events@events	PTR const struct . size(1) Largest target is 5
;!		 -> main@events(COMRAM[5]), 
;!
;!    OLED_GetGlyph@text	PTR PTR const unsigned char  size(1) Largest target is 2
;!		 -> OLED_WriteText@text(COMRAM[2]), OLED_WriteTextAtY@pointer(COMRAM[2]), OLED_WriteTextDoublePage@pointer(COMRAM[2]), 
;!
;!    OLED_TextWidth@text	PTR const unsigned char  size(2) Largest target is 20
;!		 -> Show_Countdown@text(COMRAM[9]), Show_Setup@text(COMRAM[9]), STR_1(CODE[14]), STR_10(CODE[7]), 
;!		 -> STR_11(CODE[16]), STR_12(CODE[16]), STR_2(CODE[20]), STR_3(CODE[4]), 
;!		 -> STR_4(CODE[5]), STR_5(CODE[3]), STR_6(CODE[17]), STR_7(CODE[16]), 
;!		 -> STR_8(CODE[17]), STR_9(CODE[16]), 
;!
;!    OLED_WriteTextAtY@glyph	PTR const unsigned char  size(2) Largest target is 455
;!		 -> font5x7(CODE[455]), glyph_a_acute_lower(CODE[5]), glyph_a_acute_upper(CODE[5]), glyph_o_double_acute_lower(CODE[5]), 
;!		 -> glyph_o_double_acute_upper(CODE[5]), glyph_unknown(CODE[5]), 
;!
;!    OLED_WriteTextAtY@pointer	PTR const unsigned char  size(2) Largest target is 20
;!		 -> Show_Countdown@text(COMRAM[9]), Show_Setup@text(COMRAM[9]), STR_1(CODE[14]), STR_10(CODE[7]), 
;!		 -> STR_11(CODE[16]), STR_12(CODE[16]), STR_2(CODE[20]), STR_3(CODE[4]), 
;!		 -> STR_4(CODE[5]), STR_5(CODE[3]), STR_6(CODE[17]), STR_7(CODE[16]), 
;!		 -> STR_8(CODE[17]), STR_9(CODE[16]), 
;!
;!    OLED_WriteTextAtY@text	PTR const unsigned char  size(2) Largest target is 20
;!		 -> STR_1(CODE[14]), STR_10(CODE[7]), STR_11(CODE[16]), STR_12(CODE[16]), 
;!		 -> STR_2(CODE[20]), STR_3(CODE[4]), STR_4(CODE[5]), STR_5(CODE[3]), 
;!		 -> STR_6(CODE[17]), STR_7(CODE[16]), STR_8(CODE[17]), STR_9(CODE[16]), 
;!
;!    OLED_WriteTextCenteredAtY@text	PTR const unsigned char  size(2) Largest target is 20
;!		 -> STR_1(CODE[14]), STR_10(CODE[7]), STR_11(CODE[16]), STR_12(CODE[16]), 
;!		 -> STR_2(CODE[20]), STR_3(CODE[4]), STR_4(CODE[5]), STR_5(CODE[3]), 
;!		 -> STR_6(CODE[17]), STR_7(CODE[16]), STR_8(CODE[17]), STR_9(CODE[16]), 
;!
;!    OLED_WriteTextDoubleCentered@text	PTR const unsigned char  size(1) Largest target is 9
;!		 -> Show_Countdown@text(COMRAM[9]), Show_Setup@text(COMRAM[9]), 
;!
;!    OLED_WriteTextDoublePage@glyph	PTR const unsigned char  size(2) Largest target is 455
;!		 -> font5x7(CODE[455]), glyph_a_acute_lower(CODE[5]), glyph_a_acute_upper(CODE[5]), glyph_o_double_acute_lower(CODE[5]), 
;!		 -> glyph_o_double_acute_upper(CODE[5]), glyph_unknown(CODE[5]), 
;!
;!    OLED_WriteTextDoublePage@pointer	PTR const unsigned char  size(2) Largest target is 20
;!		 -> Show_Countdown@text(COMRAM[9]), Show_Setup@text(COMRAM[9]), STR_1(CODE[14]), STR_10(CODE[7]), 
;!		 -> STR_11(CODE[16]), STR_12(CODE[16]), STR_2(CODE[20]), STR_3(CODE[4]), 
;!		 -> STR_4(CODE[5]), STR_5(CODE[3]), STR_6(CODE[17]), STR_7(CODE[16]), 
;!		 -> STR_8(CODE[17]), STR_9(CODE[16]), 
;!
;!    OLED_WriteTextDoublePage@text	PTR const unsigned char  size(1) Largest target is 9
;!		 -> Show_Countdown@text(COMRAM[9]), Show_Setup@text(COMRAM[9]), 
;!
;!    Show_Countdown@title	PTR const unsigned char  size(2) Largest target is 16
;!		 -> STR_10(CODE[7]), STR_11(CODE[16]), STR_12(CODE[16]), STR_9(CODE[16]), 
;!
;!    Show_Setup@fieldName	PTR const unsigned char  size(2) Largest target is 5
;!		 -> STR_3(CODE[4]), STR_4(CODE[5]), STR_5(CODE[3]), 
;!
;!    sp__OLED_GetGlyph	PTR const unsigned char  size(2) Largest target is 455
;!		 -> font5x7(CODE[455]), glyph_a_acute_lower(CODE[5]), glyph_a_acute_upper(CODE[5]), glyph_o_double_acute_lower(CODE[5]), 
;!		 -> glyph_o_double_acute_upper(CODE[5]), glyph_unknown(CODE[5]), 
;!
;!    Time_Adjust@value	PTR unsigned char  size(1) Largest target is 3
;!		 -> setTime(COMRAM[3]), setTime$hour(COMRAM[1]), setTime$minute(COMRAM[1]), setTime$second(COMRAM[1]), 
;!
;!    Time_Decrement@time	PTR struct . size(1) Largest target is 3
;!		 -> remainingTime(COMRAM[3]), 
;!
;!    Time_IsZero@time	PTR const struct . size(1) Largest target is 3
;!		 -> remainingTime(COMRAM[3]), setTime(COMRAM[3]), 
;!
;!    Time_ToText@text	PTR unsigned char  size(1) Largest target is 9
;!		 -> Show_Countdown@text(COMRAM[9]), Show_Setup@text(COMRAM[9]), 
;!
;!    Time_ToText@time	PTR const struct . size(1) Largest target is 3
;!		 -> remainingTime(COMRAM[3]), setTime(COMRAM[3]), 
;!


;!
;!Critical Paths under _main in COMRAM
;!
;!    _main->_Handle_Events
;!    _Update_Countdown->_Show_Countdown
;!    _Time_Decrement->_Time_IsZero
;!    _Show_Expired->_OLED_WriteTextCenteredAtY
;!    _Show_Splash->_OLED_WriteTextCenteredAtY
;!    _OLED_FindAddress->_I2C_AddressResponds
;!    _I2C_AddressResponds->_I2C_Write
;!    _OLED_DisplayOn->_OLED_Command
;!    _Handle_Events->_Resume_Countdown
;!    _Handle_Events->_Start_Countdown
;!    _Start_Countdown->_Show_Countdown
;!    _EEPROM_SaveTime->_EEPROM_Write
;!    _EEPROM_Write->_EEPROM_Check
;!    _Show_Setup->_OLED_WriteTextCenteredAtY
;!    _Resume_Countdown->_Show_Countdown
;!    _Pause_Countdown->_Show_Countdown
;!    _Show_Countdown->_OLED_WriteTextCenteredAtY
;!    _Time_ToText->___lwdiv
;!    _OLED_WriteTextDoubleCentered->_OLED_WriteTextDoublePage
;!    _OLED_WriteTextDoublePage->_OLED_GetGlyph
;!    _OLED_WriteTextDoublePage->_OLED_ScaleGlyph
;!    _OLED_WriteTextCenteredAtY->_OLED_WriteTextAtY
;!    _OLED_WriteTextAtY->_OLED_GetGlyph
;!    _OLED_Clear->_OLED_Fill
;!    _OLED_Fill->_OLED_SetCursor
;!    _OLED_SetCursor->_OLED_Command
;!    _OLED_Command->_I2C_Write
;!    _OLED_Data->_I2C_Write
;!    _I2C_Write->_I2C_WaitIdle
;!    _I2C_Stop->_I2C_WaitIdle
;!    _I2C_Start->_I2C_WaitIdle
;!    _EEPROM_LoadTime->_EEPROM_Check
;!    _Buttons_Update->_ReadButtonsRaw
;!    _Buttons_Init->_ReadButtonsRaw
;!
;!Critical Paths under _InterruptServiceRoutine in COMRAM
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    None.
;!
;!Critical Paths under _InterruptServiceRoutine in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _InterruptServiceRoutine in BANK1
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 4, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                13    13      0   34615
;!                                             54 COMRAM    13    13      0
;!                       _Buttons_Init
;!                     _Buttons_Update
;!                      _Handle_Events
;!                      _Hardware_Init
;!                             _Millis
;!                          _OLED_Init
;!                        _Outputs_Off
;!                         _Show_Setup
;!                        _Show_Splash
;!                       _Update_Alarm
;!                   _Update_Countdown
;! ---------------------------------------------------------------------------------
;! (1) _Update_Countdown                                     9     5      4    6960
;!                                             42 COMRAM     9     5      4
;!                   _Finish_Countdown
;!                     _Show_Countdown
;!                     _Time_Decrement
;! ---------------------------------------------------------------------------------
;! (2) _Time_Decrement                                       1     0      1     291
;!                                              2 COMRAM     1     0      1
;!                        _Time_IsZero
;! ---------------------------------------------------------------------------------
;! (2) _Finish_Countdown                                     4     0      4    2071
;!                                             31 COMRAM     4     0      4
;!                       _Show_Expired
;! ---------------------------------------------------------------------------------
;! (3) _Show_Expired                                         0     0      0    2048
;!                         _OLED_Clear
;!          _OLED_WriteTextCenteredAtY
;! ---------------------------------------------------------------------------------
;! (1) _Update_Alarm                                         8     4      4      23
;!                                              0 COMRAM     8     4      4
;! ---------------------------------------------------------------------------------
;! (1) _Show_Splash                                          0     0      0    2048
;!                         _OLED_Clear
;!          _OLED_WriteTextCenteredAtY
;! ---------------------------------------------------------------------------------
;! (1) _OLED_Init                                            2     2      0     596
;!                                              8 COMRAM     2     2      0
;!                           _I2C_Init
;!                         _OLED_Clear
;!                       _OLED_Command
;!                     _OLED_DisplayOn
;!                   _OLED_FindAddress
;! ---------------------------------------------------------------------------------
;! (2) _OLED_FindAddress                                     0     0      0      81
;!                _I2C_AddressResponds
;! ---------------------------------------------------------------------------------
;! (3) _I2C_AddressResponds                                  2     2      0      81
;!                                              2 COMRAM     2     2      0
;!                          _I2C_Start
;!                           _I2C_Stop
;!                          _I2C_Write
;! ---------------------------------------------------------------------------------
;! (2) _OLED_DisplayOn                                       0     0      0      58
;!                       _OLED_Command
;! ---------------------------------------------------------------------------------
;! (2) _I2C_Init                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Millis                                               9     5      4      46
;!                                              0 COMRAM     9     5      4
;! ---------------------------------------------------------------------------------
;! (1) _Hardware_Init                                        0     0      0       0
;!                        _Timer0_Init
;! ---------------------------------------------------------------------------------
;! (2) _Timer0_Init                                          0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Handle_Events                                        8     3      5   19314
;!                                             46 COMRAM     8     3      5
;!        _Buttons_ConsumeStartRelease
;!                    _EEPROM_LoadTime
;!                        _Outputs_Off
;!                    _Pause_Countdown
;!                   _Resume_Countdown
;!                         _Show_Setup
;!                    _Start_Countdown
;!                        _Time_Adjust
;! ---------------------------------------------------------------------------------
;! (2) _Time_Adjust                                          5     4      1     264
;!                                              0 COMRAM     5     4      1
;! ---------------------------------------------------------------------------------
;! (2) _Start_Countdown                                      4     0      4    4880
;!                                             42 COMRAM     4     0      4
;!                    _EEPROM_SaveTime
;!                _Outputs_CountdownOn
;!                     _Show_Countdown
;!                        _Time_IsZero
;! ---------------------------------------------------------------------------------
;! (3) _Time_IsZero                                          2     1      1      92
;!                                              0 COMRAM     2     1      1
;! ---------------------------------------------------------------------------------
;! (3) _EEPROM_SaveTime                                      1     0      1     236
;!                                              6 COMRAM     1     0      1
;!                       _EEPROM_Check
;!                       _EEPROM_Write
;! ---------------------------------------------------------------------------------
;! (4) _EEPROM_Write                                         3     2      1      79
;!                                              3 COMRAM     3     2      1
;!                       _EEPROM_Check (ARG)
;! ---------------------------------------------------------------------------------
;! (2) _Show_Setup                                          11    11      0    4528
;!                                             31 COMRAM    11    11      0
;!                         _OLED_Clear
;!          _OLED_WriteTextCenteredAtY
;!       _OLED_WriteTextDoubleCentered
;!                        _Time_ToText
;! ---------------------------------------------------------------------------------
;! (2) _Resume_Countdown                                     4     0      4    4552
;!                                             42 COMRAM     4     0      4
;!                _Outputs_CountdownOn
;!                     _Show_Countdown
;! ---------------------------------------------------------------------------------
;! (3) _Outputs_CountdownOn                                  0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _Pause_Countdown                                      0     0      0    4529
;!                     _Show_Countdown
;! ---------------------------------------------------------------------------------
;! (3) _Show_Countdown                                      11     9      2    4529
;!                                             31 COMRAM    11     9      2
;!                         _OLED_Clear
;!          _OLED_WriteTextCenteredAtY
;!       _OLED_WriteTextDoubleCentered
;!                        _Time_ToText
;! ---------------------------------------------------------------------------------
;! (4) _Time_ToText                                          3     1      2     667
;!                                              7 COMRAM     3     1      2
;!                            ___lwdiv
;!                            ___lwmod
;! ---------------------------------------------------------------------------------
;! (5) ___lwmod                                              5     1      4     165
;!                                              0 COMRAM     5     1      4
;! ---------------------------------------------------------------------------------
;! (5) ___lwdiv                                              7     3      4     168
;!                                              0 COMRAM     7     3      4
;! ---------------------------------------------------------------------------------
;! (4) _OLED_WriteTextDoubleCentered                         8     7      1    1708
;!                                             19 COMRAM     8     7      1
;!                     _OLED_TextWidth
;!           _OLED_WriteTextDoublePage
;! ---------------------------------------------------------------------------------
;! (5) _OLED_WriteTextDoublePage                            12     9      3    1188
;!                                              7 COMRAM    12     9      3
;!                          _OLED_Data
;!                      _OLED_GetGlyph
;!                    _OLED_ScaleGlyph
;!                     _OLED_SetCursor
;! ---------------------------------------------------------------------------------
;! (6) _OLED_ScaleGlyph                                      7     6      1     256
;!                                              0 COMRAM     7     6      1
;! ---------------------------------------------------------------------------------
;! (4) _OLED_WriteTextCenteredAtY                            9     7      2    1649
;!                                             22 COMRAM     9     7      2
;!                     _OLED_TextWidth
;!                  _OLED_WriteTextAtY
;! ---------------------------------------------------------------------------------
;! (5) _OLED_WriteTextAtY                                   15    12      3    1226
;!                                              7 COMRAM    15    12      3
;!                          _OLED_Data
;!                      _OLED_GetGlyph
;!                     _OLED_SetCursor
;! ---------------------------------------------------------------------------------
;! (6) _OLED_GetGlyph                                        7     5      2     379
;!                                              0 COMRAM     7     5      2
;! ---------------------------------------------------------------------------------
;! (5) _OLED_TextWidth                                       5     3      2     274
;!                                              0 COMRAM     5     3      2
;! ---------------------------------------------------------------------------------
;! (4) _OLED_Clear                                           0     0      0     399
;!                          _OLED_Fill
;! ---------------------------------------------------------------------------------
;! (5) _OLED_Fill                                            3     3      0     399
;!                                              5 COMRAM     3     3      0
;!                          _OLED_Data
;!                     _OLED_SetCursor
;! ---------------------------------------------------------------------------------
;! (6) _OLED_SetCursor                                       2     1      1     198
;!                                              3 COMRAM     2     1      1
;!                       _OLED_Command
;! ---------------------------------------------------------------------------------
;! (7) _OLED_Command                                         1     1      0      58
;!                                              2 COMRAM     1     1      0
;!                          _I2C_Start
;!                           _I2C_Stop
;!                          _I2C_Write
;! ---------------------------------------------------------------------------------
;! (6) _OLED_Data                                            1     1      0      58
;!                                              2 COMRAM     1     1      0
;!                          _I2C_Start
;!                           _I2C_Stop
;!                          _I2C_Write
;! ---------------------------------------------------------------------------------
;! (8) _I2C_Write                                            1     1      0      29
;!                                              1 COMRAM     1     1      0
;!                       _I2C_WaitIdle
;! ---------------------------------------------------------------------------------
;! (8) _I2C_Stop                                             0     0      0       0
;!                       _I2C_WaitIdle
;! ---------------------------------------------------------------------------------
;! (8) _I2C_Start                                            0     0      0       0
;!                       _I2C_WaitIdle
;! ---------------------------------------------------------------------------------
;! (9) _I2C_WaitIdle                                         1     1      0       0
;!                                              0 COMRAM     1     1      0
;! ---------------------------------------------------------------------------------
;! (2) _Outputs_Off                                          0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _EEPROM_LoadTime                                      3     2      1     261
;!                                              3 COMRAM     3     2      1
;!                       _EEPROM_Check
;!                        _EEPROM_Read
;! ---------------------------------------------------------------------------------
;! (3) _EEPROM_Read                                          1     1      0      15
;!                                              0 COMRAM     1     1      0
;! ---------------------------------------------------------------------------------
;! (4) _EEPROM_Check                                         3     2      1      68
;!                                              0 COMRAM     3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Buttons_ConsumeStartRelease                          0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Buttons_Update                                      21    16      5     862
;!                                              1 COMRAM    21    16      5
;!                     _ReadButtonsRaw
;! ---------------------------------------------------------------------------------
;! (1) _Buttons_Init                                         4     0      4      50
;!                                              1 COMRAM     4     0      4
;!                     _ReadButtonsRaw
;! ---------------------------------------------------------------------------------
;! (2) _ReadButtonsRaw                                       1     1      0      27
;!                                              0 COMRAM     1     1      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 9
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (10) _InterruptServiceRoutine                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 10
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _Buttons_Init
;!     _ReadButtonsRaw
;!   _Buttons_Update
;!     _ReadButtonsRaw
;!   _Handle_Events
;!     _Buttons_ConsumeStartRelease
;!     _EEPROM_LoadTime
;!       _EEPROM_Check
;!       _EEPROM_Read
;!     _Outputs_Off
;!     _Pause_Countdown
;!       _Show_Countdown
;!         _OLED_Clear
;!           _OLED_Fill
;!             _OLED_Data
;!               _I2C_Start
;!                 _I2C_WaitIdle
;!               _I2C_Stop
;!                 _I2C_WaitIdle
;!               _I2C_Write
;!                 _I2C_WaitIdle
;!             _OLED_SetCursor
;!               _OLED_Command
;!                 _I2C_Start
;!                 _I2C_Stop
;!                 _I2C_Write
;!         _OLED_WriteTextCenteredAtY
;!           _OLED_TextWidth
;!           _OLED_WriteTextAtY
;!             _OLED_Data
;!             _OLED_GetGlyph
;!             _OLED_SetCursor
;!         _OLED_WriteTextDoubleCentered
;!           _OLED_TextWidth
;!           _OLED_WriteTextDoublePage
;!             _OLED_Data
;!             _OLED_GetGlyph
;!             _OLED_ScaleGlyph
;!             _OLED_SetCursor
;!         _Time_ToText
;!           ___lwdiv
;!           ___lwmod
;!     _Resume_Countdown
;!       _Outputs_CountdownOn
;!       _Show_Countdown
;!     _Show_Setup
;!       _OLED_Clear
;!       _OLED_WriteTextCenteredAtY
;!       _OLED_WriteTextDoubleCentered
;!       _Time_ToText
;!     _Start_Countdown
;!       _EEPROM_SaveTime
;!         _EEPROM_Check
;!         _EEPROM_Write
;!           _EEPROM_Check (ARG)
;!       _Outputs_CountdownOn
;!       _Show_Countdown
;!       _Time_IsZero
;!     _Time_Adjust
;!   _Hardware_Init
;!     _Timer0_Init
;!   _Millis
;!   _OLED_Init
;!     _I2C_Init
;!     _OLED_Clear
;!     _OLED_Command
;!     _OLED_DisplayOn
;!       _OLED_Command
;!     _OLED_FindAddress
;!       _I2C_AddressResponds
;!         _I2C_Start
;!         _I2C_Stop
;!         _I2C_Write
;!   _Outputs_Off
;!   _Show_Setup
;!   _Show_Splash
;!     _OLED_Clear
;!     _OLED_WriteTextCenteredAtY
;!   _Update_Alarm
;!   _Update_Countdown
;!     _Finish_Countdown
;!       _Show_Expired
;!         _OLED_Clear
;!         _OLED_WriteTextCenteredAtY
;!     _Show_Countdown
;!     _Time_Decrement
;!       _Time_IsZero
;!
;! _InterruptServiceRoutine (ROOT)
;!

;!Address spaces:

;!Name               Size   Autos  Total    Usage
;!BIGRAM             511      0       0      0.0%
;!BITBANK1           256      0       0      0.0%
;!BANK1              256      0       0      0.0%
;!BITBANK0           160      0       0      0.0%
;!BANK0              160      0      21     13.1%
;!BITBIGSFRh         128      0       0      0.0%
;!BITCOMRAM           94      0       0      0.0%
;!COMRAM              94     67      93     98.9%
;!BITBIGSFRllll       11      0       0      0.0%
;!BITBIGSFRllh        10      0       0      0.0%
;!BITBIGSFRlh          6      0       0      0.0%
;!BITBIGSFRlllh        1      0       0      0.0%
;!STACK                0      0       0      0.0%
;!DATA                 0      0     114      0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 136 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  events          5   58[COMRAM] struct .
;;  now             4   63[COMRAM] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         9       0       0
;;      Temps:          4       0       0
;;      Totals:        13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels required when called: 9
;; This function calls:
;;		_Buttons_Init
;;		_Buttons_Update
;;		_Handle_Events
;;		_Hardware_Init
;;		_Millis
;;		_OLED_Init
;;		_Outputs_Off
;;		_Show_Setup
;;		_Show_Splash
;;		_Update_Alarm
;;		_Update_Countdown
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	text0,class=CODE,space=0,reloc=2,group=0
	file	"main.c"
	line	136
global __ptext0
__ptext0:
psect	text0
	file	"main.c"
	line	136
	
_main:
;incstack = 0
	callstack 22
	line	141
	
l3234:
	call	_Hardware_Init	;wreg free
	line	142
	
l3236:
	call	_OLED_Init	;wreg free
	line	144
	
l3238:
	call	_Millis	;wreg free
	movff	0+?_Millis,(c:main@now)
	movff	1+?_Millis,(c:main@now+1)
	movff	2+?_Millis,(c:main@now+2)
	movff	3+?_Millis,(c:main@now+3)
	
	line	145
	
l3240:
	movff	(c:main@now),(c:Buttons_Init@now)
	movff	(c:main@now+1),(c:Buttons_Init@now+1)
	movff	(c:main@now+2),(c:Buttons_Init@now+2)
	movff	(c:main@now+3),(c:Buttons_Init@now+3)
	call	_Buttons_Init	;wreg free
	line	146
	
l3242:
	call	_Outputs_Off	;wreg free
	line	147
	
l3244:
	call	_Show_Splash	;wreg free
	line	148
	
l3246:
	movff	(c:main@now),(c:_splashStartedAt)
	movff	(c:main@now+1),(c:_splashStartedAt+1)
	movff	(c:main@now+2),(c:_splashStartedAt+2)
	movff	(c:main@now+3),(c:_splashStartedAt+3)
	line	151
	
l3248:
	call	_Millis	;wreg free
	movff	0+?_Millis,(c:main@now)
	movff	1+?_Millis,(c:main@now+1)
	movff	2+?_Millis,(c:main@now+2)
	movff	3+?_Millis,(c:main@now+3)
	
	line	152
	
l3250:
	movff	(c:main@now),(c:Buttons_Update@now)
	movff	(c:main@now+1),(c:Buttons_Update@now+1)
	movff	(c:main@now+2),(c:Buttons_Update@now+2)
	movff	(c:main@now+3),(c:Buttons_Update@now+3)
	call	_Buttons_Update	;wreg free
	lfsr	2,(main@events)
	movlw	5-1
u3371:
	movff	plusw0,plusw2
	decf	wreg
	bc	u3371

	line	154
	
l3252:
	movf	((c:_appState))^00h,c,w
	btfss	status,2
	goto	u3381
	goto	u3380
u3381:
	goto	l3264
u3380:
	line	155
	
l3254:
	movf	((c:_splashStartedAt))^00h,c,w
	subwf	((c:main@now))^00h,c,w
	movwf	(??_main+0)^00h,c
	movf	((c:_splashStartedAt+1))^00h,c,w
	subwfb	((c:main@now+1))^00h,c,w
	movwf	1+(??_main+0)^00h,c
	
	movf	((c:_splashStartedAt+2))^00h,c,w
	subwfb	((c:main@now+2))^00h,c,w
	movwf	2+(??_main+0)^00h,c
	
	movf	((c:_splashStartedAt+3))^00h,c,w
	subwfb	((c:main@now+3))^00h,c,w
	movwf	3+(??_main+0)^00h,c
		movf	(??_main+0+3)^00h,c,w
	iorwf	(??_main+0+2)^00h,c,w
	bnz	u3390
	movlw	184
	subwf	 (??_main+0)^00h,c,w
	movlw	11
	subwfb	(??_main+0+1)^00h,c,w
	btfss	status,0
	goto	u3391
	goto	u3390

u3391:
	goto	l3266
u3390:
	line	156
	
l3256:
	movlw	low(01h)
	movwf	((c:_appState))^00h,c
	line	157
	
l3258:
	clrf	((c:_editField))^00h,c
	line	158
	
l3260:
	call	_Outputs_Off	;wreg free
	line	159
	
l3262:
	call	_Show_Setup	;wreg free
	goto	l3266
	line	162
	
l3264:
		movlw	low(main@events)
	movwf	((c:Handle_Events@events))^00h,c

	movff	(c:main@now),(c:Handle_Events@now)
	movff	(c:main@now+1),(c:Handle_Events@now+1)
	movff	(c:main@now+2),(c:Handle_Events@now+2)
	movff	(c:main@now+3),(c:Handle_Events@now+3)
	call	_Handle_Events	;wreg free
	line	165
	
l3266:
		movlw	2
	xorwf	((c:_appState))^00h,c,w
	btfss	status,2
	goto	u3401
	goto	u3400

u3401:
	goto	l3270
u3400:
	line	166
	
l3268:
	movff	(c:main@now),(c:Update_Countdown@now)
	movff	(c:main@now+1),(c:Update_Countdown@now+1)
	movff	(c:main@now+2),(c:Update_Countdown@now+2)
	movff	(c:main@now+3),(c:Update_Countdown@now+3)
	call	_Update_Countdown	;wreg free
	line	167
	goto	l3248
	
l3270:
		movlw	4
	xorwf	((c:_appState))^00h,c,w
	btfss	status,2
	goto	u3411
	goto	u3410

u3411:
	goto	l3248
u3410:
	line	168
	
l3272:
	movff	(c:main@now),(c:Update_Alarm@now)
	movff	(c:main@now+1),(c:Update_Alarm@now+1)
	movff	(c:main@now+2),(c:Update_Alarm@now+2)
	movff	(c:main@now+3),(c:Update_Alarm@now+3)
	call	_Update_Alarm	;wreg free
	goto	l3248
	global	start
	goto	start
	callstack 0
	line	171
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Update_Countdown

;; *************** function _Update_Countdown *****************
;; Defined at:
;;		line 560 in file "main.c"
;; Parameters:    Size  Location     Type
;;  now             4   42[COMRAM] unsigned long 
;; Auto vars:     Size  Location     Type
;;  displayNeeds    1   50[COMRAM] _Bool 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         1       0       0
;;      Temps:          4       0       0
;;      Totals:         9       0       0
;;Total ram usage:        9 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 4
;; This function calls:
;;		_Finish_Countdown
;;		_Show_Countdown
;;		_Time_Decrement
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,class=CODE,space=0,reloc=2,group=0
	line	560
global __ptext1
__ptext1:
psect	text1
	file	"main.c"
	line	560
	
_Update_Countdown:
;incstack = 0
	callstack 26
	line	562
	
l3204:
	clrf	((c:Update_Countdown@displayNeedsUpdate))^00h,c
	line	564
	goto	l3216
	line	565
	
l3206:; BSR set to: 0

	movlw	0E8h
	addwf	((_lastSecondAt))&0ffh
	movlw	03h
	addwfc	((_lastSecondAt+1))&0ffh
	movlw	0
	addwfc	((_lastSecondAt+2))&0ffh
	movlw	0
	addwfc	((_lastSecondAt+3))&0ffh
	line	566
	
l3208:; BSR set to: 0

	movlw	low(01h)
	movwf	((c:Update_Countdown@displayNeedsUpdate))^00h,c
	line	567
	
l3210:; BSR set to: 0

		movlw	low(_remainingTime)
	movwf	((c:Time_Decrement@time))^00h,c

	call	_Time_Decrement	;wreg free
	iorlw	0
	btfss	status,2
	goto	u3271
	goto	u3270
u3271:
	goto	l3216
u3270:
	line	568
	
l3212:
	movff	(c:Update_Countdown@now),(c:Finish_Countdown@now)
	movff	(c:Update_Countdown@now+1),(c:Finish_Countdown@now+1)
	movff	(c:Update_Countdown@now+2),(c:Finish_Countdown@now+2)
	movff	(c:Update_Countdown@now+3),(c:Finish_Countdown@now+3)
	call	_Finish_Countdown	;wreg free
	goto	l277
	line	564
	
l3216:
	movlb	0	; () banked
	movf	((_lastSecondAt))&0ffh,w
	subwf	((c:Update_Countdown@now))^00h,c,w
	movwf	(??_Update_Countdown+0)^00h,c
	movf	((_lastSecondAt+1))&0ffh,w
	subwfb	((c:Update_Countdown@now+1))^00h,c,w
	movwf	1+(??_Update_Countdown+0)^00h,c
	
	movf	((_lastSecondAt+2))&0ffh,w
	subwfb	((c:Update_Countdown@now+2))^00h,c,w
	movwf	2+(??_Update_Countdown+0)^00h,c
	
	movf	((_lastSecondAt+3))&0ffh,w
	subwfb	((c:Update_Countdown@now+3))^00h,c,w
	movwf	3+(??_Update_Countdown+0)^00h,c
		movf	(??_Update_Countdown+0+3)^00h,c,w
	iorwf	(??_Update_Countdown+0+2)^00h,c,w
	bnz	u3281
	movlw	232
	subwf	 (??_Update_Countdown+0)^00h,c,w
	movlw	3
	subwfb	(??_Update_Countdown+0+1)^00h,c,w
	btfsc	status,0
	goto	u3281
	goto	u3280

u3281:
	goto	l3206
u3280:
	line	573
	
l3218:; BSR set to: 0

	movf	((c:Update_Countdown@displayNeedsUpdate))^00h,c,w
	btfsc	status,2
	goto	u3291
	goto	u3290
u3291:
	goto	l277
u3290:
	line	574
	
l3220:; BSR set to: 0

		movlw	low(STR_12)
	movwf	((c:Show_Countdown@title))^00h,c
	movlw	high(STR_12)
	movwf	((c:Show_Countdown@title+1))^00h,c

	call	_Show_Countdown	;wreg free
	line	576
	
l277:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Update_Countdown
	__end_of_Update_Countdown:
	signat	_Update_Countdown,4217
	global	_Time_Decrement

;; *************** function _Time_Decrement *****************
;; Defined at:
;;		line 354 in file "main.c"
;; Parameters:    Size  Location     Type
;;  time            1    2[COMRAM] PTR struct .
;;		 -> remainingTime(3), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      _Bool 
;; Registers used:
;;		wreg, fsr2l, fsr2h, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_Time_IsZero
;; This function is called by:
;;		_Update_Countdown
;; This function uses a non-reentrant model
;;
psect	text2,class=CODE,space=0,reloc=2,group=0
	line	354
global __ptext2
__ptext2:
psect	text2
	file	"main.c"
	line	354
	
_Time_Decrement:
;incstack = 0
	callstack 27
	line	356
	
l2842:
	movf	((c:Time_Decrement@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movf	indf2,w
	btfsc	status,2
	goto	u2651
	goto	u2650
u2651:
	goto	l2846
u2650:
	line	357
	
l2844:
	movf	((c:Time_Decrement@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	decf	indf2

	line	358
	goto	l2856
	line	359
	
l2846:
	movf	((c:Time_Decrement@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movlw	low(03Bh)
	movwf	indf2
	line	360
	movf	((c:Time_Decrement@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	movf	indf2,w
	btfsc	status,2
	goto	u2661
	goto	u2660
u2661:
	goto	l2850
u2660:
	line	361
	
l2848:
	movf	((c:Time_Decrement@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	decf	indf2

	line	362
	goto	l2856
	line	363
	
l2850:
	movf	((c:Time_Decrement@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	movlw	low(03Bh)
	movwf	indf2
	line	364
	
l2852:
	movf	((c:Time_Decrement@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movf	indf2,w
	btfsc	status,2
	goto	u2671
	goto	u2670
u2671:
	goto	l2856
u2670:
	line	365
	
l2854:
	movf	((c:Time_Decrement@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	decf	indf2

	line	370
	
l2856:
		movff	(c:Time_Decrement@time),(c:Time_IsZero@time)

	call	_Time_IsZero	;wreg free
	iorlw	0
	btfsc	status,2
	goto	u2681
	goto	u2680
u2681:
	movlw	1
	goto	u2690
u2680:
	movlw	0
u2690:
	line	371
	
l205:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Time_Decrement
	__end_of_Time_Decrement:
	signat	_Time_Decrement,4217
	global	_Finish_Countdown

;; *************** function _Finish_Countdown *****************
;; Defined at:
;;		line 548 in file "main.c"
;; Parameters:    Size  Location     Type
;;  now             4   31[COMRAM] unsigned long 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 3
;; This function calls:
;;		_Show_Expired
;; This function is called by:
;;		_Update_Countdown
;; This function uses a non-reentrant model
;;
psect	text3,class=CODE,space=0,reloc=2,group=0
	line	548
global __ptext3
__ptext3:
psect	text3
	file	"main.c"
	line	548
	
_Finish_Countdown:
;incstack = 0
	callstack 26
	line	550
	
l2936:
	movlw	low(04h)
	movwf	((c:_appState))^00h,c
	line	551
	
l2938:
	bcf	((c:3979))^0f00h,c,1	;volatile
	line	552
	
l2940:
	bcf	((c:3979))^0f00h,c,5	;volatile
	line	553
	
l2942:
	bcf	((c:3979))^0f00h,c,2	;volatile
	line	554
	
l2944:
	bcf	((c:3979))^0f00h,c,3	;volatile
	line	555
	
l2946:
	clrf	((c:_alarmOn))^00h,c
	line	556
	
l2948:
	movff	(c:Finish_Countdown@now),(_lastAlarmToggleAt)
	movff	(c:Finish_Countdown@now+1),(_lastAlarmToggleAt+1)
	movff	(c:Finish_Countdown@now+2),(_lastAlarmToggleAt+2)
	movff	(c:Finish_Countdown@now+3),(_lastAlarmToggleAt+3)
	line	557
	
l2950:
	call	_Show_Expired	;wreg free
	line	558
	
l271:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Finish_Countdown
	__end_of_Finish_Countdown:
	signat	_Finish_Countdown,4217
	global	_Show_Expired

;; *************** function _Show_Expired *****************
;; Defined at:
;;		line 513 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_OLED_Clear
;;		_OLED_WriteTextCenteredAtY
;; This function is called by:
;;		_Finish_Countdown
;; This function uses a non-reentrant model
;;
psect	text4,class=CODE,space=0,reloc=2,group=0
	line	513
global __ptext4
__ptext4:
psect	text4
	file	"main.c"
	line	513
	
_Show_Expired:
;incstack = 0
	callstack 26
	line	515
	
l2790:
	call	_OLED_Clear	;wreg free
	line	516
	
l2792:
		movlw	low(STR_7)
	movwf	((c:OLED_WriteTextCenteredAtY@text))^00h,c
	movlw	high(STR_7)
	movwf	((c:OLED_WriteTextCenteredAtY@text+1))^00h,c

	movlw	(014h)&0ffh
	
	call	_OLED_WriteTextCenteredAtY
	line	517
	
l2794:
		movlw	low(STR_8)
	movwf	((c:OLED_WriteTextCenteredAtY@text))^00h,c
	movlw	high(STR_8)
	movwf	((c:OLED_WriteTextCenteredAtY@text+1))^00h,c

	movlw	(024h)&0ffh
	
	call	_OLED_WriteTextCenteredAtY
	line	518
	
l258:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Show_Expired
	__end_of_Show_Expired:
	signat	_Show_Expired,89
	global	_Update_Alarm

;; *************** function _Update_Alarm *****************
;; Defined at:
;;		line 578 in file "main.c"
;; Parameters:    Size  Location     Type
;;  now             4    0[COMRAM] unsigned long 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         0       0       0
;;      Temps:          4       0       0
;;      Totals:         8       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,class=CODE,space=0,reloc=2,group=0
	line	578
global __ptext5
__ptext5:
psect	text5
	file	"main.c"
	line	578
	
_Update_Alarm:
;incstack = 0
	callstack 29
	line	580
	
l3222:
	goto	l3232
	line	581
	
l3224:; BSR set to: 0

	movlw	low(0FAh)
	addwf	((_lastAlarmToggleAt))&0ffh
	movlw	0
	addwfc	((_lastAlarmToggleAt+1))&0ffh
	addwfc	((_lastAlarmToggleAt+2))&0ffh
	addwfc	((_lastAlarmToggleAt+3))&0ffh
	line	582
	
l3226:; BSR set to: 0

	movf	((c:_alarmOn))^00h,c,w
	btfsc	status,2
	goto	u3301
	goto	u3300
u3301:
	movlw	1
	goto	u3310
u3300:
	movlw	0
u3310:
	movwf	((c:_alarmOn))^00h,c
	line	583
	
l3228:; BSR set to: 0

	movf	((c:_alarmOn))^00h,c,w
	btfss	status,2
	goto	u3321
	goto	u3320
u3321:
	clrf	(??_Update_Alarm+0)^00h,c
	incf	(??_Update_Alarm+0)^00h,c
	goto	u3338
u3320:
	clrf	(??_Update_Alarm+0)^00h,c
u3338:
	rlncf	(??_Update_Alarm+0)^00h,c
	rlncf	(??_Update_Alarm+0)^00h,c
	movf	((c:3979))^0f00h,c,w	;volatile
	xorwf	(??_Update_Alarm+0)^00h,c,w
	andlw	not (((1<<1)-1)<<2)
	xorwf	(??_Update_Alarm+0)^00h,c,w
	movwf	((c:3979))^0f00h,c	;volatile
	line	584
	
l3230:
	movf	((c:_alarmOn))^00h,c,w
	btfss	status,2
	goto	u3341
	goto	u3340
u3341:
	clrf	(??_Update_Alarm+0)^00h,c
	incf	(??_Update_Alarm+0)^00h,c
	goto	u3358
u3340:
	clrf	(??_Update_Alarm+0)^00h,c
u3358:
	rlncf	(??_Update_Alarm+0)^00h,c
	rlncf	(??_Update_Alarm+0)^00h,c
	rlncf	(??_Update_Alarm+0)^00h,c
	movf	((c:3979))^0f00h,c,w	;volatile
	xorwf	(??_Update_Alarm+0)^00h,c,w
	andlw	not (((1<<1)-1)<<3)
	xorwf	(??_Update_Alarm+0)^00h,c,w
	movwf	((c:3979))^0f00h,c	;volatile
	line	580
	
l3232:
	movlb	0	; () banked
	movf	((_lastAlarmToggleAt))&0ffh,w
	subwf	((c:Update_Alarm@now))^00h,c,w
	movwf	(??_Update_Alarm+0)^00h,c
	movf	((_lastAlarmToggleAt+1))&0ffh,w
	subwfb	((c:Update_Alarm@now+1))^00h,c,w
	movwf	1+(??_Update_Alarm+0)^00h,c
	
	movf	((_lastAlarmToggleAt+2))&0ffh,w
	subwfb	((c:Update_Alarm@now+2))^00h,c,w
	movwf	2+(??_Update_Alarm+0)^00h,c
	
	movf	((_lastAlarmToggleAt+3))&0ffh,w
	subwfb	((c:Update_Alarm@now+3))^00h,c,w
	movwf	3+(??_Update_Alarm+0)^00h,c
		movf	(??_Update_Alarm+0+3)^00h,c,w
	iorwf	(??_Update_Alarm+0+2)^00h,c,w
	iorwf	(??_Update_Alarm+0+1)^00h,c,w
	bnz	u3361
	movlw	250
	subwf	 (??_Update_Alarm+0)^00h,c,w
	btfsc	status,0
	goto	u3361
	goto	u3360

u3361:
	goto	l3224
u3360:
	line	586
	
l285:; BSR set to: 0

	return	;funcret
	callstack 0
GLOBAL	__end_of_Update_Alarm
	__end_of_Update_Alarm:
	signat	_Update_Alarm,4217
	global	_Show_Splash

;; *************** function _Show_Splash *****************
;; Defined at:
;;		line 476 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_OLED_Clear
;;		_OLED_WriteTextCenteredAtY
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,class=CODE,space=0,reloc=2,group=0
	line	476
global __ptext6
__ptext6:
psect	text6
	file	"main.c"
	line	476
	
_Show_Splash:; BSR set to: 0

;incstack = 0
	callstack 28
	line	478
	
l3052:
	call	_OLED_Clear	;wreg free
	line	479
	
l3054:
		movlw	low(STR_1)
	movwf	((c:OLED_WriteTextCenteredAtY@text))^00h,c
	movlw	high(STR_1)
	movwf	((c:OLED_WriteTextCenteredAtY@text+1))^00h,c

	movlw	(015h)&0ffh
	
	call	_OLED_WriteTextCenteredAtY
	line	480
	
l3056:
		movlw	low(STR_2)
	movwf	((c:OLED_WriteTextCenteredAtY@text))^00h,c
	movlw	high(STR_2)
	movwf	((c:OLED_WriteTextCenteredAtY@text+1))^00h,c

	movlw	(022h)&0ffh
	
	call	_OLED_WriteTextCenteredAtY
	line	481
	
l245:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Show_Splash
	__end_of_Show_Splash:
	signat	_Show_Splash,89
	global	_OLED_Init

;; *************** function _OLED_Init *****************
;; Defined at:
;;		line 126 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          2       0       0
;;      Totals:         2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 4
;; This function calls:
;;		_I2C_Init
;;		_OLED_Clear
;;		_OLED_Command
;;		_OLED_DisplayOn
;;		_OLED_FindAddress
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,class=CODE,space=0,reloc=2,group=0
	file	"oled_i2c.c"
	line	126
global __ptext7
__ptext7:
psect	text7
	file	"oled_i2c.c"
	line	126
	
_OLED_Init:
;incstack = 0
	callstack 26
	line	128
	
l2964:
	call	_I2C_Init	;wreg free
	line	129
	
l2966:
	asmopt push
asmopt off
movlw  2
movwf	(??_OLED_Init+0+1)^00h,c
movlw	4
movwf	(??_OLED_Init+0)^00h,c
	movlw	186
u3467:
decfsz	wreg,f
	bra	u3467
	decfsz	(??_OLED_Init+0)^00h,c,f
	bra	u3467
	decfsz	(??_OLED_Init+0+1)^00h,c,f
	bra	u3467
	nop2
asmopt pop

	line	130
	
l2968:
	call	_OLED_FindAddress	;wreg free
	line	132
	
l2970:
	movlw	(0AEh)&0ffh
	
	call	_OLED_Command
	line	133
	
l2972:
	movlw	(0D5h)&0ffh
	
	call	_OLED_Command
	line	134
	
l2974:
	movlw	(080h)&0ffh
	
	call	_OLED_Command
	line	135
	
l2976:
	movlw	(0A8h)&0ffh
	
	call	_OLED_Command
	line	136
	
l2978:
	movlw	(03Fh)&0ffh
	
	call	_OLED_Command
	line	137
	
l2980:
	movlw	(0D3h)&0ffh
	
	call	_OLED_Command
	line	138
	
l2982:
	movlw	(0)&0ffh
	
	call	_OLED_Command
	line	139
	
l2984:
	movlw	(040h)&0ffh
	
	call	_OLED_Command
	line	140
	
l2986:
	movlw	(08Dh)&0ffh
	
	call	_OLED_Command
	line	141
	
l2988:
	movlw	(014h)&0ffh
	
	call	_OLED_Command
	line	142
	
l2990:
	movlw	(020h)&0ffh
	
	call	_OLED_Command
	line	143
	
l2992:
	movlw	(02h)&0ffh
	
	call	_OLED_Command
	line	144
	
l2994:
	movlw	(0A1h)&0ffh
	
	call	_OLED_Command
	line	145
	
l2996:
	movlw	(0C8h)&0ffh
	
	call	_OLED_Command
	line	146
	
l2998:
	movlw	(0DAh)&0ffh
	
	call	_OLED_Command
	line	147
	
l3000:
	movlw	(012h)&0ffh
	
	call	_OLED_Command
	line	148
	
l3002:
	movlw	(081h)&0ffh
	
	call	_OLED_Command
	line	149
	
l3004:
	movlw	(0CFh)&0ffh
	
	call	_OLED_Command
	line	150
	
l3006:
	movlw	(0D9h)&0ffh
	
	call	_OLED_Command
	line	151
	
l3008:
	movlw	(0F1h)&0ffh
	
	call	_OLED_Command
	line	152
	
l3010:
	movlw	(0DBh)&0ffh
	
	call	_OLED_Command
	line	153
	
l3012:
	movlw	(040h)&0ffh
	
	call	_OLED_Command
	line	154
	
l3014:
	movlw	(0A4h)&0ffh
	
	call	_OLED_Command
	line	155
	
l3016:
	movlw	(0A6h)&0ffh
	
	call	_OLED_Command
	line	156
	
l3018:
	call	_OLED_Clear	;wreg free
	line	157
	
l3020:
	call	_OLED_DisplayOn	;wreg free
	line	158
	
l377:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_Init
	__end_of_OLED_Init:
	signat	_OLED_Init,89
	global	_OLED_FindAddress

;; *************** function _OLED_FindAddress *****************
;; Defined at:
;;		line 490 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 3
;; This function calls:
;;		_I2C_AddressResponds
;; This function is called by:
;;		_OLED_Init
;; This function uses a non-reentrant model
;;
psect	text8,class=CODE,space=0,reloc=2,group=0
	line	490
global __ptext8
__ptext8:
psect	text8
	file	"oled_i2c.c"
	line	490
	
_OLED_FindAddress:
;incstack = 0
	callstack 26
	line	492
	
l2952:
	movlw	(03Ch)&0ffh
	
	call	_I2C_AddressResponds
	iorlw	0
	btfsc	status,2
	goto	u2821
	goto	u2820
u2821:
	goto	l2956
u2820:
	line	493
	
l2954:
	movlw	low(03Ch)
	movwf	((c:_oledAddress))^00h,c
	line	494
	goto	l526
	
l2956:
	movlw	(03Dh)&0ffh
	
	call	_I2C_AddressResponds
	iorlw	0
	btfsc	status,2
	goto	u2831
	goto	u2830
u2831:
	goto	l2954
u2830:
	line	495
	
l2958:
	movlw	low(03Dh)
	movwf	((c:_oledAddress))^00h,c
	line	499
	
l526:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_FindAddress
	__end_of_OLED_FindAddress:
	signat	_OLED_FindAddress,89
	global	_I2C_AddressResponds

;; *************** function _I2C_AddressResponds *****************
;; Defined at:
;;		line 479 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  address         1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  address         1    2[COMRAM] unsigned char 
;;  acknowledged    1    3[COMRAM] _Bool 
;; Return value:  Size  Location     Type
;;                  1    wreg      _Bool 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         2       0       0
;;      Temps:          0       0       0
;;      Totals:         2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_I2C_Start
;;		_I2C_Stop
;;		_I2C_Write
;; This function is called by:
;;		_OLED_FindAddress
;; This function uses a non-reentrant model
;;
psect	text9,class=CODE,space=0,reloc=2,group=0
	line	479
global __ptext9
__ptext9:
psect	text9
	file	"oled_i2c.c"
	line	479
	
_I2C_AddressResponds:
;incstack = 0
	callstack 26
	movwf	((c:I2C_AddressResponds@address))^00h,c
	line	483
	
l2796:
	call	_I2C_Start	;wreg free
	line	484
	movf	((c:I2C_AddressResponds@address))^00h,c,w
	addwf	((c:I2C_AddressResponds@address))^00h,c,w
	
	call	_I2C_Write
	movwf	((c:I2C_AddressResponds@acknowledged))^00h,c
	line	485
	call	_I2C_Stop	;wreg free
	line	487
	
l2798:
	movf	((c:I2C_AddressResponds@acknowledged))^00h,c,w
	line	488
	
l519:
	return	;funcret
	callstack 0
GLOBAL	__end_of_I2C_AddressResponds
	__end_of_I2C_AddressResponds:
	signat	_I2C_AddressResponds,4217
	global	_OLED_DisplayOn

;; *************** function _OLED_DisplayOn *****************
;; Defined at:
;;		line 179 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_OLED_Command
;; This function is called by:
;;		_OLED_Init
;; This function uses a non-reentrant model
;;
psect	text10,class=CODE,space=0,reloc=2,group=0
	line	179
global __ptext10
__ptext10:
psect	text10
	file	"oled_i2c.c"
	line	179
	
_OLED_DisplayOn:
;incstack = 0
	callstack 27
	line	181
	
l2962:
	movlw	(0AFh)&0ffh
	
	call	_OLED_Command
	line	182
	
l390:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_DisplayOn
	__end_of_OLED_DisplayOn:
	signat	_OLED_DisplayOn,89
	global	_I2C_Init

;; *************** function _I2C_Init *****************
;; Defined at:
;;		line 432 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_OLED_Init
;; This function uses a non-reentrant model
;;
psect	text11,class=CODE,space=0,reloc=2,group=0
	line	432
global __ptext11
__ptext11:
psect	text11
	file	"oled_i2c.c"
	line	432
	
_I2C_Init:
;incstack = 0
	callstack 28
	line	434
	
l1954:
	bsf	((c:4039))^0f00h,c,7	;volatile
	line	435
	bcf	((c:4039))^0f00h,c,6	;volatile
	line	436
	
l1956:
	movf	((c:4038))^0f00h,c,w	;volatile
	andlw	not (((1<<4)-1)<<0)
	iorlw	(08h & ((1<<4)-1))<<0
	movwf	((c:4038))^0f00h,c	;volatile
	line	437
	
l1958:
	bsf	((c:4038))^0f00h,c,5	;volatile
	line	438
	
l1960:
	clrf	((c:4037))^0f00h,c	;volatile
	line	439
	movlw	low(013h)
	movwf	((c:4040))^0f00h,c	;volatile
	line	441
	
l1962:
	bcf	((c:3967))^0f00h,c,2	;volatile
	line	442
	
l1964:
	bcf	((c:3967))^0f00h,c,3	;volatile
	line	443
	
l1966:
	bsf	((c:3987))^0f00h,c,4	;volatile
	line	444
	
l1968:
	bsf	((c:3987))^0f00h,c,6	;volatile
	line	445
	
l492:
	return	;funcret
	callstack 0
GLOBAL	__end_of_I2C_Init
	__end_of_I2C_Init:
	signat	_I2C_Init,89
	global	_Millis

;; *************** function _Millis *****************
;; Defined at:
;;		line 236 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  result          4    4[COMRAM] unsigned long 
;;  interruptsEn    1    8[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMRAM] unsigned long 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         5       0       0
;;      Temps:          0       0       0
;;      Totals:         9       0       0
;;Total ram usage:        9 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text12,class=CODE,space=0,reloc=2,group=0
	file	"main.c"
	line	236
global __ptext12
__ptext12:
psect	text12
	file	"main.c"
	line	236
	
_Millis:
;incstack = 0
	callstack 29
	line	241
	
l3022:
	movlw	0
	btfsc	((c:4082))^0f00h,c,7	;volatile
	movlw	1
	movwf	((c:Millis@interruptsEnabled))^00h,c
	line	242
	
l3024:
	bcf	((c:4082))^0f00h,c,7	;volatile
	line	243
	
l3026:
	movff	(c:_milliseconds),(c:Millis@result)	;volatile
	movff	(c:_milliseconds+1),(c:Millis@result+1)	;volatile
	movff	(c:_milliseconds+2),(c:Millis@result+2)	;volatile
	movff	(c:_milliseconds+3),(c:Millis@result+3)	;volatile
	line	244
	
l3028:
	btfsc	(c:Millis@interruptsEnabled)^00h,c,0
	bra	u2845
	bcf	((c:4082))^0f00h,c,7	;volatile
	bra	u2846
	u2845:
	bsf	((c:4082))^0f00h,c,7	;volatile
	u2846:

	line	246
	
l3030:
	movff	(c:Millis@result),(c:?_Millis)
	movff	(c:Millis@result+1),(c:?_Millis+1)
	movff	(c:Millis@result+2),(c:?_Millis+2)
	movff	(c:Millis@result+3),(c:?_Millis+3)
	line	247
	
l156:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Millis
	__end_of_Millis:
	signat	_Millis,92
	global	_Hardware_Init

;; *************** function _Hardware_Init *****************
;; Defined at:
;;		line 173 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_Timer0_Init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,class=CODE,space=0,reloc=2,group=0
	line	173
global __ptext13
__ptext13:
psect	text13
	file	"main.c"
	line	173
	
_Hardware_Init:
;incstack = 0
	callstack 28
	line	175
	
l1982:
	clrf	((c:3966))^0f00h,c	;volatile
	line	176
	clrf	((c:3967))^0f00h,c	;volatile
	line	177
	clrf	((c:3949))^0f00h,c	;volatile
	line	178
	clrf	((c:3947))^0f00h,c	;volatile
	line	180
	clrf	((c:3977))^0f00h,c	;volatile
	line	181
	clrf	((c:3978))^0f00h,c	;volatile
	line	182
	clrf	((c:3979))^0f00h,c	;volatile
	line	184
	setf	((c:3986))^0f00h,c	;volatile
	line	185
	setf	((c:3987))^0f00h,c	;volatile
	line	186
	setf	((c:3988))^0f00h,c	;volatile
	line	188
	bsf	((c:3986))^0f00h,c,2	;volatile
	line	189
	bsf	((c:3987))^0f00h,c,5	;volatile
	line	190
	bsf	((c:3987))^0f00h,c,7	;volatile
	line	191
	bsf	((c:3988))^0f00h,c,0	;volatile
	line	193
	bcf	((c:3988))^0f00h,c,1	;volatile
	line	194
	bcf	((c:3988))^0f00h,c,2	;volatile
	line	195
	bcf	((c:3988))^0f00h,c,3	;volatile
	line	196
	bcf	((c:3988))^0f00h,c,5	;volatile
	line	199
	bcf	((c:4081))^0f00h,c,7	;volatile
	line	200
	bsf	((c:3960))^0f00h,c,5	;volatile
	line	201
	bsf	((c:3960))^0f00h,c,7	;volatile
	line	203
	
l1984:
	call	_Timer0_Init	;wreg free
	line	204
	
l144:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Hardware_Init
	__end_of_Hardware_Init:
	signat	_Hardware_Init,89
	global	_Timer0_Init

;; *************** function _Timer0_Init *****************
;; Defined at:
;;		line 206 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Hardware_Init
;; This function uses a non-reentrant model
;;
psect	text14,class=CODE,space=0,reloc=2,group=0
	line	206
global __ptext14
__ptext14:
psect	text14
	file	"main.c"
	line	206
	
_Timer0_Init:
;incstack = 0
	callstack 28
	line	208
	
l1808:
	bcf	((c:4048))^0f00h,c,7	;volatile
	line	210
	
l1810:
	movlw	low(02h)
	movwf	((c:4053))^0f00h,c	;volatile
	line	211
	
l1812:
	setf	((c:4055))^0f00h,c	;volatile
	line	212
	movlw	low(06h)
	movwf	((c:4054))^0f00h,c	;volatile
	line	213
	
l1814:
	bcf	((c:4082))^0f00h,c,2	;volatile
	line	214
	
l1816:
	bsf	((c:4082))^0f00h,c,5	;volatile
	line	215
	
l1818:
	bsf	((c:4082))^0f00h,c,7	;volatile
	line	216
	
l1820:
	bsf	((c:4053))^0f00h,c,7	;volatile
	line	217
	
l147:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Timer0_Init
	__end_of_Timer0_Init:
	signat	_Timer0_Init,89
	global	_Handle_Events

;; *************** function _Handle_Events *****************
;; Defined at:
;;		line 588 in file "main.c"
;; Parameters:    Size  Location     Type
;;  events          1   46[COMRAM] PTR const struct .
;;		 -> main@events(5), 
;;  now             4   47[COMRAM] unsigned long 
;; Auto vars:     Size  Location     Type
;;  storedTime      3   51[COMRAM] struct .
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         5       0       0
;;      Locals:         3       0       0
;;      Temps:          0       0       0
;;      Totals:         8       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 8
;; This function calls:
;;		_Buttons_ConsumeStartRelease
;;		_EEPROM_LoadTime
;;		_Outputs_Off
;;		_Pause_Countdown
;;		_Resume_Countdown
;;		_Show_Setup
;;		_Start_Countdown
;;		_Time_Adjust
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,class=CODE,space=0,reloc=2,group=0
	line	588
global __ptext15
__ptext15:
psect	text15
	file	"main.c"
	line	588
	
_Handle_Events:
;incstack = 0
	callstack 22
	line	592
	
l3140:
		movlw	4
	xorwf	((c:_appState))^00h,c,w
	btfss	status,2
	goto	u3121
	goto	u3120

u3121:
	goto	l3156
u3120:
	line	593
	
l3142:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(04h)
	addwf	fsr2l

	movf	indf2,w
	btfsc	status,2
	goto	u3131
	goto	u3130
u3131:
	goto	l291
u3130:
	line	594
	
l3144:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	movf	indf2,w
	btfsc	status,2
	goto	u3141
	goto	u3140
u3141:
	goto	l3148
u3140:
	line	595
	
l3146:
	call	_Buttons_ConsumeStartRelease	;wreg free
	line	597
	
l3148:
	movlw	low(01h)
	movwf	((c:_appState))^00h,c
	line	598
	
l3150:
	clrf	((c:_editField))^00h,c
	line	599
	call	_Outputs_Off	;wreg free
	line	600
	
l3152:
	call	_Show_Setup	;wreg free
	goto	l291
	line	605
	
l3156:
		decf	((c:_appState))^00h,c,w
	btfss	status,2
	goto	u3151
	goto	u3150

u3151:
	goto	l3192
u3150:
	line	606
	
l3158:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	btfss	indf2,(0)&7
	goto	u3161
	goto	u3160
u3161:
	goto	l3164
u3160:
	line	607
	
l3160:
	movlw	low(01h)
	movwf	((c:Time_Adjust@increment))^00h,c
	movf	((c:_editField))^00h,c,w
	
	call	_Time_Adjust
	line	608
	
l3162:
	call	_Show_Setup	;wreg free
	line	610
	
l3164:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	btfss	indf2,(1)&7
	goto	u3171
	goto	u3170
u3171:
	goto	l3170
u3170:
	line	611
	
l3166:
	movlw	low(0)
	movwf	((c:Time_Adjust@increment))^00h,c
	movf	((c:_editField))^00h,c,w
	
	call	_Time_Adjust
	line	612
	
l3168:
	call	_Show_Setup	;wreg free
	line	614
	
l3170:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	btfss	indf2,(2)&7
	goto	u3181
	goto	u3180
u3181:
	goto	l3180
u3180:
	line	615
	
l3172:
		movlw	2
	xorwf	((c:_editField))^00h,c,w
	btfss	status,2
	goto	u3191
	goto	u3190

u3191:
	goto	l3176
u3190:
	line	616
	
l3174:
	clrf	((c:_editField))^00h,c
	line	617
	goto	l3178
	line	618
	
l3176:
	incf	((c:_editField))^00h,c,w
	movwf	((c:_editField))^00h,c
	line	620
	
l3178:
	call	_Show_Setup	;wreg free
	line	622
	
l3180:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(03h)
	addwf	fsr2l

	movf	indf2,w
	btfsc	status,2
	goto	u3201
	goto	u3200
u3201:
	goto	l3188
u3200:
	line	623
	
l3182:
		movlw	low(Handle_Events@storedTime)
	movwf	((c:EEPROM_LoadTime@time))^00h,c

	call	_EEPROM_LoadTime	;wreg free
	iorlw	0
	btfsc	status,2
	goto	u3211
	goto	u3210
u3211:
	goto	l3188
u3210:
	line	624
	
l3184:
	movff	(c:Handle_Events@storedTime),(c:_setTime)
	movff	(c:Handle_Events@storedTime+1),(c:_setTime+1)
	movff	(c:Handle_Events@storedTime+2),(c:_setTime+2)
	line	625
	clrf	((c:_editField))^00h,c
	line	626
	
l3186:
	call	_Show_Setup	;wreg free
	line	629
	
l3188:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movf	indf2,w
	btfsc	status,2
	goto	u3221
	goto	u3220
u3221:
	goto	l291
u3220:
	line	630
	
l3190:
	movff	(c:Handle_Events@now),(c:Start_Countdown@now)
	movff	(c:Handle_Events@now+1),(c:Start_Countdown@now+1)
	movff	(c:Handle_Events@now+2),(c:Start_Countdown@now+2)
	movff	(c:Handle_Events@now+3),(c:Start_Countdown@now+3)
	call	_Start_Countdown	;wreg free
	goto	l291
	line	632
	
l3192:
		movlw	2
	xorwf	((c:_appState))^00h,c,w
	btfss	status,2
	goto	u3231
	goto	u3230

u3231:
	goto	l3198
u3230:
	line	633
	
l3194:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movf	indf2,w
	btfsc	status,2
	goto	u3241
	goto	u3240
u3241:
	goto	l291
u3240:
	line	634
	
l3196:
	call	_Pause_Countdown	;wreg free
	goto	l291
	line	636
	
l3198:
		movlw	3
	xorwf	((c:_appState))^00h,c,w
	btfss	status,2
	goto	u3251
	goto	u3250

u3251:
	goto	l291
u3250:
	line	637
	
l3200:
	movf	((c:Handle_Events@events))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movf	indf2,w
	btfsc	status,2
	goto	u3261
	goto	u3260
u3261:
	goto	l291
u3260:
	line	638
	
l3202:
	movff	(c:Handle_Events@now),(c:Resume_Countdown@now)
	movff	(c:Handle_Events@now+1),(c:Resume_Countdown@now+1)
	movff	(c:Handle_Events@now+2),(c:Resume_Countdown@now+2)
	movff	(c:Handle_Events@now+3),(c:Resume_Countdown@now+3)
	call	_Resume_Countdown	;wreg free
	line	641
	
l291:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Handle_Events
	__end_of_Handle_Events:
	signat	_Handle_Events,8313
	global	_Time_Adjust

;; *************** function _Time_Adjust *****************
;; Defined at:
;;		line 373 in file "main.c"
;; Parameters:    Size  Location     Type
;;  field           1    wreg     enum E2494
;;  increment       1    0[COMRAM] _Bool 
;; Auto vars:     Size  Location     Type
;;  field           1    2[COMRAM] enum E2494
;;  value           1    4[COMRAM] PTR unsigned char 
;;		 -> setTime$second(1), setTime$minute(1), setTime$hour(1), setTime(3), 
;;  maximum         1    3[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr2l, fsr2h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         3       0       0
;;      Temps:          1       0       0
;;      Totals:         5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Handle_Events
;; This function uses a non-reentrant model
;;
psect	text16,class=CODE,space=0,reloc=2,group=0
	line	373
global __ptext16
__ptext16:
psect	text16
	file	"main.c"
	line	373
	
_Time_Adjust:
;incstack = 0
	callstack 28
	movwf	((c:Time_Adjust@field))^00h,c
	line	378
	
l2860:
	movf	((c:Time_Adjust@field))^00h,c,w
	btfss	status,2
	goto	u2701
	goto	u2700
u2701:
	goto	l2864
u2700:
	line	379
	
l2862:
		movlw	low(_setTime)
	movwf	((c:Time_Adjust@value))^00h,c

	line	380
	movlw	low(063h)
	movwf	((c:Time_Adjust@maximum))^00h,c
	line	381
	goto	l2870
	
l2864:
		decf	((c:Time_Adjust@field))^00h,c,w
	btfss	status,2
	goto	u2711
	goto	u2710

u2711:
	goto	l2868
u2710:
	line	382
	
l2866:
		movlw	low(_setTime+01h)
	movwf	((c:Time_Adjust@value))^00h,c

	line	383
	movlw	low(03Bh)
	movwf	((c:Time_Adjust@maximum))^00h,c
	line	384
	goto	l2870
	line	385
	
l2868:
		movlw	low(_setTime+02h)
	movwf	((c:Time_Adjust@value))^00h,c

	line	386
	movlw	low(03Bh)
	movwf	((c:Time_Adjust@maximum))^00h,c
	line	389
	
l2870:
	movf	((c:Time_Adjust@increment))^00h,c,w
	btfsc	status,2
	goto	u2721
	goto	u2720
u2721:
	goto	l2878
u2720:
	line	390
	
l2872:
	movf	((c:Time_Adjust@value))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
		movf	((c:Time_Adjust@maximum))^00h,c,w
	subwf	postinc2,w
	btfss	status,0
	goto	u2731
	goto	u2730

u2731:
	goto	l2876
u2730:
	line	391
	
l2874:
	movf	((c:Time_Adjust@value))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	clrf	indf2
	line	392
	goto	l218
	line	393
	
l2876:
	movf	((c:Time_Adjust@value))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	incf	indf2

	goto	l218
	line	395
	
l2878:
	movf	((c:Time_Adjust@value))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movf	indf2,w
	btfss	status,2
	goto	u2741
	goto	u2740
u2741:
	goto	l2882
u2740:
	line	396
	
l2880:
	movf	((c:Time_Adjust@value))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movff	(c:Time_Adjust@maximum),indf2

	line	397
	goto	l218
	line	398
	
l2882:
	movf	((c:Time_Adjust@value))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	decf	indf2

	line	400
	
l218:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Time_Adjust
	__end_of_Time_Adjust:
	signat	_Time_Adjust,8313
	global	_Start_Countdown

;; *************** function _Start_Countdown *****************
;; Defined at:
;;		line 520 in file "main.c"
;; Parameters:    Size  Location     Type
;;  now             4   42[COMRAM] unsigned long 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 3
;; This function calls:
;;		_EEPROM_SaveTime
;;		_Outputs_CountdownOn
;;		_Show_Countdown
;;		_Time_IsZero
;; This function is called by:
;;		_Handle_Events
;; This function uses a non-reentrant model
;;
psect	text17,class=CODE,space=0,reloc=2,group=0
	line	520
global __ptext17
__ptext17:
psect	text17
	file	"main.c"
	line	520
	
_Start_Countdown:
;incstack = 0
	callstack 26
	line	522
	
l2908:
		movlw	low(_setTime)
	movwf	((c:Time_IsZero@time))^00h,c

	call	_Time_IsZero	;wreg free
	iorlw	0
	btfsc	status,2
	goto	u2811
	goto	u2810
u2811:
	goto	l2912
u2810:
	goto	l262
	line	526
	
l2912:
		movlw	low(_setTime)
	movwf	((c:EEPROM_SaveTime@time))^00h,c

	call	_EEPROM_SaveTime	;wreg free
	line	527
	
l2914:
	movff	(c:_setTime),(c:_remainingTime)
	movff	(c:_setTime+1),(c:_remainingTime+1)
	movff	(c:_setTime+2),(c:_remainingTime+2)
	line	528
	
l2916:
	movlw	low(02h)
	movwf	((c:_appState))^00h,c
	line	529
	
l2918:
	movff	(c:Start_Countdown@now),(_lastSecondAt)
	movff	(c:Start_Countdown@now+1),(_lastSecondAt+1)
	movff	(c:Start_Countdown@now+2),(_lastSecondAt+2)
	movff	(c:Start_Countdown@now+3),(_lastSecondAt+3)
	line	530
	
l2920:
	call	_Outputs_CountdownOn	;wreg free
	line	531
	
l2922:
		movlw	low(STR_9)
	movwf	((c:Show_Countdown@title))^00h,c
	movlw	high(STR_9)
	movwf	((c:Show_Countdown@title+1))^00h,c

	call	_Show_Countdown	;wreg free
	line	532
	
l262:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Start_Countdown
	__end_of_Start_Countdown:
	signat	_Start_Countdown,4217
	global	_Time_IsZero

;; *************** function _Time_IsZero *****************
;; Defined at:
;;		line 349 in file "main.c"
;; Parameters:    Size  Location     Type
;;  time            1    0[COMRAM] PTR const struct .
;;		 -> remainingTime(3), setTime(3), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      _Bool 
;; Registers used:
;;		wreg, fsr2l, fsr2h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         1       0       0
;;      Temps:          0       0       0
;;      Totals:         2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Decrement
;;		_Start_Countdown
;; This function uses a non-reentrant model
;;
psect	text18,class=CODE,space=0,reloc=2,group=0
	line	349
global __ptext18
__ptext18:
psect	text18
	file	"main.c"
	line	349
	
_Time_IsZero:
;incstack = 0
	callstack 27
	line	351
	
l2760:
	clrf	((c:_Time_IsZero$947))^00h,c
	
l2762:
	movf	((c:Time_IsZero@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movf	indf2,w
	btfss	status,2
	goto	u2561
	goto	u2560
u2561:
	goto	l196
u2560:
	
l2764:
	movf	((c:Time_IsZero@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	movf	indf2,w
	btfss	status,2
	goto	u2571
	goto	u2570
u2571:
	goto	l196
u2570:
	
l2766:
	movf	((c:Time_IsZero@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movf	indf2,w
	btfss	status,2
	goto	u2581
	goto	u2580
u2581:
	goto	l196
u2580:
	
l2768:
	movlw	low(01h)
	movwf	((c:_Time_IsZero$947))^00h,c
	
l196:
	movf	((c:_Time_IsZero$947))^00h,c,w
	line	352
	
l197:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Time_IsZero
	__end_of_Time_IsZero:
	signat	_Time_IsZero,4217
	global	_EEPROM_SaveTime

;; *************** function _EEPROM_SaveTime *****************
;; Defined at:
;;		line 451 in file "main.c"
;; Parameters:    Size  Location     Type
;;  time            1    6[COMRAM] PTR const struct .
;;		 -> setTime(3), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr2l, fsr2h, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_EEPROM_Check
;;		_EEPROM_Write
;; This function is called by:
;;		_Start_Countdown
;; This function uses a non-reentrant model
;;
psect	text19,class=CODE,space=0,reloc=2,group=0
	line	451
global __ptext19
__ptext19:
psect	text19
	file	"main.c"
	line	451
	
_EEPROM_SaveTime:
;incstack = 0
	callstack 26
	line	453
	
l2772:
	movlw	low(0A5h)
	movwf	((c:EEPROM_Write@value))^00h,c
	movlw	(0)&0ffh
	
	call	_EEPROM_Write
	line	454
	
l2774:
	movf	((c:EEPROM_SaveTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movf	indf2,w
	movwf	((c:EEPROM_Write@value))^00h,c
	movlw	(01h)&0ffh
	
	call	_EEPROM_Write
	line	455
	
l2776:
	movf	((c:EEPROM_SaveTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	movf	indf2,w
	movwf	((c:EEPROM_Write@value))^00h,c
	movlw	(02h)&0ffh
	
	call	_EEPROM_Write
	line	456
	
l2778:
	movf	((c:EEPROM_SaveTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movf	indf2,w
	movwf	((c:EEPROM_Write@value))^00h,c
	movlw	(03h)&0ffh
	
	call	_EEPROM_Write
	line	457
	
l2780:
		movff	(c:EEPROM_SaveTime@time),(c:EEPROM_Check@time)

	call	_EEPROM_Check	;wreg free
	movwf	((c:EEPROM_Write@value))^00h,c
	movlw	(04h)&0ffh
	
	call	_EEPROM_Write
	line	458
	
l236:
	return	;funcret
	callstack 0
GLOBAL	__end_of_EEPROM_SaveTime
	__end_of_EEPROM_SaveTime:
	signat	_EEPROM_SaveTime,4217
	global	_EEPROM_Write

;; *************** function _EEPROM_Write *****************
;; Defined at:
;;		line 415 in file "main.c"
;; Parameters:    Size  Location     Type
;;  address         1    wreg     unsigned char 
;;  value           1    3[COMRAM] unsigned char 
;; Auto vars:     Size  Location     Type
;;  address         1    4[COMRAM] unsigned char 
;;  interruptsEn    1    5[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         2       0       0
;;      Temps:          0       0       0
;;      Totals:         3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_EEPROM_SaveTime
;; This function uses a non-reentrant model
;;
psect	text20,class=CODE,space=0,reloc=2,group=0
	line	415
global __ptext20
__ptext20:
psect	text20
	file	"main.c"
	line	415
	
_EEPROM_Write:
;incstack = 0
	callstack 26
	movwf	((c:EEPROM_Write@address))^00h,c
	line	419
	
l2706:
	movff	(c:EEPROM_Write@address),(c:4009)	;volatile
	line	420
	
l2708:
	movff	(c:EEPROM_Write@value),(c:4008)	;volatile
	line	421
	
l2710:
	bcf	((c:4006))^0f00h,c,7	;volsfr
	line	422
	
l2712:
	bcf	((c:4006))^0f00h,c,6	;volsfr
	line	423
	
l2714:
	bsf	((c:4006))^0f00h,c,2	;volsfr
	line	425
	
l2716:
	movlw	0
	btfsc	((c:4082))^0f00h,c,7	;volatile
	movlw	1
	movwf	((c:EEPROM_Write@interruptsEnabled))^00h,c
	line	426
	
l2718:
	bcf	((c:4082))^0f00h,c,7	;volatile
	line	427
	
l2720:
	movlw	low(055h)
	movwf	((c:4007))^0f00h,c	;volsfr
	line	428
	
l2722:
	movlw	low(0AAh)
	movwf	((c:4007))^0f00h,c	;volsfr
	line	429
	
l2724:
	bsf	((c:4006))^0f00h,c,1	;volsfr
	line	430
	
l2726:
	btfsc	(c:EEPROM_Write@interruptsEnabled)^00h,c,0
	bra	u2515
	bcf	((c:4082))^0f00h,c,7	;volatile
	bra	u2516
	u2515:
	bsf	((c:4082))^0f00h,c,7	;volatile
	u2516:

	line	433
	
l224:
	line	432
	btfsc	((c:4006))^0f00h,c,1	;volsfr
	goto	u2521
	goto	u2520
u2521:
	goto	l224
u2520:
	
l226:
	line	434
	bcf	((c:4006))^0f00h,c,2	;volsfr
	line	435
	
l227:
	return	;funcret
	callstack 0
GLOBAL	__end_of_EEPROM_Write
	__end_of_EEPROM_Write:
	signat	_EEPROM_Write,8313
	global	_Show_Setup

;; *************** function _Show_Setup *****************
;; Defined at:
;;		line 483 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  text            9   31[COMRAM] unsigned char [9]
;;  fieldName       2   40[COMRAM] PTR const unsigned char 
;;		 -> STR_5(3), STR_4(5), STR_3(4), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:        11       0       0
;;      Temps:          0       0       0
;;      Totals:        11       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_OLED_Clear
;;		_OLED_WriteTextCenteredAtY
;;		_OLED_WriteTextDoubleCentered
;;		_Time_ToText
;; This function is called by:
;;		_main
;;		_Handle_Events
;; This function uses a non-reentrant model
;;
psect	text21,class=CODE,space=0,reloc=2,group=0
	line	483
global __ptext21
__ptext21:
psect	text21
	file	"main.c"
	line	483
	
_Show_Setup:
;incstack = 0
	callstack 28
	line	488
	
l2802:
		movlw	low(_setTime)
	movwf	((c:Time_ToText@time))^00h,c

		movlw	low(Show_Setup@text)
	movwf	((c:Time_ToText@text))^00h,c

	call	_Time_ToText	;wreg free
	line	489
	
l2804:
	movf	((c:_editField))^00h,c,w
	btfss	status,2
	goto	u2591
	goto	u2590
u2591:
	goto	l2808
u2590:
	line	490
	
l2806:
		movlw	low(STR_3)
	movwf	((c:Show_Setup@fieldName))^00h,c
	movlw	high(STR_3)
	movwf	((c:Show_Setup@fieldName+1))^00h,c

	line	491
	goto	l2814
	
l2808:
		decf	((c:_editField))^00h,c,w
	btfss	status,2
	goto	u2601
	goto	u2600

u2601:
	goto	l2812
u2600:
	line	492
	
l2810:
		movlw	low(STR_4)
	movwf	((c:Show_Setup@fieldName))^00h,c
	movlw	high(STR_4)
	movwf	((c:Show_Setup@fieldName+1))^00h,c

	line	493
	goto	l2814
	line	494
	
l2812:
		movlw	low(STR_5)
	movwf	((c:Show_Setup@fieldName))^00h,c
	movlw	high(STR_5)
	movwf	((c:Show_Setup@fieldName+1))^00h,c

	line	497
	
l2814:
	call	_OLED_Clear	;wreg free
	line	498
	
l2816:
		movlw	low(STR_6)
	movwf	((c:OLED_WriteTextCenteredAtY@text))^00h,c
	movlw	high(STR_6)
	movwf	((c:OLED_WriteTextCenteredAtY@text+1))^00h,c

	movlw	(0Dh)&0ffh
	
	call	_OLED_WriteTextCenteredAtY
	line	499
	
l2818:
		movlw	low(Show_Setup@text)
	movwf	((c:OLED_WriteTextDoubleCentered@text))^00h,c

	movlw	(04h)&0ffh
	
	call	_OLED_WriteTextDoubleCentered
	line	500
	
l2820:
		movff	(c:Show_Setup@fieldName),(c:OLED_WriteTextCenteredAtY@text)
	movff	(c:Show_Setup@fieldName+1),(c:OLED_WriteTextCenteredAtY@text+1)

	movlw	(038h)&0ffh
	
	call	_OLED_WriteTextCenteredAtY
	line	501
	
l252:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Show_Setup
	__end_of_Show_Setup:
	signat	_Show_Setup,89
	global	_Resume_Countdown

;; *************** function _Resume_Countdown *****************
;; Defined at:
;;		line 540 in file "main.c"
;; Parameters:    Size  Location     Type
;;  now             4   42[COMRAM] unsigned long 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_Outputs_CountdownOn
;;		_Show_Countdown
;; This function is called by:
;;		_Handle_Events
;; This function uses a non-reentrant model
;;
psect	text22,class=CODE,space=0,reloc=2,group=0
	line	540
global __ptext22
__ptext22:
psect	text22
	file	"main.c"
	line	540
	
_Resume_Countdown:
;incstack = 0
	callstack 27
	line	542
	
l2928:
	movlw	low(02h)
	movwf	((c:_appState))^00h,c
	line	543
	
l2930:
	movff	(c:Resume_Countdown@now),(_lastSecondAt)
	movff	(c:Resume_Countdown@now+1),(_lastSecondAt+1)
	movff	(c:Resume_Countdown@now+2),(_lastSecondAt+2)
	movff	(c:Resume_Countdown@now+3),(_lastSecondAt+3)
	line	544
	
l2932:
	call	_Outputs_CountdownOn	;wreg free
	line	545
	
l2934:
		movlw	low(STR_11)
	movwf	((c:Show_Countdown@title))^00h,c
	movlw	high(STR_11)
	movwf	((c:Show_Countdown@title+1))^00h,c

	call	_Show_Countdown	;wreg free
	line	546
	
l268:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Resume_Countdown
	__end_of_Resume_Countdown:
	signat	_Resume_Countdown,4217
	global	_Outputs_CountdownOn

;; *************** function _Outputs_CountdownOn *****************
;; Defined at:
;;		line 228 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Start_Countdown
;;		_Resume_Countdown
;; This function uses a non-reentrant model
;;
psect	text23,class=CODE,space=0,reloc=2,group=0
	line	228
global __ptext23
__ptext23:
psect	text23
	file	"main.c"
	line	228
	
_Outputs_CountdownOn:
;incstack = 0
	callstack 27
	line	230
	
l2758:
	bsf	((c:3979))^0f00h,c,1	;volatile
	line	231
	bcf	((c:3979))^0f00h,c,2	;volatile
	line	232
	bcf	((c:3979))^0f00h,c,3	;volatile
	line	233
	bsf	((c:3979))^0f00h,c,5	;volatile
	line	234
	
l153:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Outputs_CountdownOn
	__end_of_Outputs_CountdownOn:
	signat	_Outputs_CountdownOn,89
	global	_Pause_Countdown

;; *************** function _Pause_Countdown *****************
;; Defined at:
;;		line 534 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 7
;; This function calls:
;;		_Show_Countdown
;; This function is called by:
;;		_Handle_Events
;; This function uses a non-reentrant model
;;
psect	text24,class=CODE,space=0,reloc=2,group=0
	line	534
global __ptext24
__ptext24:
psect	text24
	file	"main.c"
	line	534
	
_Pause_Countdown:
;incstack = 0
	callstack 22
	line	536
	
l2924:
	movlw	low(03h)
	movwf	((c:_appState))^00h,c
	line	537
	
l2926:
		movlw	low(STR_10)
	movwf	((c:Show_Countdown@title))^00h,c
	movlw	high(STR_10)
	movwf	((c:Show_Countdown@title+1))^00h,c

	call	_Show_Countdown	;wreg free
	line	538
	
l265:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Pause_Countdown
	__end_of_Pause_Countdown:
	signat	_Pause_Countdown,89
	global	_Show_Countdown

;; *************** function _Show_Countdown *****************
;; Defined at:
;;		line 503 in file "main.c"
;; Parameters:    Size  Location     Type
;;  title           2   31[COMRAM] PTR const unsigned char 
;;		 -> STR_12(16), STR_11(16), STR_10(7), STR_9(16), 
;; Auto vars:     Size  Location     Type
;;  text            9   33[COMRAM] unsigned char [9]
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         2       0       0
;;      Locals:         9       0       0
;;      Temps:          0       0       0
;;      Totals:        11       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_OLED_Clear
;;		_OLED_WriteTextCenteredAtY
;;		_OLED_WriteTextDoubleCentered
;;		_Time_ToText
;; This function is called by:
;;		_Start_Countdown
;;		_Pause_Countdown
;;		_Resume_Countdown
;;		_Update_Countdown
;; This function uses a non-reentrant model
;;
psect	text25,class=CODE,space=0,reloc=2,group=0
	line	503
global __ptext25
__ptext25:
psect	text25
	file	"main.c"
	line	503
	
_Show_Countdown:
;incstack = 0
	callstack 27
	line	507
	
l2782:
		movlw	low(_remainingTime)
	movwf	((c:Time_ToText@time))^00h,c

		movlw	low(Show_Countdown@text)
	movwf	((c:Time_ToText@text))^00h,c

	call	_Time_ToText	;wreg free
	line	508
	
l2784:
	call	_OLED_Clear	;wreg free
	line	509
	
l2786:
		movff	(c:Show_Countdown@title),(c:OLED_WriteTextCenteredAtY@text)
	movff	(c:Show_Countdown@title+1),(c:OLED_WriteTextCenteredAtY@text+1)

	movlw	(0Dh)&0ffh
	
	call	_OLED_WriteTextCenteredAtY
	line	510
	
l2788:
		movlw	low(Show_Countdown@text)
	movwf	((c:OLED_WriteTextDoubleCentered@text))^00h,c

	movlw	(04h)&0ffh
	
	call	_OLED_WriteTextDoubleCentered
	line	511
	
l255:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Show_Countdown
	__end_of_Show_Countdown:
	signat	_Show_Countdown,4217
	global	_Time_ToText

;; *************** function _Time_ToText *****************
;; Defined at:
;;		line 402 in file "main.c"
;; Parameters:    Size  Location     Type
;;  time            1    7[COMRAM] PTR const struct .
;;		 -> remainingTime(3), setTime(3), 
;;  text            1    8[COMRAM] PTR unsigned char 
;;		 -> Show_Countdown@text(9), Show_Setup@text(9), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         2       0       0
;;      Locals:         0       0       0
;;      Temps:          1       0       0
;;      Totals:         3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		___lwdiv
;;		___lwmod
;; This function is called by:
;;		_Show_Setup
;;		_Show_Countdown
;; This function uses a non-reentrant model
;;
psect	text26,class=CODE,space=0,reloc=2,group=0
	line	402
global __ptext26
__ptext26:
psect	text26
	file	"main.c"
	line	402
	
_Time_ToText:
;incstack = 0
	callstack 26
	line	404
	
l2694:
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movf	((c:Time_ToText@time))^00h,c,w
	movwf	fsr1l
	clrf	fsr1h
	movf	indf1,w
	movwf	(??_Time_ToText+0)^00h,c
	movf	((??_Time_ToText+0))^00h,c,w
	movwf	((c:___lwdiv@dividend))^00h,c
	clrf	((c:___lwdiv@dividend+1))^00h,c
	clrf	((c:___lwdiv@divisor+1))^00h,c
	movlw	low(0Ah)
	movwf	((c:___lwdiv@divisor))^00h,c
	call	___lwdiv	;wreg free
	movf	(0+?___lwdiv)^00h,c,w
	addlw	low(030h)
	movwf	indf2,c

	line	405
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	movf	((c:Time_ToText@time))^00h,c,w
	movwf	fsr1l
	clrf	fsr1h
	movf	indf1,w
	movwf	(??_Time_ToText+0)^00h,c
	movf	((??_Time_ToText+0))^00h,c,w
	movwf	((c:___lwmod@dividend))^00h,c
	clrf	((c:___lwmod@dividend+1))^00h,c
	clrf	((c:___lwmod@divisor+1))^00h,c
	movlw	low(0Ah)
	movwf	((c:___lwmod@divisor))^00h,c
	call	___lwmod	;wreg free
	movf	(0+?___lwmod)^00h,c,w
	addlw	low(030h)
	movwf	indf2,c

	line	406
	
l2696:
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movlw	low(03Ah)
	movwf	indf2
	line	407
	
l2698:
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(03h)
	addwf	fsr2l

	movf	((c:Time_ToText@time))^00h,c,w
	movwf	fsr1l
	clrf	fsr1h
	movlw	low(01h)
	addwf	fsr1l

	movf	indf1,w
	movwf	(??_Time_ToText+0)^00h,c
	movf	((??_Time_ToText+0))^00h,c,w
	movwf	((c:___lwdiv@dividend))^00h,c
	clrf	((c:___lwdiv@dividend+1))^00h,c
	clrf	((c:___lwdiv@divisor+1))^00h,c
	movlw	low(0Ah)
	movwf	((c:___lwdiv@divisor))^00h,c
	call	___lwdiv	;wreg free
	movf	(0+?___lwdiv)^00h,c,w
	addlw	low(030h)
	movwf	indf2,c

	line	408
	
l2700:
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(04h)
	addwf	fsr2l

	movf	((c:Time_ToText@time))^00h,c,w
	movwf	fsr1l
	clrf	fsr1h
	movlw	low(01h)
	addwf	fsr1l

	movf	indf1,w
	movwf	(??_Time_ToText+0)^00h,c
	movf	((??_Time_ToText+0))^00h,c,w
	movwf	((c:___lwmod@dividend))^00h,c
	clrf	((c:___lwmod@dividend+1))^00h,c
	clrf	((c:___lwmod@divisor+1))^00h,c
	movlw	low(0Ah)
	movwf	((c:___lwmod@divisor))^00h,c
	call	___lwmod	;wreg free
	movf	(0+?___lwmod)^00h,c,w
	addlw	low(030h)
	movwf	indf2,c

	line	409
	
l2702:
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(05h)
	addwf	fsr2l

	movlw	low(03Ah)
	movwf	indf2
	line	410
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(06h)
	addwf	fsr2l

	movf	((c:Time_ToText@time))^00h,c,w
	movwf	fsr1l
	clrf	fsr1h
	movlw	low(02h)
	addwf	fsr1l

	movf	indf1,w
	movwf	(??_Time_ToText+0)^00h,c
	movf	((??_Time_ToText+0))^00h,c,w
	movwf	((c:___lwdiv@dividend))^00h,c
	clrf	((c:___lwdiv@dividend+1))^00h,c
	clrf	((c:___lwdiv@divisor+1))^00h,c
	movlw	low(0Ah)
	movwf	((c:___lwdiv@divisor))^00h,c
	call	___lwdiv	;wreg free
	movf	(0+?___lwdiv)^00h,c,w
	addlw	low(030h)
	movwf	indf2,c

	line	411
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(07h)
	addwf	fsr2l

	movf	((c:Time_ToText@time))^00h,c,w
	movwf	fsr1l
	clrf	fsr1h
	movlw	low(02h)
	addwf	fsr1l

	movf	indf1,w
	movwf	(??_Time_ToText+0)^00h,c
	movf	((??_Time_ToText+0))^00h,c,w
	movwf	((c:___lwmod@dividend))^00h,c
	clrf	((c:___lwmod@dividend+1))^00h,c
	clrf	((c:___lwmod@divisor+1))^00h,c
	movlw	low(0Ah)
	movwf	((c:___lwmod@divisor))^00h,c
	call	___lwmod	;wreg free
	movf	(0+?___lwmod)^00h,c,w
	addlw	low(030h)
	movwf	indf2,c

	line	412
	
l2704:
	movf	((c:Time_ToText@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(08h)
	addwf	fsr2l

	clrf	indf2
	line	413
	
l221:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Time_ToText
	__end_of_Time_ToText:
	signat	_Time_ToText,8313
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 7 in file "C:\Program Files\Microchip\xc8\v3.10\pic\sources\c99\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  dividend        2    0[COMRAM] unsigned int 
;;  divisor         2    2[COMRAM] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    4[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMRAM] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         1       0       0
;;      Temps:          0       0       0
;;      Totals:         5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_ToText
;; This function uses a non-reentrant model
;;
psect	text27,class=CODE,space=0,reloc=2,group=1
	file	"C:\Program Files\Microchip\xc8\v3.10\pic\sources\c99\common\lwmod.c"
	line	7
global __ptext27
__ptext27:
psect	text27
	file	"C:\Program Files\Microchip\xc8\v3.10\pic\sources\c99\common\lwmod.c"
	line	7
	
___lwmod:
;incstack = 0
	callstack 25
	line	12
	
l2678:
	movf	((c:___lwmod@divisor))^00h,c,w
iorwf	((c:___lwmod@divisor+1))^00h,c,w
	btfsc	status,2
	goto	u2481
	goto	u2480

u2481:
	goto	l1140
u2480:
	line	13
	
l2680:
	movlw	low(01h)
	movwf	((c:___lwmod@counter))^00h,c
	line	14
	goto	l2684
	line	15
	
l2682:
	bcf	status,0
	rlcf	((c:___lwmod@divisor))^00h,c
	rlcf	((c:___lwmod@divisor+1))^00h,c
	line	16
	incf	((c:___lwmod@counter))^00h,c
	line	14
	
l2684:
	
	btfss	((c:___lwmod@divisor+1))^00h,c,(15)&7
	goto	u2491
	goto	u2490
u2491:
	goto	l2682
u2490:
	line	19
	
l2686:
		movf	((c:___lwmod@divisor))^00h,c,w
	subwf	((c:___lwmod@dividend))^00h,c,w
	movf	((c:___lwmod@divisor+1))^00h,c,w
	subwfb	((c:___lwmod@dividend+1))^00h,c,w
	btfss	status,0
	goto	u2501
	goto	u2500

u2501:
	goto	l2690
u2500:
	line	20
	
l2688:
	movf	((c:___lwmod@divisor))^00h,c,w
	subwf	((c:___lwmod@dividend))^00h,c
	movf	((c:___lwmod@divisor+1))^00h,c,w
	subwfb	((c:___lwmod@dividend+1))^00h,c

	line	21
	
l2690:
	bcf	status,0
	rrcf	((c:___lwmod@divisor+1))^00h,c
	rrcf	((c:___lwmod@divisor))^00h,c
	line	22
	
l2692:
	decfsz	((c:___lwmod@counter))^00h,c
	
	goto	l2686
	line	23
	
l1140:
	line	24
	movff	(c:___lwmod@dividend),(c:?___lwmod)
	movff	(c:___lwmod@dividend+1),(c:?___lwmod+1)
	line	25
	
l1147:
	return	;funcret
	callstack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 7 in file "C:\Program Files\Microchip\xc8\v3.10\pic\sources\c99\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  dividend        2    0[COMRAM] unsigned int 
;;  divisor         2    2[COMRAM] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    4[COMRAM] unsigned int 
;;  counter         1    6[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMRAM] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         3       0       0
;;      Temps:          0       0       0
;;      Totals:         7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_ToText
;; This function uses a non-reentrant model
;;
psect	text28,class=CODE,space=0,reloc=2,group=1
	file	"C:\Program Files\Microchip\xc8\v3.10\pic\sources\c99\common\lwdiv.c"
	line	7
global __ptext28
__ptext28:
psect	text28
	file	"C:\Program Files\Microchip\xc8\v3.10\pic\sources\c99\common\lwdiv.c"
	line	7
	
___lwdiv:
;incstack = 0
	callstack 25
	line	13
	
l2656:
	clrf	((c:___lwdiv@quotient+1))^00h,c
	movlw	low(0)
	movwf	((c:___lwdiv@quotient))^00h,c
	line	14
	
l2658:
	movf	((c:___lwdiv@divisor))^00h,c,w
iorwf	((c:___lwdiv@divisor+1))^00h,c,w
	btfsc	status,2
	goto	u2451
	goto	u2450

u2451:
	goto	l1130
u2450:
	line	15
	
l2660:
	movlw	low(01h)
	movwf	((c:___lwdiv@counter))^00h,c
	line	16
	goto	l2664
	line	17
	
l2662:
	bcf	status,0
	rlcf	((c:___lwdiv@divisor))^00h,c
	rlcf	((c:___lwdiv@divisor+1))^00h,c
	line	18
	incf	((c:___lwdiv@counter))^00h,c
	line	16
	
l2664:
	
	btfss	((c:___lwdiv@divisor+1))^00h,c,(15)&7
	goto	u2461
	goto	u2460
u2461:
	goto	l2662
u2460:
	line	21
	
l2666:
	bcf	status,0
	rlcf	((c:___lwdiv@quotient))^00h,c
	rlcf	((c:___lwdiv@quotient+1))^00h,c
	line	22
	
l2668:
		movf	((c:___lwdiv@divisor))^00h,c,w
	subwf	((c:___lwdiv@dividend))^00h,c,w
	movf	((c:___lwdiv@divisor+1))^00h,c,w
	subwfb	((c:___lwdiv@dividend+1))^00h,c,w
	btfss	status,0
	goto	u2471
	goto	u2470

u2471:
	goto	l2674
u2470:
	line	23
	
l2670:
	movf	((c:___lwdiv@divisor))^00h,c,w
	subwf	((c:___lwdiv@dividend))^00h,c
	movf	((c:___lwdiv@divisor+1))^00h,c,w
	subwfb	((c:___lwdiv@dividend+1))^00h,c

	line	24
	
l2672:
	bsf	(0+(0/8)+(c:___lwdiv@quotient))^00h,c,(0)&7
	line	26
	
l2674:
	bcf	status,0
	rrcf	((c:___lwdiv@divisor+1))^00h,c
	rrcf	((c:___lwdiv@divisor))^00h,c
	line	27
	
l2676:
	decfsz	((c:___lwdiv@counter))^00h,c
	
	goto	l2666
	line	28
	
l1130:
	line	29
	movff	(c:___lwdiv@quotient),(c:?___lwdiv)
	movff	(c:___lwdiv@quotient+1),(c:?___lwdiv+1)
	line	30
	
l1137:
	return	;funcret
	callstack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_OLED_WriteTextDoubleCentered

;; *************** function _OLED_WriteTextDoubleCentered *****************
;; Defined at:
;;		line 233 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  page            1    wreg     unsigned char 
;;  text            1   19[COMRAM] PTR const unsigned char 
;;		 -> Show_Countdown@text(9), Show_Setup@text(9), 
;; Auto vars:     Size  Location     Type
;;  page            1   26[COMRAM] unsigned char 
;;  column          1   25[COMRAM] unsigned char 
;;  width           1   24[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         3       0       0
;;      Temps:          4       0       0
;;      Totals:         8       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_OLED_TextWidth
;;		_OLED_WriteTextDoublePage
;; This function is called by:
;;		_Show_Setup
;;		_Show_Countdown
;; This function uses a non-reentrant model
;;
psect	text29,class=CODE,space=0,reloc=2,group=0
	file	"oled_i2c.c"
	line	233
global __ptext29
__ptext29:
psect	text29
	file	"oled_i2c.c"
	line	233
	
_OLED_WriteTextDoubleCentered:
;incstack = 0
	callstack 26
	movwf	((c:OLED_WriteTextDoubleCentered@page))^00h,c
	line	235
	
l2744:
		movff	(c:OLED_WriteTextDoubleCentered@text),(c:OLED_TextWidth@text)
	clrf	((c:OLED_TextWidth@text+1))^00h,c

	call	_OLED_TextWidth	;wreg free
	mullw	02h
	movff	prodl,(c:OLED_WriteTextDoubleCentered@width)
	line	236
	
l2746:
	clrf	((c:OLED_WriteTextDoubleCentered@column))^00h,c
	line	238
	
l2748:
		movlw	080h-0
	cpfslt	((c:OLED_WriteTextDoubleCentered@width))^00h,c
	goto	u2541
	goto	u2540

u2541:
	goto	l2752
u2540:
	line	239
	
l2750:
	movlw	low(080h)
	movwf	(??_OLED_WriteTextDoubleCentered+0)^00h,c
	movlw	high(080h)
	movwf	1+(??_OLED_WriteTextDoubleCentered+0)^00h,c
	movf	((c:OLED_WriteTextDoubleCentered@width))^00h,c,w
	subwf	(??_OLED_WriteTextDoubleCentered+0)^00h,c
	movlw	0
	subwfb	(??_OLED_WriteTextDoubleCentered+0+1)^00h,c
	bcf	status,0
	rrcf	(??_OLED_WriteTextDoubleCentered+0+1)^00h,c,w
	movwf	(??_OLED_WriteTextDoubleCentered+2+1)^00h,c
	rrcf	(??_OLED_WriteTextDoubleCentered+0)^00h,c,w
	movwf	(??_OLED_WriteTextDoubleCentered+2)^00h,c
	movf	(??_OLED_WriteTextDoubleCentered+2)^00h,c,w
	movwf	((c:OLED_WriteTextDoubleCentered@column))^00h,c
	line	242
	
l2752:
	movff	(c:OLED_WriteTextDoubleCentered@page),(c:OLED_WriteTextDoublePage@page)
		movff	(c:OLED_WriteTextDoubleCentered@text),(c:OLED_WriteTextDoublePage@text)

	movlw	low(0)
	movwf	((c:OLED_WriteTextDoublePage@lowerPage))^00h,c
	movf	((c:OLED_WriteTextDoubleCentered@column))^00h,c,w
	
	call	_OLED_WriteTextDoublePage
	line	243
	
l2754:
		movlw	07h-0
	cpfslt	((c:OLED_WriteTextDoubleCentered@page))^00h,c
	goto	u2551
	goto	u2550

u2551:
	goto	l414
u2550:
	line	244
	
l2756:
	incf	((c:OLED_WriteTextDoubleCentered@page))^00h,c,w
	movwf	((c:OLED_WriteTextDoublePage@page))^00h,c
		movff	(c:OLED_WriteTextDoubleCentered@text),(c:OLED_WriteTextDoublePage@text)

	movlw	low(01h)
	movwf	((c:OLED_WriteTextDoublePage@lowerPage))^00h,c
	movf	((c:OLED_WriteTextDoubleCentered@column))^00h,c,w
	
	call	_OLED_WriteTextDoublePage
	line	246
	
l414:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_WriteTextDoubleCentered
	__end_of_OLED_WriteTextDoubleCentered:
	signat	_OLED_WriteTextDoubleCentered,8313
	global	_OLED_WriteTextDoublePage

;; *************** function _OLED_WriteTextDoublePage *****************
;; Defined at:
;;		line 340 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  column          1    wreg     unsigned char 
;;  page            1    7[COMRAM] unsigned char 
;;  text            1    8[COMRAM] PTR const unsigned char 
;;		 -> Show_Countdown@text(9), Show_Setup@text(9), 
;;  lowerPage       1    9[COMRAM] _Bool 
;; Auto vars:     Size  Location     Type
;;  column          1   14[COMRAM] unsigned char 
;;  pointer         2   17[COMRAM] PTR const unsigned char 
;;		 -> STR_12(16), STR_11(16), STR_10(7), STR_9(16), 
;;		 -> STR_8(17), STR_7(16), Show_Countdown@text(9), STR_6(17), 
;;		 -> STR_5(3), STR_4(5), STR_3(4), Show_Setup@text(9), 
;;		 -> STR_2(20), STR_1(14), 
;;  glyph           2   12[COMRAM] PTR const unsigned char 
;;		 -> font5x7(455), glyph_unknown(5), glyph_a_acute_lower(5), glyph_a_acute_upper(5), 
;;		 -> glyph_o_double_acute_lower(5), glyph_o_double_acute_upper(5), 
;;  index           1   16[COMRAM] unsigned char 
;;  scaledColumn    1   15[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         3       0       0
;;      Locals:         7       0       0
;;      Temps:          2       0       0
;;      Totals:        12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_OLED_Data
;;		_OLED_GetGlyph
;;		_OLED_ScaleGlyph
;;		_OLED_SetCursor
;; This function is called by:
;;		_OLED_WriteTextDoubleCentered
;; This function uses a non-reentrant model
;;
psect	text30,class=CODE,space=0,reloc=2,group=0
	line	340
global __ptext30
__ptext30:
psect	text30
	file	"oled_i2c.c"
	line	340
	
_OLED_WriteTextDoublePage:
;incstack = 0
	callstack 24
	movwf	((c:OLED_WriteTextDoublePage@column))^00h,c
	line	343
	
l2630:
		movff	(c:OLED_WriteTextDoublePage@text),(c:OLED_WriteTextDoublePage@pointer)
	clrf	((c:OLED_WriteTextDoublePage@pointer+1))^00h,c

	line	348
	
l2632:
	movff	(c:OLED_WriteTextDoublePage@page),(c:OLED_SetCursor@page)
	movf	((c:OLED_WriteTextDoublePage@column))^00h,c,w
	
	call	_OLED_SetCursor
	line	349
	goto	l2654
	line	350
	
l2634:
		movlw	low(OLED_WriteTextDoublePage@pointer)
	movwf	((c:OLED_GetGlyph@text))^00h,c

	call	_OLED_GetGlyph	;wreg free
	movff	0+?_OLED_GetGlyph,(c:OLED_WriteTextDoublePage@glyph)
	movff	1+?_OLED_GetGlyph,(c:OLED_WriteTextDoublePage@glyph+1)
	line	351
	
l2636:
	clrf	((c:OLED_WriteTextDoublePage@index))^00h,c
	line	352
	
l2642:
	movff	(c:OLED_WriteTextDoublePage@lowerPage),(c:OLED_ScaleGlyph@lowerPage)
	movf	((c:OLED_WriteTextDoublePage@index))^00h,c,w
	addwf	((c:OLED_WriteTextDoublePage@glyph))^00h,c,w
	movwf	(??_OLED_WriteTextDoublePage+0)^00h,c
	movlw	0
	addwfc	((c:OLED_WriteTextDoublePage@glyph+1))^00h,c,w
	movwf	(??_OLED_WriteTextDoublePage+0+1)^00h,c
	movff	??_OLED_WriteTextDoublePage+0,tblptrl
	movff	??_OLED_WriteTextDoublePage+0+1,tblptrh
	if	0	;tblptru may be non-zero
	clrf	tblptru
	endif
	if	0	;tblptru may be non-zero
	global __mediumconst
movlw	low highword(__mediumconst)
	movwf	tblptru
	endif
	tblrd	*
	
	movf	tablat,w
	
	call	_OLED_ScaleGlyph
	movwf	((c:OLED_WriteTextDoublePage@scaledColumn))^00h,c
	line	353
	
l2644:
	movf	((c:OLED_WriteTextDoublePage@scaledColumn))^00h,c,w
	
	call	_OLED_Data
	line	354
	
l2646:
	movf	((c:OLED_WriteTextDoublePage@scaledColumn))^00h,c,w
	
	call	_OLED_Data
	line	355
	
l2648:
	incf	((c:OLED_WriteTextDoublePage@index))^00h,c
	
l2650:
		movlw	05h-1
	cpfsgt	((c:OLED_WriteTextDoublePage@index))^00h,c
	goto	u2421
	goto	u2420

u2421:
	goto	l2642
u2420:
	line	356
	
l2652:
	movlw	(0)&0ffh
	
	call	_OLED_Data
	line	357
	movlw	(0)&0ffh
	
	call	_OLED_Data
	line	349
	
l2654:
	movff	(c:OLED_WriteTextDoublePage@pointer),tblptrl
	movff	(c:OLED_WriteTextDoublePage@pointer+1),tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2437

	tblrd	*
	
	movf	tablat,w
	bra	u2430
u2437:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2430:
	iorlw	0
	btfss	status,2
	goto	u2441
	goto	u2440
u2441:
	goto	l2634
u2440:
	line	359
	
l467:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_WriteTextDoublePage
	__end_of_OLED_WriteTextDoublePage:
	signat	_OLED_WriteTextDoublePage,16505
	global	_OLED_ScaleGlyph

;; *************** function _OLED_ScaleGlyph *****************
;; Defined at:
;;		line 318 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  glyphColumn     1    wreg     const unsigned char 
;;  lowerPage       1    0[COMRAM] _Bool 
;; Auto vars:     Size  Location     Type
;;  glyphColumn     1    3[COMRAM] const unsigned char 
;;  targetBit       1    5[COMRAM] unsigned char 
;;  row             1    6[COMRAM] unsigned char 
;;  result          1    4[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0, prodl, prodh
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         4       0       0
;;      Temps:          2       0       0
;;      Totals:         7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_OLED_WriteTextDoublePage
;; This function uses a non-reentrant model
;;
psect	text31,class=CODE,space=0,reloc=2,group=0
	line	318
global __ptext31
__ptext31:
psect	text31
	file	"oled_i2c.c"
	line	318
	
_OLED_ScaleGlyph:
;incstack = 0
	callstack 24
	movwf	((c:OLED_ScaleGlyph@glyphColumn))^00h,c
	line	321
	
l2482:
	clrf	((c:OLED_ScaleGlyph@result))^00h,c
	line	323
	clrf	((c:OLED_ScaleGlyph@row))^00h,c
	line	324
	
l2488:
	movf	((c:OLED_ScaleGlyph@row))^00h,c,w
	mullw	02h
	movff	prodl,(c:OLED_ScaleGlyph@targetBit)
	line	326
	
l2490:
	movff	(c:OLED_ScaleGlyph@row),??_OLED_ScaleGlyph+0
	movlw	(01h)&0ffh
	movwf	(??_OLED_ScaleGlyph+1)^00h,c
	incf	(??_OLED_ScaleGlyph+0)^00h,c
	goto	u2024
u2025:
	bcf	status,0
	rlcf	((??_OLED_ScaleGlyph+1))^00h,c
u2024:
	decfsz	(??_OLED_ScaleGlyph+0)^00h,c
	goto	u2025
	movf	((??_OLED_ScaleGlyph+1))^00h,c,w
	andwf	((c:OLED_ScaleGlyph@glyphColumn))^00h,c,w
	iorlw	0
	btfsc	status,2
	goto	u2031
	goto	u2030
u2031:
	goto	l2502
u2030:
	line	327
	
l2492:
	movf	((c:OLED_ScaleGlyph@lowerPage))^00h,c,w
	btfss	status,2
	goto	u2041
	goto	u2040
u2041:
	goto	l2498
u2040:
	line	328
	
l2494:
		movlw	08h-0
	cpfslt	((c:OLED_ScaleGlyph@targetBit))^00h,c
	goto	u2051
	goto	u2050

u2051:
	goto	l2502
u2050:
	line	329
	
l2496:
	movff	(c:OLED_ScaleGlyph@targetBit),??_OLED_ScaleGlyph+0
	movlw	(03h)&0ffh
	movwf	(??_OLED_ScaleGlyph+1)^00h,c
	incf	(??_OLED_ScaleGlyph+0)^00h,c
	goto	u2064
u2065:
	bcf	status,0
	rlcf	((??_OLED_ScaleGlyph+1))^00h,c
u2064:
	decfsz	(??_OLED_ScaleGlyph+0)^00h,c
	goto	u2065
	movf	((??_OLED_ScaleGlyph+1))^00h,c,w
	iorwf	((c:OLED_ScaleGlyph@result))^00h,c
	goto	l2502
	line	331
	
l2498:
		movlw	08h-1
	cpfsgt	((c:OLED_ScaleGlyph@targetBit))^00h,c
	goto	u2071
	goto	u2070

u2071:
	goto	l2502
u2070:
	line	332
	
l2500:
	movff	(c:OLED_ScaleGlyph@targetBit),??_OLED_ScaleGlyph+0
	movlw	0F8h
	addwf	(??_OLED_ScaleGlyph+0)^00h,c
	movlw	(03h)&0ffh
	movwf	(??_OLED_ScaleGlyph+1)^00h,c
	incf	(??_OLED_ScaleGlyph+0)^00h,c
	goto	u2084
u2085:
	bcf	status,0
	rlcf	((??_OLED_ScaleGlyph+1))^00h,c
u2084:
	decfsz	(??_OLED_ScaleGlyph+0)^00h,c
	goto	u2085
	movf	((??_OLED_ScaleGlyph+1))^00h,c,w
	iorwf	((c:OLED_ScaleGlyph@result))^00h,c
	line	335
	
l2502:
	incf	((c:OLED_ScaleGlyph@row))^00h,c
	
l2504:
		movlw	07h-1
	cpfsgt	((c:OLED_ScaleGlyph@row))^00h,c
	goto	u2091
	goto	u2090

u2091:
	goto	l2488
u2090:
	line	337
	
l2506:
	movf	((c:OLED_ScaleGlyph@result))^00h,c,w
	line	338
	
l459:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_ScaleGlyph
	__end_of_OLED_ScaleGlyph:
	signat	_OLED_ScaleGlyph,8313
	global	_OLED_WriteTextCenteredAtY

;; *************** function _OLED_WriteTextCenteredAtY *****************
;; Defined at:
;;		line 221 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  y               1    wreg     unsigned char 
;;  text            2   22[COMRAM] PTR const unsigned char 
;;		 -> STR_12(16), STR_11(16), STR_10(7), STR_9(16), 
;;		 -> STR_8(17), STR_7(16), STR_6(17), STR_5(3), 
;;		 -> STR_4(5), STR_3(4), STR_2(20), STR_1(14), 
;; Auto vars:     Size  Location     Type
;;  y               1   28[COMRAM] unsigned char 
;;  width           1   30[COMRAM] unsigned char 
;;  column          1   29[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         2       0       0
;;      Locals:         3       0       0
;;      Temps:          4       0       0
;;      Totals:         9       0       0
;;Total ram usage:        9 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_OLED_TextWidth
;;		_OLED_WriteTextAtY
;; This function is called by:
;;		_Show_Splash
;;		_Show_Setup
;;		_Show_Countdown
;;		_Show_Expired
;; This function uses a non-reentrant model
;;
psect	text32,class=CODE,space=0,reloc=2,group=0
	line	221
global __ptext32
__ptext32:
psect	text32
	file	"oled_i2c.c"
	line	221
	
_OLED_WriteTextCenteredAtY:
;incstack = 0
	callstack 26
	movwf	((c:OLED_WriteTextCenteredAtY@y))^00h,c
	line	223
	
l2734:
		movff	(c:OLED_WriteTextCenteredAtY@text),(c:OLED_TextWidth@text)
	movff	(c:OLED_WriteTextCenteredAtY@text+1),(c:OLED_TextWidth@text+1)

	call	_OLED_TextWidth	;wreg free
	movwf	((c:OLED_WriteTextCenteredAtY@width))^00h,c
	line	224
	
l2736:
	clrf	((c:OLED_WriteTextCenteredAtY@column))^00h,c
	line	226
	
l2738:
		movlw	080h-0
	cpfslt	((c:OLED_WriteTextCenteredAtY@width))^00h,c
	goto	u2531
	goto	u2530

u2531:
	goto	l2742
u2530:
	line	227
	
l2740:
	movlw	low(080h)
	movwf	(??_OLED_WriteTextCenteredAtY+0)^00h,c
	movlw	high(080h)
	movwf	1+(??_OLED_WriteTextCenteredAtY+0)^00h,c
	movf	((c:OLED_WriteTextCenteredAtY@width))^00h,c,w
	subwf	(??_OLED_WriteTextCenteredAtY+0)^00h,c
	movlw	0
	subwfb	(??_OLED_WriteTextCenteredAtY+0+1)^00h,c
	bcf	status,0
	rrcf	(??_OLED_WriteTextCenteredAtY+0+1)^00h,c,w
	movwf	(??_OLED_WriteTextCenteredAtY+2+1)^00h,c
	rrcf	(??_OLED_WriteTextCenteredAtY+0)^00h,c,w
	movwf	(??_OLED_WriteTextCenteredAtY+2)^00h,c
	movf	(??_OLED_WriteTextCenteredAtY+2)^00h,c,w
	movwf	((c:OLED_WriteTextCenteredAtY@column))^00h,c
	line	230
	
l2742:
	movff	(c:OLED_WriteTextCenteredAtY@y),(c:OLED_WriteTextAtY@y)
		movff	(c:OLED_WriteTextCenteredAtY@text),(c:OLED_WriteTextAtY@text)
	movff	(c:OLED_WriteTextCenteredAtY@text+1),(c:OLED_WriteTextAtY@text+1)

	movf	((c:OLED_WriteTextCenteredAtY@column))^00h,c,w
	
	call	_OLED_WriteTextAtY
	line	231
	
l409:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_WriteTextCenteredAtY
	__end_of_OLED_WriteTextCenteredAtY:
	signat	_OLED_WriteTextCenteredAtY,8313
	global	_OLED_WriteTextAtY

;; *************** function _OLED_WriteTextAtY *****************
;; Defined at:
;;		line 283 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  column          1    wreg     unsigned char 
;;  y               1    7[COMRAM] unsigned char 
;;  text            2    8[COMRAM] PTR const unsigned char 
;;		 -> STR_12(16), STR_11(16), STR_10(7), STR_9(16), 
;;		 -> STR_8(17), STR_7(16), STR_6(17), STR_5(3), 
;;		 -> STR_4(5), STR_3(4), STR_2(20), STR_1(14), 
;; Auto vars:     Size  Location     Type
;;  column          1   14[COMRAM] unsigned char 
;;  pointer         2   20[COMRAM] PTR const unsigned char 
;;		 -> STR_12(16), STR_11(16), STR_10(7), STR_9(16), 
;;		 -> STR_8(17), STR_7(16), Show_Countdown@text(9), STR_6(17), 
;;		 -> STR_5(3), STR_4(5), STR_3(4), Show_Setup@text(9), 
;;		 -> STR_2(20), STR_1(14), 
;;  glyph           2   15[COMRAM] PTR const unsigned char 
;;		 -> font5x7(455), glyph_unknown(5), glyph_a_acute_lower(5), glyph_a_acute_upper(5), 
;;		 -> glyph_o_double_acute_lower(5), glyph_o_double_acute_upper(5), 
;;  index           1   19[COMRAM] unsigned char 
;;  page            1   18[COMRAM] unsigned char 
;;  shift           1   17[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         3       0       0
;;      Locals:         8       0       0
;;      Temps:          4       0       0
;;      Totals:        15       0       0
;;Total ram usage:       15 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_OLED_Data
;;		_OLED_GetGlyph
;;		_OLED_SetCursor
;; This function is called by:
;;		_OLED_WriteTextCenteredAtY
;; This function uses a non-reentrant model
;;
psect	text33,class=CODE,space=0,reloc=2,group=0
	line	283
global __ptext33
__ptext33:
psect	text33
	file	"oled_i2c.c"
	line	283
	
_OLED_WriteTextAtY:
;incstack = 0
	callstack 24
	movwf	((c:OLED_WriteTextAtY@column))^00h,c
	line	287
	
l2574:
	swapf	((c:OLED_WriteTextAtY@y))^00h,c,w
	rlncf	wreg
	andlw	(0ffh shr 3) & 0ffh
	movwf	((c:OLED_WriteTextAtY@page))^00h,c
	line	288
	
l2576:
	movf	((c:OLED_WriteTextAtY@y))^00h,c,w
	andlw	low(07h)
	movwf	((c:OLED_WriteTextAtY@shift))^00h,c
	line	291
	
l2578:
		movlw	08h-1
	cpfsgt	((c:OLED_WriteTextAtY@page))^00h,c
	goto	u2311
	goto	u2310

u2311:
	goto	l2582
u2310:
	goto	l438
	line	295
	
l2582:
	movff	(c:OLED_WriteTextAtY@page),(c:OLED_SetCursor@page)
	movf	((c:OLED_WriteTextAtY@column))^00h,c,w
	
	call	_OLED_SetCursor
	line	296
	
l2584:
		movff	(c:OLED_WriteTextAtY@text),(c:OLED_WriteTextAtY@pointer)
	movff	(c:OLED_WriteTextAtY@text+1),(c:OLED_WriteTextAtY@pointer+1)

	line	297
	goto	l2602
	line	298
	
l2586:
		movlw	low(OLED_WriteTextAtY@pointer)
	movwf	((c:OLED_GetGlyph@text))^00h,c

	call	_OLED_GetGlyph	;wreg free
	movff	0+?_OLED_GetGlyph,(c:OLED_WriteTextAtY@glyph)
	movff	1+?_OLED_GetGlyph,(c:OLED_WriteTextAtY@glyph+1)
	line	299
	
l2588:
	clrf	((c:OLED_WriteTextAtY@index))^00h,c
	line	300
	
l2594:
	movff	(c:OLED_WriteTextAtY@shift),??_OLED_WriteTextAtY+0
	movf	((c:OLED_WriteTextAtY@index))^00h,c,w
	addwf	((c:OLED_WriteTextAtY@glyph))^00h,c,w
	movwf	(??_OLED_WriteTextAtY+1)^00h,c
	movlw	0
	addwfc	((c:OLED_WriteTextAtY@glyph+1))^00h,c,w
	movwf	(??_OLED_WriteTextAtY+1+1)^00h,c
	movff	??_OLED_WriteTextAtY+1,tblptrl
	movff	??_OLED_WriteTextAtY+1+1,tblptrh
	if	0	;tblptru may be non-zero
	clrf	tblptru
	endif
	if	0	;tblptru may be non-zero
	global __mediumconst
movlw	low highword(__mediumconst)
	movwf	tblptru
	endif
	tblrd	*
	
	movff	tablat,??_OLED_WriteTextAtY+3
	incf	(??_OLED_WriteTextAtY+0)^00h,c
	goto	u2324
u2325:
	bcf	status,0
	rlcf	(??_OLED_WriteTextAtY+3)^00h,c
u2324:
	decfsz	(??_OLED_WriteTextAtY+0)^00h,c
	goto	u2325
	movf	(??_OLED_WriteTextAtY+3)^00h,c,w
	
	call	_OLED_Data
	line	301
	
l2596:
	incf	((c:OLED_WriteTextAtY@index))^00h,c
	
l2598:
		movlw	05h-1
	cpfsgt	((c:OLED_WriteTextAtY@index))^00h,c
	goto	u2331
	goto	u2330

u2331:
	goto	l2594
u2330:
	line	302
	
l2600:
	movlw	(0)&0ffh
	
	call	_OLED_Data
	line	297
	
l2602:
	movff	(c:OLED_WriteTextAtY@pointer),tblptrl
	movff	(c:OLED_WriteTextAtY@pointer+1),tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2347

	tblrd	*
	
	movf	tablat,w
	bra	u2340
u2347:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2340:
	iorlw	0
	btfss	status,2
	goto	u2351
	goto	u2350
u2351:
	goto	l2586
u2350:
	line	305
	
l2604:
	movf	((c:OLED_WriteTextAtY@shift))^00h,c,w
	btfsc	status,2
	goto	u2361
	goto	u2360
u2361:
	goto	l438
u2360:
	
l2606:
		movlw	07h-0
	cpfslt	((c:OLED_WriteTextAtY@page))^00h,c
	goto	u2371
	goto	u2370

u2371:
	goto	l438
u2370:
	line	306
	
l2608:
	incf	((c:OLED_WriteTextAtY@page))^00h,c,w
	movwf	((c:OLED_SetCursor@page))^00h,c
	movf	((c:OLED_WriteTextAtY@column))^00h,c,w
	
	call	_OLED_SetCursor
	line	307
	
l2610:
		movff	(c:OLED_WriteTextAtY@text),(c:OLED_WriteTextAtY@pointer)
	movff	(c:OLED_WriteTextAtY@text+1),(c:OLED_WriteTextAtY@pointer+1)

	line	308
	goto	l2628
	line	309
	
l2612:
		movlw	low(OLED_WriteTextAtY@pointer)
	movwf	((c:OLED_GetGlyph@text))^00h,c

	call	_OLED_GetGlyph	;wreg free
	movff	0+?_OLED_GetGlyph,(c:OLED_WriteTextAtY@glyph)
	movff	1+?_OLED_GetGlyph,(c:OLED_WriteTextAtY@glyph+1)
	line	310
	
l2614:
	clrf	((c:OLED_WriteTextAtY@index))^00h,c
	line	311
	
l2620:
	movf	((c:OLED_WriteTextAtY@shift))^00h,c,w
	sublw	low(08h)
	movwf	(??_OLED_WriteTextAtY+0)^00h,c
	movf	((c:OLED_WriteTextAtY@index))^00h,c,w
	addwf	((c:OLED_WriteTextAtY@glyph))^00h,c,w
	movwf	(??_OLED_WriteTextAtY+1)^00h,c
	movlw	0
	addwfc	((c:OLED_WriteTextAtY@glyph+1))^00h,c,w
	movwf	(??_OLED_WriteTextAtY+1+1)^00h,c
	movff	??_OLED_WriteTextAtY+1,tblptrl
	movff	??_OLED_WriteTextAtY+1+1,tblptrh
	if	0	;tblptru may be non-zero
	clrf	tblptru
	endif
	if	0	;tblptru may be non-zero
	global __mediumconst
movlw	low highword(__mediumconst)
	movwf	tblptru
	endif
	tblrd	*
	
	movff	tablat,??_OLED_WriteTextAtY+3
	incf	((??_OLED_WriteTextAtY+0))^00h,c
	goto	u2384
u2385:
	bcf	status,0
	rrcf	(??_OLED_WriteTextAtY+3)^00h,c
u2384:
	decfsz	((??_OLED_WriteTextAtY+0))^00h,c
	goto	u2385
	movf	(??_OLED_WriteTextAtY+3)^00h,c,w
	
	call	_OLED_Data
	line	312
	
l2622:
	incf	((c:OLED_WriteTextAtY@index))^00h,c
	
l2624:
		movlw	05h-1
	cpfsgt	((c:OLED_WriteTextAtY@index))^00h,c
	goto	u2391
	goto	u2390

u2391:
	goto	l2620
u2390:
	line	313
	
l2626:
	movlw	(0)&0ffh
	
	call	_OLED_Data
	line	308
	
l2628:
	movff	(c:OLED_WriteTextAtY@pointer),tblptrl
	movff	(c:OLED_WriteTextAtY@pointer+1),tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2407

	tblrd	*
	
	movf	tablat,w
	bra	u2400
u2407:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2400:
	iorlw	0
	btfss	status,2
	goto	u2411
	goto	u2410
u2411:
	goto	l2612
u2410:
	line	316
	
l438:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_WriteTextAtY
	__end_of_OLED_WriteTextAtY:
	signat	_OLED_WriteTextAtY,12409
	global	_OLED_GetGlyph

;; *************** function _OLED_GetGlyph *****************
;; Defined at:
;;		line 361 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  text            1    0[COMRAM] PTR PTR const unsigned c
;;		 -> OLED_WriteTextDoublePage@pointer(2), OLED_WriteTextAtY@pointer(2), OLED_WriteText@text(2), 
;; Auto vars:     Size  Location     Type
;;  c               1    6[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMRAM] PTR const unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, prodl, prodh
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         2       0       0
;;      Locals:         1       0       0
;;      Temps:          4       0       0
;;      Totals:         7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_OLED_WriteTextAtY
;;		_OLED_WriteTextDoublePage
;;		_OLED_WriteText
;; This function uses a non-reentrant model
;;
psect	text34,class=CODE,space=0,reloc=2,group=0
	line	361
global __ptext34
__ptext34:
psect	text34
	file	"oled_i2c.c"
	line	361
	
_OLED_GetGlyph:
;incstack = 0
	callstack 24
	line	363
	
l2426:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movff	postinc2,tblptrl
	movff	postinc2,tblptrh
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u1877

	tblrd	*
	
	movf	tablat,w
	bra	u1870
u1877:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u1870:
	movwf	((c:OLED_GetGlyph@c))^00h,c
	line	365
	
l2428:
		movlw	197
	xorwf	((c:OLED_GetGlyph@c))^00h,c,w
	btfss	status,2
	goto	u1881
	goto	u1880

u1881:
	goto	l2438
u1880:
	
l2430:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movff	postinc2,??_OLED_GetGlyph+0
	movff	postdec2,??_OLED_GetGlyph+0+1
	movlw	01h
	addwf	(??_OLED_GetGlyph+0)^00h,c
	movlw	0
	addwfc	(??_OLED_GetGlyph+0+1)^00h,c
	movff	??_OLED_GetGlyph+0,tblptrl
	movff	??_OLED_GetGlyph+0+1,tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u1897

	tblrd	*
	
	movf	tablat,w
	bra	u1890
u1897:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u1890:
	xorlw	090h
	btfss	status,2
	goto	u1901
	goto	u1900
u1901:
	goto	l2438
u1900:
	line	366
	
l2432:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	02h
	addwf	postinc2
	movlw	0
	addwfc	postdec2
	line	367
	
l2434:
		movlw	low(_glyph_o_double_acute_upper)
	movwf	((c:?_OLED_GetGlyph))^00h,c
	movlw	high(_glyph_o_double_acute_upper)
	movwf	((c:?_OLED_GetGlyph+1))^00h,c

	goto	l471
	line	370
	
l2438:
		movlw	197
	xorwf	((c:OLED_GetGlyph@c))^00h,c,w
	btfss	status,2
	goto	u1911
	goto	u1910

u1911:
	goto	l2448
u1910:
	
l2440:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movff	postinc2,??_OLED_GetGlyph+0
	movff	postdec2,??_OLED_GetGlyph+0+1
	movlw	01h
	addwf	(??_OLED_GetGlyph+0)^00h,c
	movlw	0
	addwfc	(??_OLED_GetGlyph+0+1)^00h,c
	movff	??_OLED_GetGlyph+0,tblptrl
	movff	??_OLED_GetGlyph+0+1,tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u1927

	tblrd	*
	
	movf	tablat,w
	bra	u1920
u1927:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u1920:
	xorlw	091h
	btfss	status,2
	goto	u1931
	goto	u1930
u1931:
	goto	l2448
u1930:
	line	371
	
l2442:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	02h
	addwf	postinc2
	movlw	0
	addwfc	postdec2
	line	372
	
l2444:
		movlw	low(_glyph_o_double_acute_lower)
	movwf	((c:?_OLED_GetGlyph))^00h,c
	movlw	high(_glyph_o_double_acute_lower)
	movwf	((c:?_OLED_GetGlyph+1))^00h,c

	goto	l471
	line	375
	
l2448:
		movlw	195
	xorwf	((c:OLED_GetGlyph@c))^00h,c,w
	btfss	status,2
	goto	u1941
	goto	u1940

u1941:
	goto	l2458
u1940:
	
l2450:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movff	postinc2,??_OLED_GetGlyph+0
	movff	postdec2,??_OLED_GetGlyph+0+1
	movlw	01h
	addwf	(??_OLED_GetGlyph+0)^00h,c
	movlw	0
	addwfc	(??_OLED_GetGlyph+0+1)^00h,c
	movff	??_OLED_GetGlyph+0,tblptrl
	movff	??_OLED_GetGlyph+0+1,tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u1957

	tblrd	*
	
	movf	tablat,w
	bra	u1950
u1957:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u1950:
	xorlw	081h
	btfss	status,2
	goto	u1961
	goto	u1960
u1961:
	goto	l2458
u1960:
	line	376
	
l2452:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	02h
	addwf	postinc2
	movlw	0
	addwfc	postdec2
	line	377
	
l2454:
		movlw	low(_glyph_a_acute_upper)
	movwf	((c:?_OLED_GetGlyph))^00h,c
	movlw	high(_glyph_a_acute_upper)
	movwf	((c:?_OLED_GetGlyph+1))^00h,c

	goto	l471
	line	380
	
l2458:
		movlw	195
	xorwf	((c:OLED_GetGlyph@c))^00h,c,w
	btfss	status,2
	goto	u1971
	goto	u1970

u1971:
	goto	l2468
u1970:
	
l2460:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movff	postinc2,??_OLED_GetGlyph+0
	movff	postdec2,??_OLED_GetGlyph+0+1
	movlw	01h
	addwf	(??_OLED_GetGlyph+0)^00h,c
	movlw	0
	addwfc	(??_OLED_GetGlyph+0+1)^00h,c
	movff	??_OLED_GetGlyph+0,tblptrl
	movff	??_OLED_GetGlyph+0+1,tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u1987

	tblrd	*
	
	movf	tablat,w
	bra	u1980
u1987:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u1980:
	xorlw	0A1h
	btfss	status,2
	goto	u1991
	goto	u1990
u1991:
	goto	l2468
u1990:
	line	381
	
l2462:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	02h
	addwf	postinc2
	movlw	0
	addwfc	postdec2
	line	382
	
l2464:
		movlw	low(_glyph_a_acute_lower)
	movwf	((c:?_OLED_GetGlyph))^00h,c
	movlw	high(_glyph_a_acute_lower)
	movwf	((c:?_OLED_GetGlyph+1))^00h,c

	goto	l471
	line	385
	
l2468:
	movf	((c:OLED_GetGlyph@text))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	incf	postinc2
	movlw	0
	addwfc	postdec2
	line	387
	
l2470:
		movlw	020h-1
	cpfsgt	((c:OLED_GetGlyph@c))^00h,c
	goto	u2001
	goto	u2000

u2001:
	goto	l2474
u2000:
	
l2472:
		movlw	07Fh-1
	cpfsgt	((c:OLED_GetGlyph@c))^00h,c
	goto	u2011
	goto	u2010

u2011:
	goto	l2478
u2010:
	line	388
	
l2474:
		movlw	low(_glyph_unknown)
	movwf	((c:?_OLED_GetGlyph))^00h,c
	movlw	high(_glyph_unknown)
	movwf	((c:?_OLED_GetGlyph+1))^00h,c

	goto	l471
	line	391
	
l2478:
	movf	((c:OLED_GetGlyph@c))^00h,c,w
	mullw	05h
	movff	prodl,??_OLED_GetGlyph+0
	movff	prodh,??_OLED_GetGlyph+0+1
	movlw	low(0FF60h)
	addwf	(??_OLED_GetGlyph+0)^00h,c,w
	movwf	(??_OLED_GetGlyph+2)^00h,c
	movlw	high(0FF60h)
	addwfc	(??_OLED_GetGlyph+0+1)^00h,c,w
	movwf	1+(??_OLED_GetGlyph+2)^00h,c
	movlw	low(_font5x7)
	addwf	(??_OLED_GetGlyph+2)^00h,c,w
	movwf	((c:?_OLED_GetGlyph))^00h,c
	movlw	high(_font5x7)
	addwfc	(??_OLED_GetGlyph+2+1)^00h,c,w
	movwf	1+((c:?_OLED_GetGlyph))^00h,c
	line	392
	
l471:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_GetGlyph
	__end_of_OLED_GetGlyph:
	signat	_OLED_GetGlyph,4218
	global	_OLED_TextWidth

;; *************** function _OLED_TextWidth *****************
;; Defined at:
;;		line 248 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  text            2    0[COMRAM] PTR const unsigned char 
;;		 -> STR_12(16), STR_11(16), STR_10(7), STR_9(16), 
;;		 -> STR_8(17), STR_7(16), Show_Countdown@text(9), STR_6(17), 
;;		 -> STR_5(3), STR_4(5), STR_3(4), Show_Setup@text(9), 
;;		 -> STR_2(20), STR_1(14), 
;; Auto vars:     Size  Location     Type
;;  width           1    4[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, tblptrl, tblptrh, tblptru
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         2       0       0
;;      Locals:         1       0       0
;;      Temps:          2       0       0
;;      Totals:         5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_OLED_WriteTextCenteredAtY
;;		_OLED_WriteTextDoubleCentered
;;		_OLED_WriteTextCentered
;; This function uses a non-reentrant model
;;
psect	text35,class=CODE,space=0,reloc=2,group=0
	line	248
global __ptext35
__ptext35:
psect	text35
	file	"oled_i2c.c"
	line	248
	
_OLED_TextWidth:
;incstack = 0
	callstack 25
	line	250
	
l2536:
	clrf	((c:OLED_TextWidth@width))^00h,c
	line	252
	goto	l2568
	line	253
	
l2538:
	movff	(c:OLED_TextWidth@text),tblptrl
	movff	(c:OLED_TextWidth@text+1),tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2127

	tblrd	*
	
	movf	tablat,w
	bra	u2120
u2127:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2120:
	xorlw	0C5h
	btfss	status,2
	goto	u2131
	goto	u2130
u2131:
	goto	l2544
u2130:
	
l2540:
	movlw	01h
	addwf	((c:OLED_TextWidth@text))^00h,c,w
	movwf	(??_OLED_TextWidth+0)^00h,c
	movlw	0
	addwfc	((c:OLED_TextWidth@text+1))^00h,c,w
	movwf	(??_OLED_TextWidth+0+1)^00h,c
	movff	??_OLED_TextWidth+0,tblptrl
	movff	??_OLED_TextWidth+0+1,tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2147

	tblrd	*
	
	movf	tablat,w
	bra	u2140
u2147:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2140:
	xorlw	090h
	btfss	status,2
	goto	u2151
	goto	u2150
u2151:
	goto	l2544
u2150:
	line	254
	
l2542:
	movlw	02h
	addwf	((c:OLED_TextWidth@text))^00h,c
	movlw	0
	addwfc	((c:OLED_TextWidth@text+1))^00h,c
	line	255
	goto	l2564
	
l2544:
	movff	(c:OLED_TextWidth@text),tblptrl
	movff	(c:OLED_TextWidth@text+1),tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2167

	tblrd	*
	
	movf	tablat,w
	bra	u2160
u2167:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2160:
	xorlw	0C5h
	btfss	status,2
	goto	u2171
	goto	u2170
u2171:
	goto	l2550
u2170:
	
l2546:
	movlw	01h
	addwf	((c:OLED_TextWidth@text))^00h,c,w
	movwf	(??_OLED_TextWidth+0)^00h,c
	movlw	0
	addwfc	((c:OLED_TextWidth@text+1))^00h,c,w
	movwf	(??_OLED_TextWidth+0+1)^00h,c
	movff	??_OLED_TextWidth+0,tblptrl
	movff	??_OLED_TextWidth+0+1,tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2187

	tblrd	*
	
	movf	tablat,w
	bra	u2180
u2187:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2180:
	xorlw	091h
	btfss	status,2
	goto	u2191
	goto	u2190
u2191:
	goto	l2550
u2190:
	goto	l2542
	line	257
	
l2550:
	movff	(c:OLED_TextWidth@text),tblptrl
	movff	(c:OLED_TextWidth@text+1),tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2207

	tblrd	*
	
	movf	tablat,w
	bra	u2200
u2207:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2200:
	xorlw	0C3h
	btfss	status,2
	goto	u2211
	goto	u2210
u2211:
	goto	l2556
u2210:
	
l2552:
	movlw	01h
	addwf	((c:OLED_TextWidth@text))^00h,c,w
	movwf	(??_OLED_TextWidth+0)^00h,c
	movlw	0
	addwfc	((c:OLED_TextWidth@text+1))^00h,c,w
	movwf	(??_OLED_TextWidth+0+1)^00h,c
	movff	??_OLED_TextWidth+0,tblptrl
	movff	??_OLED_TextWidth+0+1,tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2227

	tblrd	*
	
	movf	tablat,w
	bra	u2220
u2227:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2220:
	xorlw	081h
	btfss	status,2
	goto	u2231
	goto	u2230
u2231:
	goto	l2556
u2230:
	goto	l2542
	line	259
	
l2556:
	movff	(c:OLED_TextWidth@text),tblptrl
	movff	(c:OLED_TextWidth@text+1),tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2247

	tblrd	*
	
	movf	tablat,w
	bra	u2240
u2247:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2240:
	xorlw	0C3h
	btfss	status,2
	goto	u2251
	goto	u2250
u2251:
	goto	l2562
u2250:
	
l2558:
	movlw	01h
	addwf	((c:OLED_TextWidth@text))^00h,c,w
	movwf	(??_OLED_TextWidth+0)^00h,c
	movlw	0
	addwfc	((c:OLED_TextWidth@text+1))^00h,c,w
	movwf	(??_OLED_TextWidth+0+1)^00h,c
	movff	??_OLED_TextWidth+0,tblptrl
	movff	??_OLED_TextWidth+0+1,tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2267

	tblrd	*
	
	movf	tablat,w
	bra	u2260
u2267:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2260:
	xorlw	0A1h
	btfss	status,2
	goto	u2271
	goto	u2270
u2271:
	goto	l2562
u2270:
	goto	l2542
	line	262
	
l2562:
	infsnz	((c:OLED_TextWidth@text))^00h,c
	incf	((c:OLED_TextWidth@text+1))^00h,c
	line	265
	
l2564:
		movlw	07Bh-0
	cpfslt	((c:OLED_TextWidth@width))^00h,c
	goto	u2281
	goto	u2280

u2281:
	goto	l2568
u2280:
	line	266
	
l2566:
	movf	((c:OLED_TextWidth@width))^00h,c,w
	addlw	low(06h)
	movwf	((c:OLED_TextWidth@width))^00h,c
	line	252
	
l2568:
	movff	(c:OLED_TextWidth@text),tblptrl
	movff	(c:OLED_TextWidth@text+1),tblptrh
	clrf	tblptru
	
	movlw	high __ramtop-1
	cpfsgt	tblptrh
	bra	u2297

	tblrd	*
	
	movf	tablat,w
	bra	u2290
u2297:
	movff	tblptrl,fsr0l
	movff	tblptrh,fsr0h
	movf	indf0,w
u2290:
	iorlw	0
	btfss	status,2
	goto	u2301
	goto	u2300
u2301:
	goto	l2538
u2300:
	line	270
	
l2570:
	movf	((c:OLED_TextWidth@width))^00h,c,w
	line	271
	
l429:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_TextWidth
	__end_of_OLED_TextWidth:
	signat	_OLED_TextWidth,4217
	global	_OLED_Clear

;; *************** function _OLED_Clear *****************
;; Defined at:
;;		line 160 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_OLED_Fill
;; This function is called by:
;;		_Show_Splash
;;		_Show_Setup
;;		_Show_Countdown
;;		_Show_Expired
;;		_OLED_Init
;; This function uses a non-reentrant model
;;
psect	text36,class=CODE,space=0,reloc=2,group=0
	line	160
global __ptext36
__ptext36:
psect	text36
	file	"oled_i2c.c"
	line	160
	
_OLED_Clear:
;incstack = 0
	callstack 26
	line	162
	
l2732:
	movlw	(0)&0ffh
	
	call	_OLED_Fill
	line	163
	
l380:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_Clear
	__end_of_OLED_Clear:
	signat	_OLED_Clear,89
	global	_OLED_Fill

;; *************** function _OLED_Fill *****************
;; Defined at:
;;		line 165 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  pattern         1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  pattern         1    5[COMRAM] unsigned char 
;;  page            1    7[COMRAM] unsigned char 
;;  column          1    6[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         3       0       0
;;      Temps:          0       0       0
;;      Totals:         3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 4
;; This function calls:
;;		_OLED_Data
;;		_OLED_SetCursor
;; This function is called by:
;;		_OLED_Clear
;; This function uses a non-reentrant model
;;
psect	text37,class=CODE,space=0,reloc=2,group=0
	line	165
global __ptext37
__ptext37:
psect	text37
	file	"oled_i2c.c"
	line	165
	
_OLED_Fill:
;incstack = 0
	callstack 22
	movwf	((c:OLED_Fill@pattern))^00h,c
	line	170
	
l2510:
	clrf	((c:OLED_Fill@page))^00h,c
	line	171
	
l2516:
	movff	(c:OLED_Fill@page),(c:OLED_SetCursor@page)
	movlw	(0)&0ffh
	
	call	_OLED_SetCursor
	line	172
	
l2518:
	clrf	((c:OLED_Fill@column))^00h,c
	line	173
	
l2524:
	movf	((c:OLED_Fill@pattern))^00h,c,w
	
	call	_OLED_Data
	line	174
	
l2526:
	incf	((c:OLED_Fill@column))^00h,c
	
l2528:
		movlw	080h-1
	cpfsgt	((c:OLED_Fill@column))^00h,c
	goto	u2101
	goto	u2100

u2101:
	goto	l2524
u2100:
	line	175
	
l2530:
	incf	((c:OLED_Fill@page))^00h,c
	
l2532:
		movlw	08h-1
	cpfsgt	((c:OLED_Fill@page))^00h,c
	goto	u2111
	goto	u2110

u2111:
	goto	l2516
u2110:
	line	176
	
l2534:
	movlw	low(0)
	movwf	((c:OLED_SetCursor@page))^00h,c
	movlw	(0)&0ffh
	
	call	_OLED_SetCursor
	line	177
	
l387:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_Fill
	__end_of_OLED_Fill:
	signat	_OLED_Fill,4217
	global	_OLED_SetCursor

;; *************** function _OLED_SetCursor *****************
;; Defined at:
;;		line 184 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  column          1    wreg     unsigned char 
;;  page            1    3[COMRAM] unsigned char 
;; Auto vars:     Size  Location     Type
;;  column          1    4[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         1       0       0
;;      Temps:          0       0       0
;;      Totals:         2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_OLED_Command
;; This function is called by:
;;		_OLED_Fill
;;		_OLED_WriteTextAtY
;;		_OLED_WriteTextDoublePage
;;		_OLED_WriteTextCentered
;; This function uses a non-reentrant model
;;
psect	text38,class=CODE,space=0,reloc=2,group=0
	line	184
global __ptext38
__ptext38:
psect	text38
	file	"oled_i2c.c"
	line	184
	
_OLED_SetCursor:
;incstack = 0
	callstack 24
	movwf	((c:OLED_SetCursor@column))^00h,c
	line	186
	
l2390:
		movlw	080h-1
	cpfsgt	((c:OLED_SetCursor@column))^00h,c
	goto	u1831
	goto	u1830

u1831:
	goto	l2394
u1830:
	line	187
	
l2392:
	movlw	low(07Fh)
	movwf	((c:OLED_SetCursor@column))^00h,c
	line	189
	
l2394:
		movlw	08h-1
	cpfsgt	((c:OLED_SetCursor@page))^00h,c
	goto	u1841
	goto	u1840

u1841:
	goto	l2398
u1840:
	line	190
	
l2396:
	movlw	low(07h)
	movwf	((c:OLED_SetCursor@page))^00h,c
	line	193
	
l2398:
	movf	((c:OLED_SetCursor@page))^00h,c,w
	iorlw	low(0B0h)
	
	call	_OLED_Command
	line	194
	
l2400:
	movf	((c:OLED_SetCursor@column))^00h,c,w
	andlw	low(0Fh)
	
	call	_OLED_Command
	line	195
	
l2402:
	swapf	((c:OLED_SetCursor@column))^00h,c,w
	andlw	(0ffh shr 4) & 0ffh
	iorlw	low(010h)
	
	call	_OLED_Command
	line	196
	
l395:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_SetCursor
	__end_of_OLED_SetCursor:
	signat	_OLED_SetCursor,8313
	global	_OLED_Command

;; *************** function _OLED_Command *****************
;; Defined at:
;;		line 394 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  command         1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  command         1    2[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      _Bool 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         1       0       0
;;      Temps:          0       0       0
;;      Totals:         1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_I2C_Start
;;		_I2C_Stop
;;		_I2C_Write
;; This function is called by:
;;		_OLED_Init
;;		_OLED_DisplayOn
;;		_OLED_SetCursor
;; This function uses a non-reentrant model
;;
psect	text39,class=CODE,space=0,reloc=2,group=0
	line	394
global __ptext39
__ptext39:
psect	text39
	file	"oled_i2c.c"
	line	394
	
_OLED_Command:
;incstack = 0
	callstack 23
	movwf	((c:OLED_Command@command))^00h,c
	line	396
	
l2368:
	call	_I2C_Start	;wreg free
	line	397
	movf	((c:_oledAddress))^00h,c,w
	addwf	((c:_oledAddress))^00h,c,w
	
	call	_I2C_Write
	iorlw	0
	btfss	status,2
	goto	u1811
	goto	u1810
u1811:
	goto	l2374
u1810:
	line	398
	
l2370:
	call	_I2C_Stop	;wreg free
	goto	l481
	line	401
	
l2374:
	movlw	(0)&0ffh
	
	call	_I2C_Write
	iorlw	0
	btfss	status,2
	goto	u1821
	goto	u1820
u1821:
	goto	l2380
u1820:
	goto	l2370
	line	405
	
l2380:
	movf	((c:OLED_Command@command))^00h,c,w
	
	call	_I2C_Write
	goto	l2370
	line	411
	
l481:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_Command
	__end_of_OLED_Command:
	signat	_OLED_Command,4217
	global	_OLED_Data

;; *************** function _OLED_Data *****************
;; Defined at:
;;		line 413 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  data            1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  data            1    2[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      _Bool 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         1       0       0
;;      Temps:          0       0       0
;;      Totals:         1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_I2C_Start
;;		_I2C_Stop
;;		_I2C_Write
;; This function is called by:
;;		_OLED_Fill
;;		_OLED_WriteTextAtY
;;		_OLED_WriteTextDoublePage
;;		_OLED_WriteGlyph
;; This function uses a non-reentrant model
;;
psect	text40,class=CODE,space=0,reloc=2,group=0
	line	413
global __ptext40
__ptext40:
psect	text40
	file	"oled_i2c.c"
	line	413
	
_OLED_Data:
;incstack = 0
	callstack 24
	movwf	((c:OLED_Data@data))^00h,c
	line	415
	
l2404:
	call	_I2C_Start	;wreg free
	line	416
	movf	((c:_oledAddress))^00h,c,w
	addwf	((c:_oledAddress))^00h,c,w
	
	call	_I2C_Write
	iorlw	0
	btfss	status,2
	goto	u1851
	goto	u1850
u1851:
	goto	l2410
u1850:
	line	417
	
l2406:
	call	_I2C_Stop	;wreg free
	goto	l487
	line	420
	
l2410:
	movlw	(040h)&0ffh
	
	call	_I2C_Write
	iorlw	0
	btfss	status,2
	goto	u1861
	goto	u1860
u1861:
	goto	l2416
u1860:
	goto	l2406
	line	424
	
l2416:
	movf	((c:OLED_Data@data))^00h,c,w
	
	call	_I2C_Write
	goto	l2406
	line	430
	
l487:
	return	;funcret
	callstack 0
GLOBAL	__end_of_OLED_Data
	__end_of_OLED_Data:
	signat	_OLED_Data,4217
	global	_I2C_Write

;; *************** function _I2C_Write *****************
;; Defined at:
;;		line 463 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;  data            1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  data            1    1[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      _Bool 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         1       0       0
;;      Temps:          0       0       0
;;      Totals:         1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_I2C_WaitIdle
;; This function is called by:
;;		_OLED_Command
;;		_OLED_Data
;;		_I2C_AddressResponds
;; This function uses a non-reentrant model
;;
psect	text41,class=CODE,space=0,reloc=2,group=0
	line	463
global __ptext41
__ptext41:
psect	text41
	file	"oled_i2c.c"
	line	463
	
_I2C_Write:
;incstack = 0
	callstack 22
	movwf	((c:I2C_Write@data))^00h,c
	line	465
	
l2352:
	call	_I2C_WaitIdle	;wreg free
	line	466
	
l2354:
	bcf	((c:3998))^0f00h,c,3	;volatile
	line	467
	
l2356:
	movff	(c:I2C_Write@data),(c:4041)	;volatile
	line	468
	
l507:
	btfss	((c:3998))^0f00h,c,3	;volatile
	goto	u1771
	goto	u1770
u1771:
	goto	l507
u1770:
	
l509:
	line	469
	bcf	((c:3998))^0f00h,c,3	;volatile
	line	470
	
l2358:
	btfss	((c:4037))^0f00h,c,6	;volatile
	goto	u1781
	goto	u1780
u1781:
	movlw	1
	goto	u1790
u1780:
	movlw	0
u1790:
	line	471
	
l510:
	return	;funcret
	callstack 0
GLOBAL	__end_of_I2C_Write
	__end_of_I2C_Write:
	signat	_I2C_Write,4217
	global	_I2C_Stop

;; *************** function _I2C_Stop *****************
;; Defined at:
;;		line 455 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_I2C_WaitIdle
;; This function is called by:
;;		_OLED_Command
;;		_OLED_Data
;;		_I2C_AddressResponds
;; This function uses a non-reentrant model
;;
psect	text42,class=CODE,space=0,reloc=2,group=0
	line	455
global __ptext42
__ptext42:
psect	text42
	file	"oled_i2c.c"
	line	455
	
_I2C_Stop:
;incstack = 0
	callstack 22
	line	457
	
l2362:
	call	_I2C_WaitIdle	;wreg free
	line	458
	
l2364:
	bcf	((c:3998))^0f00h,c,3	;volatile
	line	459
	
l2366:
	bsf	((c:4037))^0f00h,c,2	;volatile
	line	460
	
l501:
	btfsc	((c:4037))^0f00h,c,2	;volatile
	goto	u1801
	goto	u1800
u1801:
	goto	l501
u1800:
	line	461
	
l504:
	return	;funcret
	callstack 0
GLOBAL	__end_of_I2C_Stop
	__end_of_I2C_Stop:
	signat	_I2C_Stop,89
	global	_I2C_Start

;; *************** function _I2C_Start *****************
;; Defined at:
;;		line 447 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		_I2C_WaitIdle
;; This function is called by:
;;		_OLED_Command
;;		_OLED_Data
;;		_I2C_AddressResponds
;; This function uses a non-reentrant model
;;
psect	text43,class=CODE,space=0,reloc=2,group=0
	line	447
global __ptext43
__ptext43:
psect	text43
	file	"oled_i2c.c"
	line	447
	
_I2C_Start:
;incstack = 0
	callstack 22
	line	449
	
l2346:
	call	_I2C_WaitIdle	;wreg free
	line	450
	
l2348:
	bcf	((c:3998))^0f00h,c,3	;volatile
	line	451
	
l2350:
	bsf	((c:4037))^0f00h,c,0	;volatile
	line	452
	
l495:
	btfsc	((c:4037))^0f00h,c,0	;volatile
	goto	u1761
	goto	u1760
u1761:
	goto	l495
u1760:
	line	453
	
l498:
	return	;funcret
	callstack 0
GLOBAL	__end_of_I2C_Start
	__end_of_I2C_Start:
	signat	_I2C_Start,89
	global	_I2C_WaitIdle

;; *************** function _I2C_WaitIdle *****************
;; Defined at:
;;		line 473 in file "oled_i2c.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          1       0       0
;;      Totals:         1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_I2C_Start
;;		_I2C_Stop
;;		_I2C_Write
;; This function uses a non-reentrant model
;;
psect	text44,class=CODE,space=0,reloc=2,group=0
	line	473
global __ptext44
__ptext44:
psect	text44
	file	"oled_i2c.c"
	line	473
	
_I2C_WaitIdle:
;incstack = 0
	callstack 21
	line	475
	
l2340:
	
l2342:
	movff	(c:4037),??_I2C_WaitIdle+0	;volatile
	movlw	01Fh
	andwf	(??_I2C_WaitIdle+0)^00h,c
	btfss	status,2
	goto	u1741
	goto	u1740
u1741:
	goto	l2342
u1740:
	
l2344:
	btfsc	((c:4039))^0f00h,c,2	;volatile
	goto	u1751
	goto	u1750
u1751:
	goto	l2342
u1750:
	line	477
	
l516:
	return	;funcret
	callstack 0
GLOBAL	__end_of_I2C_WaitIdle
	__end_of_I2C_WaitIdle:
	signat	_I2C_WaitIdle,89
	global	_Outputs_Off

;; *************** function _Outputs_Off *****************
;; Defined at:
;;		line 219 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;;		_Handle_Events
;; This function uses a non-reentrant model
;;
psect	text45,class=CODE,space=0,reloc=2,group=0
	file	"main.c"
	line	219
global __ptext45
__ptext45:
psect	text45
	file	"main.c"
	line	219
	
_Outputs_Off:
;incstack = 0
	callstack 28
	line	221
	
l1786:
	bcf	((c:3979))^0f00h,c,1	;volatile
	line	222
	bcf	((c:3979))^0f00h,c,2	;volatile
	line	223
	bcf	((c:3979))^0f00h,c,3	;volatile
	line	224
	bcf	((c:3979))^0f00h,c,5	;volatile
	line	225
	clrf	((c:_alarmOn))^00h,c
	line	226
	
l150:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Outputs_Off
	__end_of_Outputs_Off:
	signat	_Outputs_Off,89
	global	_EEPROM_LoadTime

;; *************** function _EEPROM_LoadTime *****************
;; Defined at:
;;		line 460 in file "main.c"
;; Parameters:    Size  Location     Type
;;  time            1    3[COMRAM] PTR struct .
;;		 -> Handle_Events@storedTime(3), 
;; Auto vars:     Size  Location     Type
;;  magic           1    5[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      _Bool 
;; Registers used:
;;		wreg, fsr2l, fsr2h, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         1       0       0
;;      Temps:          1       0       0
;;      Totals:         3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_EEPROM_Check
;;		_EEPROM_Read
;; This function is called by:
;;		_Handle_Events
;; This function uses a non-reentrant model
;;
psect	text46,class=CODE,space=0,reloc=2,group=0
	line	460
global __ptext46
__ptext46:
psect	text46
	file	"main.c"
	line	460
	
_EEPROM_LoadTime:
;incstack = 0
	callstack 27
	line	462
	
l2884:
	movlw	(0)&0ffh
	
	call	_EEPROM_Read
	movwf	((c:EEPROM_LoadTime@magic))^00h,c
	line	464
	
l2886:
	movf	((c:EEPROM_LoadTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	(01h)&0ffh
	
	call	_EEPROM_Read
	movwf	indf2,c

	line	465
	
l2888:
	movf	((c:EEPROM_LoadTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	movlw	(02h)&0ffh
	
	call	_EEPROM_Read
	movwf	indf2,c

	line	466
	
l2890:
	movf	((c:EEPROM_LoadTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movlw	(03h)&0ffh
	
	call	_EEPROM_Read
	movwf	indf2,c

	line	468
	
l2892:
		movlw	165
	xorwf	((c:EEPROM_LoadTime@magic))^00h,c,w
	btfss	status,2
	goto	u2751
	goto	u2750

u2751:
	goto	l2900
u2750:
	
l2894:
	movf	((c:EEPROM_LoadTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
		movlw	064h-0
	cpfslt	indf2
	goto	u2761
	goto	u2760

u2761:
	goto	l2900
u2760:
	
l2896:
	movf	((c:EEPROM_LoadTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

		movlw	03Ch-0
	cpfslt	indf2
	goto	u2771
	goto	u2770

u2771:
	goto	l2900
u2770:
	
l2898:
	movf	((c:EEPROM_LoadTime@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

		movlw	03Ch-1
	cpfsgt	indf2
	goto	u2781
	goto	u2780

u2781:
	goto	l2904
u2780:
	line	470
	
l2900:
	movlw	(0)&0ffh
	goto	l242
	line	473
	
l2904:
	movlw	(04h)&0ffh
	
	call	_EEPROM_Read
	movwf	(??_EEPROM_LoadTime+0)^00h,c
		movff	(c:EEPROM_LoadTime@time),(c:EEPROM_Check@time)

	call	_EEPROM_Check	;wreg free
	xorwf	((??_EEPROM_LoadTime+0))^00h,c,w

	btfsc	status,2
	goto	u2791
	goto	u2790
u2791:
	movlw	1
	goto	u2800
u2790:
	movlw	0
u2800:
	line	474
	
l242:
	return	;funcret
	callstack 0
GLOBAL	__end_of_EEPROM_LoadTime
	__end_of_EEPROM_LoadTime:
	signat	_EEPROM_LoadTime,4217
	global	_EEPROM_Read

;; *************** function _EEPROM_Read *****************
;; Defined at:
;;		line 437 in file "main.c"
;; Parameters:    Size  Location     Type
;;  address         1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  address         1    0[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         1       0       0
;;      Temps:          0       0       0
;;      Totals:         1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_EEPROM_LoadTime
;; This function uses a non-reentrant model
;;
psect	text47,class=CODE,space=0,reloc=2,group=0
	line	437
global __ptext47
__ptext47:
psect	text47
	file	"main.c"
	line	437
	
_EEPROM_Read:
;incstack = 0
	callstack 27
	movwf	((c:EEPROM_Read@address))^00h,c
	line	439
	
l1744:
	movff	(c:EEPROM_Read@address),(c:4009)	;volatile
	line	440
	
l1746:
	bcf	((c:4006))^0f00h,c,7	;volsfr
	line	441
	
l1748:
	bcf	((c:4006))^0f00h,c,6	;volsfr
	line	442
	
l1750:
	bsf	((c:4006))^0f00h,c,0	;volsfr
	line	443
	
l1752:
	movf	((c:4008))^0f00h,c,w	;volatile
	line	444
	
l230:
	return	;funcret
	callstack 0
GLOBAL	__end_of_EEPROM_Read
	__end_of_EEPROM_Read:
	signat	_EEPROM_Read,4217
	global	_EEPROM_Check

;; *************** function _EEPROM_Check *****************
;; Defined at:
;;		line 446 in file "main.c"
;; Parameters:    Size  Location     Type
;;  time            1    0[COMRAM] PTR const struct .
;;		 -> Handle_Events@storedTime(3), setTime(3), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr2l, fsr2h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         1       0       0
;;      Locals:         0       0       0
;;      Temps:          2       0       0
;;      Totals:         3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_EEPROM_SaveTime
;;		_EEPROM_LoadTime
;; This function uses a non-reentrant model
;;
psect	text48,class=CODE,space=0,reloc=2,group=0
	line	446
global __ptext48
__ptext48:
psect	text48
	file	"main.c"
	line	446
	
_EEPROM_Check:
;incstack = 0
	callstack 26
	line	448
	
l2728:
	movf	((c:EEPROM_Check@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(02h)
	addwf	fsr2l

	movf	indf2,w
	movwf	(??_EEPROM_Check+0)^00h,c
	movf	((c:EEPROM_Check@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movlw	low(01h)
	addwf	fsr2l

	movf	indf2,w
	movwf	(??_EEPROM_Check+1)^00h,c
	movf	((c:EEPROM_Check@time))^00h,c,w
	movwf	fsr2l
	clrf	fsr2h
	movf	indf2,w
	xorwf	((??_EEPROM_Check+1))^00h,c,w
	xorwf	((??_EEPROM_Check+0))^00h,c,w
	xorlw	0ffh
	line	449
	
l233:
	return	;funcret
	callstack 0
GLOBAL	__end_of_EEPROM_Check
	__end_of_EEPROM_Check:
	signat	_EEPROM_Check,4217
	global	_Buttons_ConsumeStartRelease

;; *************** function _Buttons_ConsumeStartRelease *****************
;; Defined at:
;;		line 344 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Handle_Events
;; This function uses a non-reentrant model
;;
psect	text49,class=CODE,space=0,reloc=2,group=0
	line	344
global __ptext49
__ptext49:
psect	text49
	file	"main.c"
	line	344
	
_Buttons_ConsumeStartRelease:
;incstack = 0
	callstack 28
	line	346
	
l1842:
	movlw	low(01h)
	movwf	((c:_consumeStartRelease))^00h,c
	line	347
	
l192:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Buttons_ConsumeStartRelease
	__end_of_Buttons_ConsumeStartRelease:
	signat	_Buttons_ConsumeStartRelease,89
	global	_Buttons_Update

;; *************** function _Buttons_Update *****************
;; Defined at:
;;		line 282 in file "main.c"
;; Parameters:    Size  Location     Type
;;  now             4    1[COMRAM] unsigned long 
;; Auto vars:     Size  Location     Type
;;  mask            1   21[COMRAM] unsigned char 
;;  rawPressed      1   14[COMRAM] _Bool 
;;  stablePresse    1   12[COMRAM] _Bool 
;;  lastPressed     1   11[COMRAM] _Bool 
;;  events          5   16[COMRAM] struct .
;;  index           1   15[COMRAM] unsigned char 
;;  raw             1   10[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  5    1[COMRAM] struct .
;; Registers used:
;;		wreg, fsr0l, fsr0h, fsr1l, fsr1h, fsr2l, fsr2h, status,2, status,0, tblptrl, tblptrh, tblptru, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         5       0       0
;;      Locals:        12       0       0
;;      Temps:          4       0       0
;;      Totals:        21       0       0
;;Total ram usage:       21 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_ReadButtonsRaw
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text50,class=CODE,space=0,reloc=2,group=0
	line	282
global __ptext50
__ptext50:
psect	text50
	file	"main.c"
	line	282
	
_Buttons_Update:
;incstack = 0
	callstack 28
	line	284
	
l3058:
	lfsr	2,(Buttons_Update@F2596)
	lfsr	1,(Buttons_Update@events)
	movlw	5-1
u2851:
	movff	plusw2,plusw1
	decf	wreg
	bc	u2851

	line	288
	
l3060:
	movlb	0	; () banked
	movf	((_lastButtonPollAt))&0ffh,w
	subwf	((c:Buttons_Update@now))^00h,c,w
	movwf	(??_Buttons_Update+0)^00h,c
	movf	((_lastButtonPollAt+1))&0ffh,w
	subwfb	((c:Buttons_Update@now+1))^00h,c,w
	movwf	1+(??_Buttons_Update+0)^00h,c
	
	movf	((_lastButtonPollAt+2))&0ffh,w
	subwfb	((c:Buttons_Update@now+2))^00h,c,w
	movwf	2+(??_Buttons_Update+0)^00h,c
	
	movf	((_lastButtonPollAt+3))&0ffh,w
	subwfb	((c:Buttons_Update@now+3))^00h,c,w
	movwf	3+(??_Buttons_Update+0)^00h,c
		movf	(??_Buttons_Update+0+3)^00h,c,w
	iorwf	(??_Buttons_Update+0+2)^00h,c,w
	iorwf	(??_Buttons_Update+0+1)^00h,c,w
	bnz	u2861
	movlw	10
	subwf	 (??_Buttons_Update+0)^00h,c,w
	btfsc	status,0
	goto	u2861
	goto	u2860

u2861:
	goto	l171
u2860:
	line	289
	
l3062:
	lfsr	2,(Buttons_Update@events)
	lfsr	0,(?_Buttons_Update)
	movlw	5-1
u2871:
	movff	plusw2,plusw0
	decf	wreg
	bc	u2871

	goto	l172
	line	290
	
l171:; BSR set to: 0

	line	291
	movff	(c:Buttons_Update@now),(_lastButtonPollAt)
	movff	(c:Buttons_Update@now+1),(_lastButtonPollAt+1)
	movff	(c:Buttons_Update@now+2),(_lastButtonPollAt+2)
	movff	(c:Buttons_Update@now+3),(_lastButtonPollAt+3)
	line	292
	
l3066:; BSR set to: 0

	call	_ReadButtonsRaw	;wreg free
	movwf	((c:Buttons_Update@raw))^00h,c
	line	294
	
l3068:
	clrf	((c:Buttons_Update@index))^00h,c
	line	295
	
l3074:
	movlw	low((_buttonMasks))
	addwf	((c:Buttons_Update@index))^00h,c,w
	movwf	tblptrl
	clrf	tblptrh
	movlw	high((_buttonMasks))
	addwfc	tblptrh
	if	0	;There are less than 3 active tblptr bytes
	clrf	tblptru
	global __mediumconst
movlw	low highword(__mediumconst)
	addwfc	tblptru,f
	endif
	tblrd	*
	
	movff	tablat,(c:Buttons_Update@mask)
	line	296
	
l3076:
	movf	((c:Buttons_Update@raw))^00h,c,w
	andwf	((c:Buttons_Update@mask))^00h,c,w
	iorlw	0
	btfss	status,2
	goto	u2881
	goto	u2880
u2881:
	movlw	1
	goto	u2890
u2880:
	movlw	0
u2890:
	movwf	((c:Buttons_Update@rawPressed))^00h,c
	line	297
	
l3078:
	movf	((c:_buttonLastRaw))^00h,c,w
	andwf	((c:Buttons_Update@mask))^00h,c,w
	iorlw	0
	btfss	status,2
	goto	u2901
	goto	u2900
u2901:
	movlw	1
	goto	u2910
u2900:
	movlw	0
u2910:
	movwf	((c:Buttons_Update@lastPressed))^00h,c
	line	298
	
l3080:
	movf	((c:_buttonStable))^00h,c,w
	andwf	((c:Buttons_Update@mask))^00h,c,w
	iorlw	0
	btfss	status,2
	goto	u2921
	goto	u2920
u2921:
	movlw	1
	goto	u2930
u2920:
	movlw	0
u2930:
	movwf	((c:Buttons_Update@stablePressed))^00h,c
	line	300
	
l3082:
	movf	((c:Buttons_Update@lastPressed))^00h,c,w
xorwf	((c:Buttons_Update@rawPressed))^00h,c,w
	btfsc	status,2
	goto	u2941
	goto	u2940

u2941:
	goto	l3092
u2940:
	line	301
	
l3084:
	movf	((c:Buttons_Update@rawPressed))^00h,c,w
	btfsc	status,2
	goto	u2951
	goto	u2950
u2951:
	goto	l3088
u2950:
	line	302
	
l3086:
	movf	((c:Buttons_Update@mask))^00h,c,w
	iorwf	((c:_buttonLastRaw))^00h,c
	line	303
	goto	l3090
	line	304
	
l3088:
	movf	((c:Buttons_Update@mask))^00h,c,w
	xorlw	0ffh
	andwf	((c:_buttonLastRaw))^00h,c
	line	306
	
l3090:
	movf	((c:Buttons_Update@index))^00h,c,w
	addlw	low(_buttonDebounce)
	movwf	fsr2l
	clrf	fsr2h
	clrf	indf2
	line	307
	goto	l3120
	
l3092:
	movf	((c:Buttons_Update@index))^00h,c,w
	addlw	low(_buttonDebounce)
	movwf	fsr2l
	clrf	fsr2h
		movlw	03h-0
	cpfslt	indf2
	goto	u2961
	goto	u2960

u2961:
	goto	l3120
u2960:
	line	308
	
l3094:
	movf	((c:Buttons_Update@index))^00h,c,w
	addlw	low(_buttonDebounce)
	movwf	fsr2l
	clrf	fsr2h
	incf	indf2

	line	310
	movf	((c:Buttons_Update@index))^00h,c,w
	addlw	low(_buttonDebounce)
	movwf	fsr2l
	clrf	fsr2h
		movlw	03h-1
	cpfsgt	indf2
	goto	u2971
	goto	u2970

u2971:
	goto	l3120
u2970:
	
l3096:
	movf	((c:Buttons_Update@stablePressed))^00h,c,w
xorwf	((c:Buttons_Update@rawPressed))^00h,c,w
	btfsc	status,2
	goto	u2981
	goto	u2980

u2981:
	goto	l3120
u2980:
	line	312
	
l3098:
	movf	((c:Buttons_Update@rawPressed))^00h,c,w
	btfsc	status,2
	goto	u2991
	goto	u2990
u2991:
	goto	l3110
u2990:
	line	313
	
l3100:
	movf	((c:Buttons_Update@mask))^00h,c,w
	iorwf	((c:_buttonStable))^00h,c
	line	314
		movlw	8
	xorwf	((c:Buttons_Update@mask))^00h,c,w
	btfss	status,2
	goto	u3001
	goto	u3000

u3001:
	goto	l3108
u3000:
	line	315
	
l3102:
	movlw	low(01h)
	movwf	(0+((c:Buttons_Update@events)+01h))^00h,c
	line	316
	
l3104:
	movff	(c:Buttons_Update@now),(_startPressedAt)
	movff	(c:Buttons_Update@now+1),(_startPressedAt+1)
	movff	(c:Buttons_Update@now+2),(_startPressedAt+2)
	movff	(c:Buttons_Update@now+3),(_startPressedAt+3)
	line	317
	
l3106:
	clrf	((c:_startLongReported))^00h,c
	line	318
	goto	l3120
	line	319
	
l3108:
	movf	((c:Buttons_Update@mask))^00h,c,w
	iorwf	((c:Buttons_Update@events))^00h,c
	goto	l3120
	line	322
	
l3110:
	movf	((c:Buttons_Update@mask))^00h,c,w
	xorlw	0ffh
	andwf	((c:_buttonStable))^00h,c
	line	323
		movlw	8
	xorwf	((c:Buttons_Update@mask))^00h,c,w
	btfss	status,2
	goto	u3011
	goto	u3010

u3011:
	goto	l3120
u3010:
	line	324
	
l3112:
	movf	((c:_startLongReported))^00h,c,w
	btfss	status,2
	goto	u3021
	goto	u3020
u3021:
	goto	l3118
u3020:
	
l3114:
	movf	((c:_consumeStartRelease))^00h,c,w
	btfss	status,2
	goto	u3031
	goto	u3030
u3031:
	goto	l3118
u3030:
	line	325
	
l3116:
	movlw	low(01h)
	movwf	(0+((c:Buttons_Update@events)+02h))^00h,c
	line	327
	
l3118:
	clrf	((c:_consumeStartRelease))^00h,c
	line	332
	
l3120:
	incf	((c:Buttons_Update@index))^00h,c
	
l3122:
		movlw	04h-1
	cpfsgt	((c:Buttons_Update@index))^00h,c
	goto	u3041
	goto	u3040

u3041:
	goto	l3074
u3040:
	
l174:
	line	334
	
	btfss	((c:_buttonStable))^00h,c,(3)&7
	goto	u3051
	goto	u3050
u3051:
	goto	l187
u3050:
	
l3124:
	movf	((c:_startLongReported))^00h,c,w
	btfss	status,2
	goto	u3061
	goto	u3060
u3061:
	goto	l187
u3060:
	
l3126:
	movlb	0	; () banked
	movf	((_startPressedAt))&0ffh,w
	subwf	((c:Buttons_Update@now))^00h,c,w
	movwf	(??_Buttons_Update+0)^00h,c
	movf	((_startPressedAt+1))&0ffh,w
	subwfb	((c:Buttons_Update@now+1))^00h,c,w
	movwf	1+(??_Buttons_Update+0)^00h,c
	
	movf	((_startPressedAt+2))&0ffh,w
	subwfb	((c:Buttons_Update@now+2))^00h,c,w
	movwf	2+(??_Buttons_Update+0)^00h,c
	
	movf	((_startPressedAt+3))&0ffh,w
	subwfb	((c:Buttons_Update@now+3))^00h,c,w
	movwf	3+(??_Buttons_Update+0)^00h,c
		movf	(??_Buttons_Update+0+3)^00h,c,w
	iorwf	(??_Buttons_Update+0+2)^00h,c,w
	bnz	u3070
	movlw	208
	subwf	 (??_Buttons_Update+0)^00h,c,w
	movlw	7
	subwfb	(??_Buttons_Update+0+1)^00h,c,w
	btfss	status,0
	goto	u3071
	goto	u3070

u3071:
	goto	l187
u3070:
	line	336
	
l3128:; BSR set to: 0

	movlw	low(01h)
	movwf	((c:_startLongReported))^00h,c
	line	337
	movlw	low(01h)
	movwf	(0+((c:Buttons_Update@events)+03h))^00h,c
	line	338
	
l187:
	line	340
	movlw	low(01h)
	movwf	((c:_Buttons_Update$940))^00h,c
	movf	((c:Buttons_Update@events))^00h,c,w
	btfss	status,2
	goto	u3081
	goto	u3080
u3081:
	goto	l3134
u3080:
	
l3130:
	movf	(0+((c:Buttons_Update@events)+01h))^00h,c,w
	btfss	status,2
	goto	u3091
	goto	u3090
u3091:
	goto	l3134
u3090:
	
l3132:
	clrf	((c:_Buttons_Update$940))^00h,c
	
l3134:
	movf	((c:_Buttons_Update$940))^00h,c,w
	btfss	status,2
	goto	u3101
	goto	u3100
u3101:
	movlw	1
	goto	u3110
u3100:
	movlw	0
u3110:
	movwf	(0+((c:Buttons_Update@events)+04h))^00h,c
	goto	l3062
	line	342
	
l172:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Buttons_Update
	__end_of_Buttons_Update:
	signat	_Buttons_Update,4221
	global	_Buttons_Init

;; *************** function _Buttons_Init *****************
;; Defined at:
;;		line 269 in file "main.c"
;; Parameters:    Size  Location     Type
;;  now             4    1[COMRAM] unsigned long 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         4       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 2
;; This function calls:
;;		_ReadButtonsRaw
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text51,class=CODE,space=0,reloc=2,group=0
	line	269
global __ptext51
__ptext51:
psect	text51
	file	"main.c"
	line	269
	
_Buttons_Init:
;incstack = 0
	callstack 28
	line	271
	
l3034:
	call	_ReadButtonsRaw	;wreg free
	movwf	((c:_buttonStable))^00h,c
	line	272
	
l3036:
	movff	(c:_buttonStable),(c:_buttonLastRaw)
	line	273
	
l3038:
	clrf	((c:_buttonDebounce))^00h,c
	line	274
	
l3040:
	clrf	(0+((c:_buttonDebounce)+01h))^00h,c
	line	275
	
l3042:
	clrf	(0+((c:_buttonDebounce)+02h))^00h,c
	line	276
	
l3044:
	clrf	(0+((c:_buttonDebounce)+03h))^00h,c
	line	277
	
l3046:
	movff	(c:Buttons_Init@now),(_lastButtonPollAt)
	movff	(c:Buttons_Init@now+1),(_lastButtonPollAt+1)
	movff	(c:Buttons_Init@now+2),(_lastButtonPollAt+2)
	movff	(c:Buttons_Init@now+3),(_lastButtonPollAt+3)
	line	278
	
l3048:
	clrf	((c:_startLongReported))^00h,c
	line	279
	
l3050:
	clrf	((c:_consumeStartRelease))^00h,c
	line	280
	
l166:
	return	;funcret
	callstack 0
GLOBAL	__end_of_Buttons_Init
	__end_of_Buttons_Init:
	signat	_Buttons_Init,4217
	global	_ReadButtonsRaw

;; *************** function _ReadButtonsRaw *****************
;; Defined at:
;;		line 249 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  value           1    0[COMRAM] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         1       0       0
;;      Temps:          0       0       0
;;      Totals:         1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used: 1
;; Hardware stack levels required when called: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Buttons_Init
;;		_Buttons_Update
;; This function uses a non-reentrant model
;;
psect	text52,class=CODE,space=0,reloc=2,group=0
	line	249
global __ptext52
__ptext52:
psect	text52
	file	"main.c"
	line	249
	
_ReadButtonsRaw:
;incstack = 0
	callstack 28
	line	251
	
l2822:
	clrf	((c:ReadButtonsRaw@value))^00h,c
	line	253
	btfsc	((c:3970))^0f00h,c,0	;volatile
	goto	u2611
	goto	u2610
u2611:
	goto	l2826
u2610:
	line	254
	
l2824:
	bsf	(0+(0/8)+(c:ReadButtonsRaw@value))^00h,c,(0)&7
	line	256
	
l2826:
	btfsc	((c:3969))^0f00h,c,5	;volatile
	goto	u2621
	goto	u2620
u2621:
	goto	l2830
u2620:
	line	257
	
l2828:
	bsf	(0+(1/8)+(c:ReadButtonsRaw@value))^00h,c,(1)&7
	line	259
	
l2830:
	btfsc	((c:3969))^0f00h,c,7	;volatile
	goto	u2631
	goto	u2630
u2631:
	goto	l2834
u2630:
	line	260
	
l2832:
	bsf	(0+(2/8)+(c:ReadButtonsRaw@value))^00h,c,(2)&7
	line	262
	
l2834:
	btfsc	((c:3968))^0f00h,c,2	;volatile
	goto	u2641
	goto	u2640
u2641:
	goto	l2838
u2640:
	line	263
	
l2836:
	bsf	(0+(3/8)+(c:ReadButtonsRaw@value))^00h,c,(3)&7
	line	266
	
l2838:
	movf	((c:ReadButtonsRaw@value))^00h,c,w
	line	267
	
l163:
	return	;funcret
	callstack 0
GLOBAL	__end_of_ReadButtonsRaw
	__end_of_ReadButtonsRaw:
	signat	_ReadButtonsRaw,89
	global	_InterruptServiceRoutine

;; *************** function _InterruptServiceRoutine *****************
;; Defined at:
;;		line 126 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMRAM   BANK0   BANK1
;;      Params:         0       0       0
;;      Locals:         0       0       0
;;      Temps:          0       0       0
;;      Totals:         0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used: 1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		Interrupt level 2
;; This function uses a non-reentrant model
;;
psect	intcode,class=CODE,space=0,reloc=2
	file	"build_check.s"
	line	#
global __pintcode
__pintcode:
psect	intcode
	file	"main.c"
	line	126
	
_InterruptServiceRoutine:
;incstack = 0
	callstack 21
	bsf int$flags,1,c ;set compiler interrupt flag (level 2)
	line	128
	
i2l2256:
	btfss	((c:4082))^0f00h,c,2	;volatile
	goto	i2u164_41
	goto	i2u164_40
i2u164_41:
	goto	i2l128
i2u164_40:
	line	129
	
i2l2258:
	setf	((c:4055))^0f00h,c	;volatile
	line	130
	
i2l2260:
	movlw	low(06h)
	movwf	((c:4054))^0f00h,c	;volatile
	line	131
	
i2l2262:
	bcf	((c:4082))^0f00h,c,2	;volatile
	line	132
	
i2l2264:
	movlw	low(01h)
	addwf	((c:_milliseconds))^00h,c	;volatile
	movlw	0
	addwfc	((c:_milliseconds+1))^00h,c	;volatile
	addwfc	((c:_milliseconds+2))^00h,c	;volatile
	addwfc	((c:_milliseconds+3))^00h,c	;volatile
	line	134
	
i2l128:
	bcf int$flags,1,c ;clear compiler interrupt flag (level 2)
	retfie f
	callstack 0
GLOBAL	__end_of_InterruptServiceRoutine
	__end_of_InterruptServiceRoutine:
	signat	_InterruptServiceRoutine,89
psect	mediumconst
	db 0	; dummy byte at the end
	global	__smallconst
__smallconst	set	__pmediumconst
	global	__mediumconst
__mediumconst	set	__pmediumconst
	GLOBAL	__activetblptr
__activetblptr	EQU	2
	psect	intsave_regs,class=BIGRAM,space=1,noexec
	PSECT	rparam,class=COMRAM,space=1,noexec
	GLOBAL	__Lrparam
	FNCONF	rparam,??,?
	GLOBAL	___rparam_used
	___rparam_used EQU 1
	GLOBAL	___param_bank
	___param_bank EQU 0
GLOBAL	__Lparam, __Hparam
GLOBAL	__Lrparam, __Hrparam
__Lparam	EQU	__Lrparam
__Hparam	EQU	__Hrparam
	global	btemp
	btemp set 01h

	DABS	1,1,1	;btemp
	global	int$flags
	int$flags	set btemp
	global btemp0
	btemp0 set btemp+0
	global btemp1
	btemp1 set btemp+1
	end
