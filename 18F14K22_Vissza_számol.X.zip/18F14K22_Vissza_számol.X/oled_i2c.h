#ifndef OLED_I2C_H
#define OLED_I2C_H

#include "main.h"

#define OLED_WIDTH      128u
#define OLED_HEIGHT     64u
#define OLED_I2C_ADDR   0x3Cu

void OLED_Init(void);
void OLED_Clear(void);
void OLED_DisplayOn(void);
void OLED_Fill(uint8_t pattern);
void OLED_SetCursor(uint8_t column, uint8_t page);
void OLED_WriteText(const char *text);
void OLED_WriteTextCentered(uint8_t page, const char *text);
void OLED_WriteTextCenteredAtY(uint8_t y, const char *text);
void OLED_WriteTextDoubleCentered(uint8_t page, const char *text);
uint8_t OLED_TextWidth(const char *text);

#endif
