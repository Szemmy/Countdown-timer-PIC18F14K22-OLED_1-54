#include "oled_i2c.h"

#define I2C_SPEED_HZ 100000UL

#define OLED_CONTROL_COMMAND 0x00u
#define OLED_CONTROL_DATA    0x40u

static void I2C_Init(void);
static void I2C_Start(void);
static void I2C_Stop(void);
static bool I2C_Write(uint8_t data);
static void I2C_WaitIdle(void);
static bool I2C_AddressResponds(uint8_t address);
static void OLED_FindAddress(void);
static bool OLED_Command(uint8_t command);
static bool OLED_CommandBlock(const uint8_t *commands, uint8_t length);
static bool OLED_DataBlock(const uint8_t *data, uint8_t length);
static const uint8_t *OLED_GetGlyph(const char **text);
static void OLED_WriteTextAtY(uint8_t column, uint8_t y, const char *text);
static uint8_t OLED_ScaleGlyph(const uint8_t glyphColumn, bool lowerPage);
static void OLED_WriteTextDoublePage(uint8_t column, uint8_t page,
                                     const char *text, bool lowerPage);

static uint8_t oledAddress = OLED_I2C_ADDR;
/* A single page-sized transfer buffer replaces the slow byte-by-byte writes. */
static uint8_t oledTransferBuffer[OLED_WIDTH];

static const uint8_t font5x7[][5] = {
    {0x00,0x00,0x00,0x00,0x00}, /* space */
    {0x00,0x00,0x5F,0x00,0x00}, /* ! */
    {0x00,0x07,0x00,0x07,0x00}, /* " */
    {0x14,0x7F,0x14,0x7F,0x14}, /* # */
    {0x24,0x2A,0x7F,0x2A,0x12}, /* $ */
    {0x23,0x13,0x08,0x64,0x62}, /* % */
    {0x36,0x49,0x55,0x22,0x50}, /* & */
    {0x00,0x05,0x03,0x00,0x00}, /* ' */
    {0x00,0x1C,0x22,0x41,0x00}, /* ( */
    {0x00,0x41,0x22,0x1C,0x00}, /* ) */
    {0x14,0x08,0x3E,0x08,0x14}, /* * */
    {0x08,0x08,0x3E,0x08,0x08}, /* + */
    {0x00,0x50,0x30,0x00,0x00}, /* , */
    {0x08,0x08,0x08,0x08,0x08}, /* - */
    {0x00,0x60,0x60,0x00,0x00}, /* . */
    {0x20,0x10,0x08,0x04,0x02}, /* / */
    {0x3E,0x51,0x49,0x45,0x3E}, /* 0 */
    {0x00,0x42,0x7F,0x40,0x00}, /* 1 */
    {0x42,0x61,0x51,0x49,0x46}, /* 2 */
    {0x21,0x41,0x45,0x4B,0x31}, /* 3 */
    {0x18,0x14,0x12,0x7F,0x10}, /* 4 */
    {0x27,0x45,0x45,0x45,0x39}, /* 5 */
    {0x3C,0x4A,0x49,0x49,0x30}, /* 6 */
    {0x01,0x71,0x09,0x05,0x03}, /* 7 */
    {0x36,0x49,0x49,0x49,0x36}, /* 8 */
    {0x06,0x49,0x49,0x29,0x1E}, /* 9 */
    {0x00,0x36,0x36,0x00,0x00}, /* : */
    {0x00,0x56,0x36,0x00,0x00}, /* ; */
    {0x08,0x14,0x22,0x41,0x00}, /* < */
    {0x14,0x14,0x14,0x14,0x14}, /* = */
    {0x00,0x41,0x22,0x14,0x08}, /* > */
    {0x02,0x01,0x51,0x09,0x06}, /* ? */
    {0x32,0x49,0x79,0x41,0x3E}, /* @ */
    {0x7E,0x11,0x11,0x11,0x7E}, /* A */
    {0x7F,0x49,0x49,0x49,0x36}, /* B */
    {0x3E,0x41,0x41,0x41,0x22}, /* C */
    {0x7F,0x41,0x41,0x22,0x1C}, /* D */
    {0x7F,0x49,0x49,0x49,0x41}, /* E */
    {0x7F,0x09,0x09,0x09,0x01}, /* F */
    {0x3E,0x41,0x49,0x49,0x7A}, /* G */
    {0x7F,0x08,0x08,0x08,0x7F}, /* H */
    {0x00,0x41,0x7F,0x41,0x00}, /* I */
    {0x20,0x40,0x41,0x3F,0x01}, /* J */
    {0x7F,0x08,0x14,0x22,0x41}, /* K */
    {0x7F,0x40,0x40,0x40,0x40}, /* L */
    {0x7F,0x02,0x0C,0x02,0x7F}, /* M */
    {0x7F,0x04,0x08,0x10,0x7F}, /* N */
    {0x3E,0x41,0x41,0x41,0x3E}, /* O */
    {0x7F,0x09,0x09,0x09,0x06}, /* P */
    {0x3E,0x41,0x51,0x21,0x5E}, /* Q */
    {0x7F,0x09,0x19,0x29,0x46}, /* R */
    {0x46,0x49,0x49,0x49,0x31}, /* S */
    {0x01,0x01,0x7F,0x01,0x01}, /* T */
    {0x3F,0x40,0x40,0x40,0x3F}, /* U */
    {0x1F,0x20,0x40,0x20,0x1F}, /* V */
    {0x3F,0x40,0x38,0x40,0x3F}, /* W */
    {0x63,0x14,0x08,0x14,0x63}, /* X */
    {0x07,0x08,0x70,0x08,0x07}, /* Y */
    {0x61,0x51,0x49,0x45,0x43}, /* Z */
    {0x00,0x7F,0x41,0x41,0x00}, /* [ */
    {0x02,0x04,0x08,0x10,0x20}, /* backslash */
    {0x00,0x41,0x41,0x7F,0x00}, /* ] */
    {0x04,0x02,0x01,0x02,0x04}, /* ^ */
    {0x40,0x40,0x40,0x40,0x40}, /* _ */
    {0x00,0x01,0x02,0x04,0x00}, /* ` */
    {0x20,0x54,0x54,0x54,0x78}, /* a */
    {0x7F,0x48,0x44,0x44,0x38}, /* b */
    {0x38,0x44,0x44,0x44,0x20}, /* c */
    {0x38,0x44,0x44,0x48,0x7F}, /* d */
    {0x38,0x54,0x54,0x54,0x18}, /* e */
    {0x08,0x7E,0x09,0x01,0x02}, /* f */
    {0x0C,0x52,0x52,0x52,0x3E}, /* g */
    {0x7F,0x08,0x04,0x04,0x78}, /* h */
    {0x00,0x44,0x7D,0x40,0x00}, /* i */
    {0x20,0x40,0x44,0x3D,0x00}, /* j */
    {0x7F,0x10,0x28,0x44,0x00}, /* k */
    {0x00,0x41,0x7F,0x40,0x00}, /* l */
    {0x7C,0x04,0x18,0x04,0x78}, /* m */
    {0x7C,0x08,0x04,0x04,0x78}, /* n */
    {0x38,0x44,0x44,0x44,0x38}, /* o */
    {0x7C,0x14,0x14,0x14,0x08}, /* p */
    {0x08,0x14,0x14,0x18,0x7C}, /* q */
    {0x7C,0x08,0x04,0x04,0x08}, /* r */
    {0x48,0x54,0x54,0x54,0x20}, /* s */
    {0x04,0x3F,0x44,0x40,0x20}, /* t */
    {0x3C,0x40,0x40,0x20,0x7C}, /* u */
    {0x1C,0x20,0x40,0x20,0x1C}, /* v */
    {0x3C,0x40,0x30,0x40,0x3C}, /* w */
    {0x44,0x28,0x10,0x28,0x44}, /* x */
    {0x0C,0x50,0x50,0x50,0x3C}, /* y */
    {0x44,0x64,0x54,0x4C,0x44}, /* z */
};

static const uint8_t glyph_o_double_acute_upper[5] = {0x3E,0x43,0x41,0x43,0x3E};
static const uint8_t glyph_o_double_acute_lower[5] = {0x38,0x46,0x44,0x46,0x38};
static const uint8_t glyph_a_acute_upper[5] = {0x7E,0x11,0x11,0x11,0x7F};
static const uint8_t glyph_a_acute_lower[5] = {0x3C,0x4A,0x49,0x49,0x7C};
static const uint8_t glyph_unknown[5] = {0x02,0x01,0x51,0x09,0x06};

void OLED_Init(void)
{
    I2C_Init();
    __delay_ms(100);
    OLED_FindAddress();

    OLED_Command(0xAE);
    OLED_Command(0xD5);
    OLED_Command(0x80);
    OLED_Command(0xA8);
    OLED_Command(0x3F);
    OLED_Command(0xD3);
    OLED_Command(0x00);
    OLED_Command(0x40);
    OLED_Command(0x8D);
    OLED_Command(0x14);
    OLED_Command(0x20);
    OLED_Command(0x02);
    OLED_Command(0xA1);
    OLED_Command(0xC8);
    OLED_Command(0xDA);
    OLED_Command(0x12);
    OLED_Command(0x81);
    OLED_Command(0xCF);
    OLED_Command(0xD9);
    OLED_Command(0xF1);
    OLED_Command(0xDB);
    OLED_Command(0x40);
    OLED_Command(0xA4);
    OLED_Command(0xA6);
    OLED_Clear();
    OLED_DisplayOn();
}

void OLED_Clear(void)
{
    OLED_Fill(0x00);
}

void OLED_Fill(uint8_t pattern)
{
    uint8_t page;
    uint8_t column;

    for (column = 0u; column < OLED_WIDTH; column++) {
        oledTransferBuffer[column] = pattern;
    }

    for (page = 0; page < 8u; page++) {
        OLED_SetCursor(0u, page);
        OLED_DataBlock(oledTransferBuffer, OLED_WIDTH);
    }
    OLED_SetCursor(0u, 0u);
}

void OLED_DisplayOn(void)
{
    OLED_Command(0xAF);
}

void OLED_SetCursor(uint8_t column, uint8_t page)
{
    uint8_t commands[3];

    if (column >= OLED_WIDTH) {
        column = OLED_WIDTH - 1u;
    }
    if (page > 7u) {
        page = 7u;
    }

    commands[0] = (uint8_t)(0xB0u | page);
    commands[1] = (uint8_t)(0x00u | (column & 0x0Fu));
    commands[2] = (uint8_t)(0x10u | (column >> 4));
    OLED_CommandBlock(commands, 3u);
}

void OLED_WriteText(const char *text)
{
    uint8_t length = 0u;
    const uint8_t *glyph;

    while ((*text != '\0') && (length <= (OLED_WIDTH - 6u))) {
        glyph = OLED_GetGlyph(&text);
        oledTransferBuffer[length++] = glyph[0];
        oledTransferBuffer[length++] = glyph[1];
        oledTransferBuffer[length++] = glyph[2];
        oledTransferBuffer[length++] = glyph[3];
        oledTransferBuffer[length++] = glyph[4];
        oledTransferBuffer[length++] = 0x00u;
    }

    OLED_DataBlock(oledTransferBuffer, length);
}

void OLED_WriteTextCentered(uint8_t page, const char *text)
{
    uint8_t width = OLED_TextWidth(text);
    uint8_t column = 0u;

    if (width < OLED_WIDTH) {
        column = (uint8_t)((OLED_WIDTH - width) / 2u);
    }

    OLED_SetCursor(column, page);
    OLED_WriteText(text);
}

void OLED_WriteTextCenteredAtY(uint8_t y, const char *text)
{
    uint8_t width = OLED_TextWidth(text);
    uint8_t column = 0u;

    if (width < OLED_WIDTH) {
        column = (uint8_t)((OLED_WIDTH - width) / 2u);
    }

    OLED_WriteTextAtY(column, y, text);
}

void OLED_WriteTextDoubleCentered(uint8_t page, const char *text)
{
    uint8_t width = (uint8_t)(OLED_TextWidth(text) * 2u);
    uint8_t column = 0u;

    if (width < OLED_WIDTH) {
        column = (uint8_t)((OLED_WIDTH - width) / 2u);
    }

    OLED_WriteTextDoublePage(column, page, text, false);
    if (page < 7u) {
        OLED_WriteTextDoublePage(column, (uint8_t)(page + 1u), text, true);
    }
}

uint8_t OLED_TextWidth(const char *text)
{
    uint8_t width = 0u;

    while (*text != '\0') {
        if ((uint8_t)text[0] == 0xC5u && (uint8_t)text[1] == 0x90u) {
            text += 2;
        } else if ((uint8_t)text[0] == 0xC5u && (uint8_t)text[1] == 0x91u) {
            text += 2;
        } else if ((uint8_t)text[0] == 0xC3u && (uint8_t)text[1] == 0x81u) {
            text += 2;
        } else if ((uint8_t)text[0] == 0xC3u && (uint8_t)text[1] == 0xA1u) {
            text += 2;
        } else {
            text++;
        }

        if (width <= (OLED_WIDTH - 6u)) {
            width = (uint8_t)(width + 6u);
        }
    }

    return width;
}

static void OLED_WriteTextAtY(uint8_t column, uint8_t y, const char *text)
{
    const char *pointer;
    const uint8_t *glyph;
    uint8_t page = (uint8_t)(y >> 3);
    uint8_t shift = (uint8_t)(y & 0x07u);
    uint8_t index;
    uint8_t length;

    if (page > 7u) {
        return;
    }

    length = 0u;
    pointer = text;
    while ((*pointer != '\0') && (length <= (OLED_WIDTH - 6u))) {
        glyph = OLED_GetGlyph(&pointer);
        for (index = 0u; index < 5u; index++) {
            oledTransferBuffer[length++] = (uint8_t)(glyph[index] << shift);
        }
        oledTransferBuffer[length++] = 0x00u;
    }
    OLED_SetCursor(column, page);
    OLED_DataBlock(oledTransferBuffer, length);

    if ((shift != 0u) && (page < 7u)) {
        length = 0u;
        pointer = text;
        while ((*pointer != '\0') && (length <= (OLED_WIDTH - 6u))) {
            glyph = OLED_GetGlyph(&pointer);
            for (index = 0u; index < 5u; index++) {
                oledTransferBuffer[length++] = (uint8_t)(glyph[index] >> (8u - shift));
            }
            oledTransferBuffer[length++] = 0x00u;
        }
        OLED_SetCursor(column, (uint8_t)(page + 1u));
        OLED_DataBlock(oledTransferBuffer, length);
    }
}

static uint8_t OLED_ScaleGlyph(const uint8_t glyphColumn, bool lowerPage)
{
    uint8_t row;
    uint8_t result = 0u;

    for (row = 0u; row < 7u; row++) {
        uint8_t targetBit = (uint8_t)(row * 2u);

        if ((glyphColumn & ((uint8_t)1u << row)) != 0u) {
            if (!lowerPage) {
                if (targetBit < 8u) {
                    result |= (uint8_t)(0x03u << targetBit);
                }
            } else if (targetBit >= 8u) {
                result |= (uint8_t)(0x03u << (targetBit - 8u));
            }
        }
    }

    return result;
}

static void OLED_WriteTextDoublePage(uint8_t column, uint8_t page,
                                     const char *text, bool lowerPage)
{
    const char *pointer = text;
    const uint8_t *glyph;
    uint8_t index;
    uint8_t scaledColumn;
    uint8_t length = 0u;

    while ((*pointer != '\0') && (length <= (OLED_WIDTH - 12u))) {
        glyph = OLED_GetGlyph(&pointer);
        for (index = 0u; index < 5u; index++) {
            scaledColumn = OLED_ScaleGlyph(glyph[index], lowerPage);
            oledTransferBuffer[length++] = scaledColumn;
            oledTransferBuffer[length++] = scaledColumn;
        }
        oledTransferBuffer[length++] = 0x00u;
        oledTransferBuffer[length++] = 0x00u;
    }

    OLED_SetCursor(column, page);
    OLED_DataBlock(oledTransferBuffer, length);
}

static const uint8_t *OLED_GetGlyph(const char **text)
{
    uint8_t c = (uint8_t)(**text);

    if (c == 0xC5u && (uint8_t)(*text)[1] == 0x90u) {
        *text += 2;
        return glyph_o_double_acute_upper;
    }

    if (c == 0xC5u && (uint8_t)(*text)[1] == 0x91u) {
        *text += 2;
        return glyph_o_double_acute_lower;
    }

    if (c == 0xC3u && (uint8_t)(*text)[1] == 0x81u) {
        *text += 2;
        return glyph_a_acute_upper;
    }

    if (c == 0xC3u && (uint8_t)(*text)[1] == 0xA1u) {
        *text += 2;
        return glyph_a_acute_lower;
    }

    (*text)++;

    if (c < 32u || c > 126u) {
        return glyph_unknown;
    }

    return font5x7[c - 32u];
}

static bool OLED_Command(uint8_t command)
{
    return OLED_CommandBlock(&command, 1u);
}

static bool OLED_CommandBlock(const uint8_t *commands, uint8_t length)
{
    uint8_t index;

    I2C_Start();
    if (!I2C_Write((uint8_t)(oledAddress << 1))) {
        I2C_Stop();
        return false;
    }
    if (!I2C_Write(OLED_CONTROL_COMMAND)) {
        I2C_Stop();
        return false;
    }
    for (index = 0u; index < length; index++) {
        if (!I2C_Write(commands[index])) {
            I2C_Stop();
            return false;
        }
    }
    I2C_Stop();
    return true;
}

static bool OLED_DataBlock(const uint8_t *data, uint8_t length)
{
    uint8_t index;

    I2C_Start();
    if (!I2C_Write((uint8_t)(oledAddress << 1))) {
        I2C_Stop();
        return false;
    }
    if (!I2C_Write(OLED_CONTROL_DATA)) {
        I2C_Stop();
        return false;
    }
    for (index = 0u; index < length; index++) {
        if (!I2C_Write(data[index])) {
            I2C_Stop();
            return false;
        }
    }
    I2C_Stop();
    return true;
}

static void I2C_Init(void)
{
    SSPSTATbits.SMP = 1;
    SSPSTATbits.CKE = 0;
    SSPCON1bits.SSPM = 0x08;
    SSPCON1bits.SSPEN = 1;
    SSPCON2 = 0x00;
    SSPADD = (uint8_t)((_XTAL_FREQ / (4UL * I2C_SPEED_HZ)) - 1UL);

    ANSELHbits.ANSEL10 = 0;
    ANSELHbits.ANSEL11 = 0;
    TRISBbits.TRISB4 = 1;
    TRISBbits.TRISB6 = 1;
}

static void I2C_Start(void)
{
    I2C_WaitIdle();
    PIR1bits.SSPIF = 0;
    SSPCON2bits.SEN = 1;
    while (SSPCON2bits.SEN);
}

static void I2C_Stop(void)
{
    I2C_WaitIdle();
    PIR1bits.SSPIF = 0;
    SSPCON2bits.PEN = 1;
    while (SSPCON2bits.PEN);
}

static bool I2C_Write(uint8_t data)
{
    I2C_WaitIdle();
    PIR1bits.SSPIF = 0;
    SSPBUF = data;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;
    return (SSPCON2bits.ACKSTAT == 0);
}

static void I2C_WaitIdle(void)
{
    while ((SSPCON2 & 0x1F) || SSPSTATbits.R_W) {
    }
}

static bool I2C_AddressResponds(uint8_t address)
{
    bool acknowledged;

    I2C_Start();
    acknowledged = I2C_Write((uint8_t)(address << 1));
    I2C_Stop();

    return acknowledged;
}

static void OLED_FindAddress(void)
{
    if (I2C_AddressResponds(0x3Cu)) {
        oledAddress = 0x3Cu;
    } else if (I2C_AddressResponds(0x3Du)) {
        oledAddress = 0x3Du;
    } else {
        oledAddress = OLED_I2C_ADDR;
    }
}
